# IREE RISC-V 64 (`riscv64` RVV) CI/CD Engineering & Handover Documentation

This document explains **what our RISC-V 64 Vector (`riscv64` RVV) CI/CD pipeline is trying to achieve**, **which script files run at every stage (with visual flow graphs)**, and **the exact copy-paste commands** (both modular script commands and raw underlying CLI commands) so the CI/CD team can wire up **Pull Request (PR)**, **Nightly Release**, and **Stable Release** pipelines in Jenkins, GitLab CI, GitHub Actions, or Buildkite without any guesswork.

## 1. Executive Summary: What Are We Trying to Do?

We maintain a fork of the [IREE (Intermediate Representation Execution Environment) compiler and runtime](https://github.com/iree-org/iree) targeting **64-bit RISC-V processors with the RISC-V Vector Extension (`riscv64` RVV 1.0)**.

Because standard CI servers run on `x86_64` Linux machines while our deployment target is `riscv64` with vector instructions (`+v`, `+zvl256b` / `+zvl512b`), our CI/CD pipeline must solve four problems automatically:

1. **Two-Stage Cross-Compilation ([IREE RISC-V Build Flow](https://iree.dev/building-from-source/riscv/))**:

   * **Host Build (`x86_64`)**: Compile the IREE compiler (`iree-compile`) and ONNX importer (`iree-import-onnx`) to run on the fast `x86_64` CI host while emitting `riscv64` RVV machine code.

   * **Target Cross-Build (`riscv64`)**: Cross-compile the lightweight IREE runtime (`iree-run-module`, `iree-benchmark-module`, and RVV microkernel test binaries) for `riscv64-unknown-linux-gnu` using [`build_tools/cmake/linux_riscv64.cmake`](https://github.com/iree-org/iree/blob/main/build_tools/cmake/linux_riscv64.cmake).

2. **Three-Tier Compiler & Runtime Verification (Lit → RVV `ukernel` → E2E Matmul)**:

   * Verify that MLIR compiler passes generate valid RISC-V vector instructions (`lit` tests), that hand-tuned RISC-V 64 C/assembly microkernels ([IREE CPU Microkernels](https://iree.dev/community/blog/2024-01-22-exploring-cpu-microkernels-on-a-matmul-example/#overview-of-the-compilation-and-linking-flow)) compute exact tile math (`ukernel` tests), and that the compiler-to-runtime tile contract (`e2e_matmul`) executes on `qemu-riscv64` (with RVV 1.0 enabled) or a physical RISC-V board.

3. **Zero-Config ONNX Model + External Weights Auto-Discovery (`stable` vs. `nightly`)**:

   * Whenever an engineer drops a new `.onnx` model and its external weight files (`.onnx.data`, `.weights`, `.bin`, `.pb`) into `tests/onnx_models/stable/<model_name>/` or `tests/onnx_models/nightly/<model_name>/`, the pipeline automatically discovers the model and weights, classifies its release tier (`stable` or `nightly`), and runs it without anyone editing CI pipeline definitions.

4. **End-to-End Numerical Accuracy Verification (ONNX Runtime Golden `.npy` vs. IREE RVV `.npy`)**:

   * To prove that IREE's RISC-V RVV compilation did not degrade model accuracy, every discovered ONNX model is fed identical deterministic NumPy input tensors (`input_0.npy`) through **both** **ONNX Runtime** (golden reference producing `ort_output_0.npy`) and [**IREE's ONNX-to-RVV path**](https://iree.dev/guides/ml-frameworks/onnx/) (or our custom pipeline script, producing `iree_output_0.npy`). The pipeline compares both NumPy arrays via `np.allclose(atol, rtol)` and reports `max_abs_diff`, `mean_abs_diff`, `RMSE`, and `cosine_similarity`.

## 2. Visual Flow Graphs: Which Scripts Run at Each CI/CD Stage?

*(Note: `tests/onnx_models/` is skipped by default. The active pipeline runs the **VME Ukernel Path** via `ci/riscv_rvv/vme_ukernel_suite/`. A high-resolution diagram is bundled at `ci/riscv_rvv/docs/iree_riscv64_rvv_cicd_flow_graph.png`.)*

### Flow Graph A: Master CI/CD Stage Pipeline (VME Ukernel Path)

```text
[CI/CD Trigger Event]
  |
  +---> Pull Request (PR) -----> ./ci/riscv_rvv/ci_entrypoint.sh --stage pr
  +---> Nightly Cron Schedule -> ./ci/riscv_rvv/ci_entrypoint.sh --stage nightly
  +---> Release Tag (v*.*.*) --> ./ci/riscv_rvv/ci_entrypoint.sh --stage stable
          |
          v
  +======================================================+
  | STAGE 0: Fast Pre-Commit & Script Integrity Gate     |
  +======================================================+
  | Script : ci/riscv_rvv/modules/00_pre_commit_check.sh
          |
          v
  +======================================================+
  | STAGE 1: Two-Step Host + RISC-V 64 RVV Cross-Build   |
  +======================================================+
  | Script : ci/riscv_rvv/modules/01_build_iree_rvv.sh
  | Config : ci/riscv_rvv/config.env
  |   |-- 1A. Host Build (iree-compile, iree-import-onnx)
  |   +-- 1B. Target Cross-Build (riscv64 iree-run-module)
          |
          v
  +======================================================+
  | STAGE 2: IREE Core Tests (Lit + RVV ukernel + HAL)   |
  +======================================================+
  | Script : ci/riscv_rvv/modules/02_run_iree_core_tests.sh
  |          (Delegates RISC-V target tests to riscv_test.sh)
  |   |-- 2A. Host Lit Tests (MLIR -> RISC-V RVV codegen)
  |   |-- 2B. RVV Microkernel Tests (ctest -R ukernel)
  |   +-- 2C. Core Runtime / HAL / e2e_matmul
          |
          v
  +======================================================+
  | STAGE 3: Generate VME Ukernel ONNX & CTest Suite     |
  +======================================================+
  | Scripts:
  |   |-- vme_ukernel_suite/gen_conv2d_onnx.py
  |   |-- vme_ukernel_suite/gen_matmul_onnx.py
  |   +-- vme_ukernel_suite/gen_conv_matmul_model_onnx.py
  | Output : conv2d_tests.cmake, matmul_tests.cmake,
  |          conv_matmul_model_tests.cmake
          |
          v
  +======================================================+
  | STAGE 4: Run VME Ukernel Path via CTest              |
  +======================================================+
  | Runner : ctest --test-dir build-vme-ctest -R vme_ukernel
  | Script : vme_ukernel_suite/run_vme_ukernel_case.py
  |   |-- 4A. IREE VME Ukernel Path -> iree_output_0.npy
  |   |-- 4B. ONNX Runtime Golden   -> ort_output_0.npy
  |   +-- 4C. NumPy np.allclose(atol, rtol) + JUnit XML
          |
          v
  +======================================================+
  | STAGE 5: Release Packaging (Nightly & Stable Only)   |
  +======================================================+
  | Output : iree-<version>.tar.gz + .sha256 checksum
```

| Stage | Script Executed | Key Inputs Consumed | Key Outputs Produced |
| :--- | :--- | :--- | :--- |
| **Stage 0: Pre-Commit Gate** | `ci/riscv_rvv/modules/00_pre_commit_check.sh` | `ci/riscv_rvv/**` | Exit `0` (Pass) or `1` |
| **Stage 1: Build & Cross-Build** | `ci/riscv_rvv/modules/01_build_iree_rvv.sh` | `ci/riscv_rvv/config.env`, `linux_riscv64.cmake` | `iree-compile`, `iree-import-onnx`, `iree-run-module` |
| **Stage 2: Core CTest Pyramid** | `ci/riscv_rvv/modules/02_run_iree_core_tests.sh` (`riscv_test.sh`) | `--stage pr\|nightly\|stable` | `junit_host_lit_*.xml`, `junit_riscv_rvv_ukernel.xml` |
| **Stage 3: Generate VME ONNX Cases** | `gen_conv2d_onnx.py`, `gen_matmul_onnx.py`, `gen_conv_matmul_model_onnx.py` | Dimension & model configs | `.onnx` files + `*_tests.cmake` |
| **Stage 4: VME Ukernel CTest Run** | `ci/riscv_rvv/vme_ukernel_suite/run_vme_ukernel_case.py` | `IREE_VME_CPU_FEATURES` | `iree_output_0.npy`, `ort_output_0.npy`, `comparison_report.json`, `junit_vme_ukernel_*.xml` |
| **Stage 5: Release Packaging** | `ci/riscv_rvv/ci_entrypoint.sh` | Host & `riscv64` binaries | `iree-<version>.tar.gz` + `.sha256` |

### Flow Graph B: VME Ukernel Path Dataflow (Per-Case CTest Execution)

Every `ctest -R vme_ukernel` test case runs `run_vme_ukernel_case.py` in this exact order:

```text
[Generated ONNX Case: Conv2D | Unbatched MatMul | Conv+MatMul Model]
        |
        v
  [STEP 1] Generate Deterministic NumPy Input
        +-> Saves inputs/input_0.npy matching ONNX graph signature
        |
        v
  [STEP 2] FIRST: Execute IREE VME Ukernel Path
        |-- 2a. iree-import-onnx model.onnx -o model.mlir
        |-- 2b. iree-compile model.mlir
        |         --iree-llvmcpu-target-cpu-features="${IREE_VME_CPU_FEATURES}"
        |         --iree-opt-data-tiling
        |         --iree-llvmcpu-enable-ukernels=all
        |         --iree-global-opt-use-im2col-for-convs=true
        |         -> model_vme.vmfb
        +-- 2c. iree-run-module --module=model_vme.vmfb
                  --input=@inputs/input_0.npy
                  --output=@iree_outputs/iree_output_0.npy
        |
        v
  [STEP 3] THEN: Execute ONNX Runtime Golden Reference
        |-- Runs onnxruntime.InferenceSession (CPUExecutionProvider)
        +-- Feeds exact same inputs/input_0.npy
              -> Saves ort_outputs/ort_output_0.npy
        |
        v
  [STEP 4] NumPy Numerical Comparison (03_ort_vs_iree_numpy.py)
        |-- Loads ort_output_0.npy & iree_output_0.npy
        |-- Computes max_abs_diff, mean_abs_diff, RMSE, cosine_sim
        +-- Asserts np.allclose(ort_arr, iree_arr, rtol=1e-3, atol=1e-3)
              -> comparison_report.json + CTest Pass/Fail
```

## 3. Detailed Explanation of Every Stage: What Is Each Step Trying to Do?

### Stage 1: Two-Step Host + Target Cross-Compilation (`01_build_iree_rvv.sh`)

* **What it is trying to do**: IREE separates compilation (heavy MLIR/LLVM optimization passes) from execution (a lightweight C runtime). We build `iree-compile` and `iree-import-onnx` natively for the `x86_64` CI host so model compilation is fast, and then cross-compile only the IREE runtime and test binaries (`iree-run-module`, `iree-benchmark-module`, `ukernel` tests) for `riscv64-unknown-linux-gnu` using [`build_tools/cmake/linux_riscv64.cmake`](https://github.com/iree-org/iree/blob/main/build_tools/cmake/linux_riscv64.cmake).

* **Why `RelWithDebInfo` vs. `Release`**: PR and Nightly runs use `RelWithDebInfo` with `-DIREE_ENABLE_ASSERTIONS=ON` so any compiler assertion or stack trace is immediately visible on failure. Stable releases use `Release` for maximum runtime performance.

### Stage 2: IREE Internal CTest Verification Pyramid (`02_run_iree_core_tests.sh`)

This script runs four distinct layers of internal IREE tests so failures are isolated to the exact subsystem:

1. **Layer 2A — Compiler Lit Tests (`ctest --test-dir build-host -R "Codegen/LLVMCPU|riscv"`)**:

   * **What it is trying to do**: Runs MLIR `FileCheck` tests on the host compiler to verify that high-level tensor operations lower into expected RISC-V vector (`rvv`) instructions and select the right tile sizes before running anything on an emulator.

2. **Layer 2B — RISC-V 64 RVV Microkernel (`ukernel`) Unit Tests (`ctest --test-dir build-riscv64-rvv -R "ukernel"`)**:

   * **What it is trying to do**: Executes [`mmt4d_test`, `pack_test`, `unpack_test`, and `query_tile_sizes_test`](https://iree.dev/community/blog/2024-01-22-exploring-cpu-microkernels-on-a-matmul-example/#overview-of-the-compilation-and-linking-flow) under `qemu-riscv64` with RVV enabled.

   * **Why it is critical & what it covers**: In IREE, data-tiled matrix multiplications (`linalg.mmt4d`) dispatch to hand-written RISC-V 64 C/assembly microkernels in [`runtime/src/iree/builtins/ukernel/arch/riscv_64/`](https://github.com/iree-org/iree/issues/24576) (`mmt4d_riscv_64_v.c`, `mmt4d_riscv_64_zvfh.c`). These tests validate vector register arithmetic, accumulation flags, and odd-dimension padding across `f32`, `f16` (`+zvfh`), and `i8->i32` in under 30 seconds.

   * **What it does NOT cover (why Layers 2D & Stage 4 are also required)**: Standalone `ukernel` tests only cover `mmt4d`/`pack`/`unpack` and set `ALLOW_GENERIC_FALLBACK` in the test harness ([IREE Issue #24576](https://github.com/iree-org/iree/issues/24576)). They do not verify that the compiler's tile chooser (`enumerateMatmulTileRiscv64`) agrees with the runtime tile table (`mmt4d_riscv_64_tiles.inl`), nor do they test convolutions, softmax, normalization, or full-model weight loading.

3. **Layer 2C — Core Runtime, HAL & VM Tests (`ctest --test-dir build-riscv64-rvv -R "iree/base|iree/hal|iree/vm"`)**:

   * **What it is trying to do**: Verifies that the RISC-V 64 Linux multi-threaded task scheduler (`local-task`), ELF executable loader, memory allocators, and VM bytecode interpreter work properly on `riscv64`.

4. **Layer 2D — End-to-End Data-Tiled Matmul & Check Smoke Tests (`ctest --test-dir build-riscv64-rvv -L "driver=local-task" -R "check_llvm-cpu|e2e_matmul"`)**:

   * **What it is trying to do**: Compiles end-to-end `.mlir` matmul workloads with `--iree-opt-data-tiling --iree-llvmcpu-enable-ukernels=all` on the host and executes the resulting `.vmfb` modules on `qemu-riscv64`, proving the compiler-to-runtime RVV microkernel contract is unbroken.

### Stage 3 & Stage 4: Auto-Discovered ONNX Models & ONNX Runtime vs. IREE NumPy Comparison

* **What it is trying to do**: Validates real-world neural networks (`.onnx` + external weights) end to end.

* **How `stable` vs. `nightly` tiering works**:

  * **PR Stage (`--tier pr`)**: Runs only models classified as `stable` (with `run_on_pr: true`, the default for `tests/onnx_models/stable/**`) so PR feedback stays fast while protecting production models from regressions.

  * **Nightly Stage (`--tier nightly`)**: Runs **both** `stable` and `nightly` (`tests/onnx_models/nightly/**`) models overnight to test heavy models, new operators, and wider vector lengths (`+zvl512b`).

  * **Stable Release Stage (`--tier stable`)**: Runs all `stable` models as a strict release gate (`fail-fast`) before packaging the official release tarball.

## 4. Copy-Paste Command Reference for the CI/CD Team

The CI/CD team can integrate this pipeline in **three ways** depending on their pipeline design:

* **Option 1**: Single-command master entrypoint per trigger (simplest).

* **Option 2**: Modular stage-by-stage script commands (for multi-stage CI graphs).

* **Option 3**: Raw underlying CLI commands (if the CI/CD team prefers to write raw commands directly in their runner config without wrapper scripts).

### Option 1: Single-Command Master Entrypoint (Recommended)

```
# 1. Run on Every Pull Request (PR):
./ci/riscv_rvv/ci_entrypoint.sh --stage pr

# 2. Run on Nightly Schedule (Cron):
./ci/riscv_rvv/ci_entrypoint.sh --stage nightly

# 3. Run on Stable Release Tag (e.g., v1.0.0):
./ci/riscv_rvv/ci_entrypoint.sh --stage stable --release-version v1.0.0

```

### Option 2: Modular Stage-by-Stage Script Commands

If the CI/CD team splits **Build**, **Core CTest**, **ONNX Discovery**, and **ONNX Execution + NumPy Comparison** into separate pipeline stages or parallel workers:

```
# --- STAGE 1: Build Host Compiler & Cross-Compile RISC-V 64 RVV Runtime ---
# Use RelWithDebInfo for PR/Nightly, Release for Stable Release
./ci/riscv_rvv/modules/01_build_iree_rvv.sh --build-type RelWithDebInfo

# --- STAGE 2: Run IREE Core CTest Verification Pyramid (Lit + RVV ukernel + HAL + E2E Matmul) ---
# Pass --stage pr, --stage nightly, or --stage stable
./ci/riscv_rvv/modules/02_run_iree_core_tests.sh --stage pr

# --- STAGE 3A (Optional): Emit Dynamic JSON Matrix of Auto-Discovered ONNX Models for Parallel CI Workers ---
python3 ci/riscv_rvv/discover_and_run_onnx.py \
  --models-root tests/onnx_models \
  --tier pr \
  --emit-matrix

# --- STAGE 3B: Run All Auto-Discovered ONNX Models for the Stage (with ORT vs. IREE NumPy Comparison) ---
# To run a single model on a parallel worker, append: --model-name <MODEL_NAME>
python3 ci/riscv_rvv/discover_and_run_onnx.py \
  --models-root tests/onnx_models \
  --tier pr \
  --iree-host-bin "$(realpath build-host/install/bin)" \
  --iree-riscv-bin "$(realpath build-riscv64-rvv/tools)" \
  --pipeline-script ./ci/riscv_rvv/modules/04_run_single_onnx_model.sh \
  --work-dir build-ci-artifacts/onnx_pr \
  --junit-xml build-ci-artifacts/onnx_pr/junit_onnx_pr.xml \
  --run

```

### Option 3: Raw Underlying CLI Commands (If Writing Commands Directly Without Wrapper Scripts)

If the CI/CD team wants to know or run the exact underlying CMake, CTest, IREE, QEMU, and Python commands directly:

#### 1. Raw Build Commands (Host Compiler + `riscv64` Cross-Compiled Runtime)

```
# 1A. Configure & build host compiler (iree-compile, iree-import-onnx)
cmake -G Ninja -B build-host . \
  -DCMAKE_C_COMPILER=clang \
  -DCMAKE_CXX_COMPILER=clang++ \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DCMAKE_INSTALL_PREFIX=build-host/install \
  -DIREE_ENABLE_ASSERTIONS=ON \
  -DIREE_ENABLE_LLD=ON \
  -DIREE_BUILD_COMPILER=ON \
  -DIREE_BUILD_TESTS=ON \
  -DIREE_BUILD_SAMPLES=OFF \
  -DIREE_TARGET_BACKEND_LLVM_CPU=ON \
  -DIREE_BUILD_PYTHON_BINDINGS=ON

cmake --build build-host --target install iree-test-deps

# 1B. Cross-compile IREE runtime & test binaries for riscv64
cmake -G Ninja -B build-riscv64-rvv . \
  -DCMAKE_TOOLCHAIN_FILE="./build_tools/cmake/linux_riscv64.cmake" \
  -DIREE_HOST_BIN_DIR="$(realpath build-host/install/bin)" \
  -DRISCV_TOOLCHAIN_ROOT="/opt/riscv" \
  -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DIREE_BUILD_COMPILER=OFF \
  -DIREE_BUILD_TESTS=ON \
  -DIREE_BUILD_SAMPLES=ON \
  -DIREE_ENABLE_CPUINFO=ON

cmake --build build-riscv64-rvv
cmake --build build-riscv64-rvv --target iree-test-deps

```

#### 2. Raw Core CTest Commands (PR vs. Nightly vs. Stable)

```
# 2A. Compiler Lit Tests (RISC-V & LLVMCPU RVV Codegen) — Run on PR, Nightly, Stable
ctest --test-dir build-host \
  -R "compiler/src/iree/compiler/Codegen/LLVMCPU|riscv" \
  --output-on-failure -j "$(nproc)" \
  --output-junit build-ci-artifacts/junit_host_lit_riscv.xml

# 2B. RISC-V 64 RVV Microkernel Tests (mmt4d, pack, unpack) — Run on PR, Nightly, Stable
ctest --test-dir build-riscv64-rvv \
  -R "ukernel" \
  --output-on-failure -j "$(nproc)" \
  --output-junit build-ci-artifacts/junit_riscv_rvv_ukernel.xml

# 2C. Core Runtime / HAL / VM Tests — Run on PR (use full ctest without -R on Nightly & Stable)
ctest --test-dir build-riscv64-rvv \
  -R "iree/base|iree/hal|iree/vm" \
  --output-on-failure -j "$(nproc)" \
  --output-junit build-ci-artifacts/junit_riscv_runtime_core.xml

# 2D. End-to-End Data-Tiled Matmul & Check Smoke Tests — Run on PR, Nightly, Stable
ctest --test-dir build-riscv64-rvv \
  -L "driver=local-task" \
  -R "check_llvm-cpu|e2e_matmul" \
  --output-on-failure -j "$(nproc)" \
  --output-junit build-ci-artifacts/junit_riscv_e2e_matmul.xml

```

#### 3. Raw Single-Model ONNX Runtime vs. IREE RISC-V 64 RVV NumPy Verification Commands

```
# 3A. Generate deterministic input_0.npy and run ONNX Runtime to save golden ort_output_0.npy
python3 ci/riscv_rvv/modules/03_ort_vs_iree_numpy.py prepare \
  --onnx tests/onnx_models/stable/my_model/model.onnx \
  --inputs-dir /tmp/my_model_run/inputs \
  --ort-outputs-dir /tmp/my_model_run/ort_outputs \
  --seed 42

# 3B. Import ONNX (+ external weights in same directory) to MLIR
./build-host/install/bin/iree-import-onnx \
  tests/onnx_models/stable/my_model/model.onnx \
  --opset-version 17 \
  -o /tmp/my_model_run/model.mlir

# 3C. Compile MLIR to RISC-V 64 RVV Executable (.vmfb) with RVV 1.0 & Microkernels
./build-host/install/bin/iree-compile \
  /tmp/my_model_run/model.mlir \
  --iree-hal-target-device=local \
  --iree-hal-local-target-device-backends=llvm-cpu \
  --iree-llvmcpu-target-triple=riscv64-unknown-linux-gnu \
  --iree-llvmcpu-target-abi=lp64d \
  --iree-llvmcpu-target-cpu-features="+m,+a,+f,+d,+v,+zvl256b" \
  --riscv-v-fixed-length-vector-lmul-max=8 \
  --iree-opt-data-tiling \
  --iree-llvmcpu-enable-ukernels=all \
  -o /tmp/my_model_run/model_riscv64_rvv.vmfb

# 3D. Execute on QEMU (RVV 1.0, VLEN=256) feeding input_0.npy and saving iree_output_0.npy
mkdir -p /tmp/my_model_run/iree_outputs
qemu-riscv64 -cpu rv64,v=true,vlen=256,vext_spec=v1.0 \
  -L /opt/riscv/sysroot \
  ./build-riscv64-rvv/tools/iree-run-module \
  --device=local-task \
  --module=/tmp/my_model_run/model_riscv64_rvv.vmfb \
  --function=main_graph \
  --input=@/tmp/my_model_run/inputs/input_0.npy \
  --output=@/tmp/my_model_run/iree_outputs/iree_output_0.npy

# 3E. Compare ONNX Runtime golden ort_output_0.npy vs. IREE RVV iree_output_0.npy
python3 ci/riscv_rvv/modules/03_ort_vs_iree_numpy.py compare \
  --ort-outputs /tmp/my_model_run/ort_outputs/ort_output_0.npy \
  --iree-outputs /tmp/my_model_run/iree_outputs/iree_output_0.npy \
  --atol 1e-3 --rtol 1e-3 \
  --report-json /tmp/my_model_run/comparison_report.json

```

## 5. Summary Matrix: PR vs. Nightly vs. Stable Release Pipeline Policies

| Pipeline Policy | Pull Request (`--stage pr`) | Nightly Release (`--stage nightly`) | Stable Release (`--stage stable`) | 
| ----- | ----- | ----- | ----- | 
| **Trigger Condition** | Every PR targeting `main` / `release/*` | Daily schedule (e.g., `0 20 * * *` UTC) | Git tag push (`v*.*.*`) or manual release trigger | 
| **CMake Build Type** | `RelWithDebInfo` (`IREE_ENABLE_ASSERTIONS=ON`) | `RelWithDebInfo` (`IREE_ENABLE_ASSERTIONS=ON`) | `Release` (fully optimized) | 
| **Host Lit Tests** | RISC-V & LLVMCPU subset (`-R "LLVMCPU|riscv"`) | Full host Lit test suite | RISC-V & LLVMCPU subset | 
| **RISC-V 64 RVV `ukernel` Tests** | Mandatory (`ctest -R ukernel`) | Mandatory (`ctest -R ukernel`) | Mandatory (`ctest -R ukernel`) | 
| **RISC-V 64 Runtime / HAL / E2E Tests** | Core HAL/VM + `check_llvm-cpu` + `e2e_matmul` | Full cross-compiled CTest suite | Full cross-compiled CTest suite | 
| **Auto-Discovered ONNX Models Executed** | `stable` tier models (`run_on_pr: true`) | Both `stable` AND `nightly` tier models | `stable` tier models (strict release gate) | 
| **ONNX Runtime vs. IREE NumPy Check** | Mandatory (`np.allclose` per output tensor) | Mandatory (`np.allclose` + full drift report) | Mandatory (`fail-fast: true`, blocks release on mismatch) | 
| **Output Artifacts for CI Dashboard** | JUnit XML + `comparison_summary.md` | JUnit XML + `comparison_summary.md` + `iree-nightly-riscv64-rvv-YYYYMMDD.tar.gz` | JUnit XML + `comparison_summary.md` + `iree-vX.Y.Z.tar.gz` + `.sha256` |

---

## 6. Pre-Commit Verification ()

To catch broken ONNX uploads, missing external weight files ( / ), invalid  schemas, or shell/Python syntax errors **before** a commit ever triggers a heavy RISC-V cross-compilation in CI, the kit includes  (which also runs automatically as Step 0 of  and aligns with upstream [IREE's ](https://github.com/iree-org/iree/blob/main/.pre-commit-config.yaml)):

1. **Install as a Local Git Pre-Commit Hook (One-Time Setup)**:
   
2. **Run Manually or as Step 0 in Any CI Pipeline**:
   
3. **What It Checks in Under 3 Seconds**:
   - **Tier Identification Check**: Verifies every  file under  is properly classified as  or  (via folder path or ).
   - **External Weights Presence Check**: Parses the ONNX protobuf header () and verifies that any external tensor file referenced by the model (such as  or ) actually exists in the folder so developers never commit an  file while forgetting to  its companion weights.
   - **Metadata & Script Syntax Check**: Validates  fields (, , RVV  flag) and runs  and  across .

---

## 7. Deep Dive: How Inputs, Separate/External Weights, and QEMU RVV Execution Work

### A. How ONNX Input Files Are Resolved (Custom Inputs vs. Seeded Auto-Generation)

For every model directory under `tests/onnx_models/<stable|nightly>/<model_name>/`, `03_ort_vs_iree_numpy.py prepare` resolves each input tensor in the ONNX graph using the following priority order:

| Priority | Input Source in Model Folder | How the Pipeline Handles It |
| :--- | :--- | :--- |
| **1. Dedicated `.npy` Input / Weight File** | `<input_name>.npy`, `input_0.npy`, `inputs/<input_name>.npy`, or `weights/<input_name>.npy` | Loaded directly via `np.load()`, saved to `inputs/input_<idx>.npy`, and fed identically to both ONNX Runtime and `iree-run-module --input=@.../input_<idx>.npy` |
| **2. Multi-Tensor `.npz` Archive** | `inputs.npz` or `weights.npz` | Matches tensor keys by `<input_name>`, `input_<idx>`, or `arr_<idx>` and extracts each into `inputs/input_<idx>.npy` |
| **3. Standard ONNX Model Zoo `.pb` Tensor** | `test_data_set_0/input_0.pb` | Parses `onnx.TensorProto` via `onnx.numpy_helper.to_array()`, converts it to `inputs/input_0.npy`, and feeds both runtimes |
| **4. `meta.json` Shape Spec or Graph Signature** | `"inputs": ["1x3x224x224xf32"]` (or no input file present) | Generates a deterministic seeded NumPy tensor (`seed: 42`) matching the graph's exact shape and dtype so both ONNX Runtime and IREE still run on identical inputs |

### B. How All 3 ONNX Weight / Parameter Architectures Are Supported

Real-world ONNX models store weights in three distinct ways—all three are supported automatically:

1. **Architecture 1 — Embedded Weights (Single `.onnx` File < 2 GB)**:
   - All weight initializers live inside `model.onnx`. Both ONNX Runtime and [`iree-import-onnx`](https://iree.dev/guides/ml-frameworks/onnx/) read `model.onnx` directly.
2. **Architecture 2 — External ONNX Protobuf Data Files (`model.onnx.data`, `.weights`, `.bin`)**:
   - The `.onnx` file stores only the graph topology and relative file pointers to external weight files in the same folder.
   - **How we handle it**: Both `03_ort_vs_iree_numpy.py` (for ONNX Runtime) and `04_run_single_onnx_model.sh` (for `iree-import-onnx`) `cd` into the model's directory (`ONNX_MODEL_DIR`) before loading `model.onnx`, and `00_pre_commit_check.sh` parses the ONNX protobuf header before commit to guarantee every referenced external weight file is present in Git.
3. **Architecture 3 — Separate / Decoupled Weights (Weightless Graph + Independent Weight Files or IREE `.irpa` Parameter Archives)**:
   - If a model exports weights as **separate graph inputs** (for example, in `weights.npz` or `weights/<tensor_name>.npy`), `03_ort_vs_iree_numpy.py` automatically matches each weight tensor by name, packs it into the ordered `input_<idx>.npy` list, and passes it to both ONNX Runtime and `iree-run-module`.
   - If a model uses a decoupled **IREE Parameter Archive** (`.irpa`, `.safetensors`, or `.gguf`), `04_run_single_onnx_model.sh` passes `--parameters=${ONNX_PARAM_ARCHIVE}` to `iree-run-module` (and exports `ONNX_WEIGHTS_PATHS` / `ONNX_PARAM_ARCHIVE` to your custom script).

### C. Are We Testing IREE on QEMU? How the Execution & NumPy Comparison Works End-to-End

**Yes—by default on standard `x86_64` Linux CI servers, IREE's compiled RISC-V 64 RVV code is executed on `qemu-riscv64` with RVV 1.0 vector emulation enabled** (and can be switched to a physical RISC-V 64 board with a single environment variable):

1. **Cross-Compilation to RISC-V 64 RVV Machine Code (on `x86_64` Host)**:
   - `iree-compile` compiles the imported `.mlir` file into `<model>_riscv64_rvv.vmfb` using `--iree-llvmcpu-target-triple=riscv64-unknown-linux-gnu`, `--iree-llvmcpu-target-cpu-features="+m,+a,+f,+d,+v,+zvl256b"`, `--iree-opt-data-tiling`, and `--iree-llvmcpu-enable-ukernels=all`.
   - Inside that `.vmfb` file is an embedded `riscv64` ELF shared library containing actual RISC-V Vector (`rvv`) instructions and inlined RISC-V 64 microkernels.
2. **Execution Inside `qemu-riscv64` (or Physical RISC-V Silicon)**:
   - Because the `x86_64` CI host cannot natively execute `riscv64` instructions, Module 04 invokes the cross-compiled RISC-V binary (`build-riscv64-rvv/tools/iree-run-module`) under **QEMU User-Mode Emulation** ([IREE RISC-V Guide](https://iree.dev/building-from-source/riscv/)):
     ```bash
     qemu-riscv64 -cpu rv64,v=true,vlen=256,vext_spec=v1.0 \
       -L /opt/riscv/sysroot \
       ./build-riscv64-rvv/tools/iree-run-module \
       --device=local-task \
       --module=model_riscv64_rvv.vmfb \
       --function=main_graph \
       --input=@/path/to/inputs/input_0.npy \
       --output=@/path/to/iree_outputs/iree_output_0.npy
     ```
   - `qemu-riscv64 -cpu rv64,v=true,vlen=256,vext_spec=v1.0` emulates a 64-bit RISC-V CPU with the RVV 1.0 vector unit (`VLEN=256`). It loads `input_0.npy` from disk, executes every RVV vector dispatch, and writes the resulting output tensor buffer directly to `iree_outputs/iree_output_0.npy`.
   - **Running on a Physical RISC-V Board**: If your CI/CD team attaches a self-hosted physical RISC-V 64 RVV board (such as SpacemiT K1 / Banana Pi BPI-F3), setting `QEMU_RISCV64_BIN=""` in `ci/riscv_rvv/config.env` bypasses QEMU and runs `iree-run-module` directly on the RISC-V hardware.
3. **Final NumPy Comparison (`ort_output_0.npy` vs. `iree_output_0.npy`)**:
   - Once `iree-run-module` finishes writing `iree_output_0.npy`, `03_ort_vs_iree_numpy.py compare` loads both `ort_output_0.npy` (produced by ONNX Runtime) and `iree_output_0.npy` (produced by IREE on `qemu-riscv64`) into NumPy and verifies `np.allclose(ort_arr, iree_arr, rtol=rtol, atol=atol)`.

---

## 8. Does Stock `riscv_test.sh` Test RVV `ukernel`? (Why We Modified `riscv_test.sh` & Why It Is Essential)

### A. Does a Stock `riscv_test.sh` Actually Test RVV Microkernels (`ukernel`)?

**Not reliably—and often not at all**, due to three subtleties in how IREE's CMake/CTest and RISC-V flags work:

1. **The `driver=local-task` Label Trap Skips `ukernel` Completely**:
   - In IREE's build tree, the standalone microkernel unit tests (`runtime/src/iree/builtins/ukernel/tools/mmt4d_test`, `pack_test`, `unpack_test`, `query_tile_sizes_test`) are raw C binaries that call the microkernel entry points directly without initializing a HAL driver. Because they do not use a HAL driver, **they do NOT have the `driver=local-task` (or `driver=local-sync`) CTest label**.
   - If a `riscv_test.sh` script filters tests with `-L "driver=local-task"` (or `--label-regex "driver=local-task"`), **CTest skips 100% of the `ukernel` unit tests**.
2. **The `ALLOW_GENERIC_FALLBACK` Trap in `mmt4d_test.c` ([IREE Issue #24576](https://github.com/iree-org/iree/issues/24576))**:
   - Even if `riscv_test.sh` runs `mmt4d_test` without label filtering, the test harness enables `ALLOW_GENERIC_FALLBACK` so it doesn't crash on non-vector CPUs. If `riscv_test.sh` invokes `qemu-riscv64` with default `-cpu rv64` (omitting `v=true,vlen=256,vext_spec=v1.0`), `mmt4d_test` silently executes the scalar C fallback loop and reports `PASSED` without executing a single RVV vector instruction.
3. **Microkernels Are Off by Default on RISC-V in Standard E2E Tests**:
   - Per [IREE Issue #24576 (`getDefaultEnabledUkernels` in `Utils.cpp:204`)](https://github.com/iree-org/iree/issues/24576) and the [IREE RISC-V Guide](https://iree.dev/blog/2026-07-23-running-models-on-risc-v-with-iree/), both `--iree-opt-data-tiling` and `--iree-llvmcpu-enable-ukernels` are **off by default on RISC-V**. Standard `check_llvm-cpu` tests compiled with default flags only test LLVM's generic vectorizer—they never exercise `runtime/src/iree/builtins/ukernel/arch/riscv_64/`.

### B. Why Testing RVV `ukernel` Is Mandatory (4 Engineering Reasons)

1. **It Powers Both MatMul/GEMM and Conv2D Performance on RISC-V**:
   - As documented in the [IREE RISC-V Guide](https://iree.dev/blog/2026-07-23-running-models-on-risc-v-with-iree/), *"Data-tiling together with the `mmt4d` microkernel is the recommended combination on RISC-V... the microkernel path is currently the most stable one."* When combined with `--iree-global-opt-use-im2col-for-convs=true`, **both dense matrix multiplications and 2D convolutions** route through the `mmt4d`, `pack`, and `unpack` RISC-V 64 microkernels.
2. **Catches Register Clobbers, `vsetvli` Bugs & Tail-Padding Errors in < 10 Seconds**:
   - Hand-written RVV microkernels (`mmt4d_riscv_64_v.c`, `mmt4d_riscv_64_zvfh.c`) manually schedule 32 vector registers (`v0`–`v31`), LMUL groupings, and unaligned `(M, N, K)` remainder loops. `mmt4d_test` and `pack_test` sweep hundreds of non-multiple tile boundaries across `f32`, `f16` (`+zvfh`), and `i8->i32` (`s8s8s32`) in seconds.
3. **Prevents Silent Compiler-to-Runtime Tile Drift**:
   - As highlighted in [IREE Issue #24576](https://github.com/iree-org/iree/issues/24576), the compiler's `enumerateMatmulTileRiscv64` (`CPUEncodingExternalModels.cpp:997`) and the runtime's `mmt4d_riscv_64_tiles.inl` must agree on `(type, M0, K0)`. Pairing `ctest -R ukernel` with `e2e_matmul` (`e2e_matmul_cpu_dt_*`) verifies both sides of that contract.
4. **Instant Root-Cause Isolation When an ONNX Model Fails**:
   - If an ONNX model fails `np.allclose` in Stage 4, checking whether `ukernel` passed immediately tells the team if the bug is in low-level RVV kernel math (`ukernel` failed) or high-level graph lowering (`ukernel` passed, ONNX failed).

### C. What We Changed in the Bundled `riscv_test.sh`

We included an updated, drop-in `riscv_test.sh` (at root `riscv_test.sh` and `ci/riscv_rvv/riscv_test.sh`, automatically invoked by `02_run_iree_core_tests.sh`) that runs a two-step sequence:

```bash
# Step 1: Explicitly run RVV ukernel tests WITHOUT any -L driver=* filter
# under QEMU_CPU="rv64,v=true,vlen=256,vext_spec=v1.0"
ctest --test-dir "${BUILD_DIR}"   --tests-regex "ukernel"   --output-on-failure   --parallel "${JOBS}"   --output-junit "${JUNIT_DIR}/junit_riscv_rvv_ukernel.xml"

# Step 2: Run runtime HAL/VM, check_llvm-cpu, and e2e_matmul tests
# (Fast subset on --stage pr, full cross-compiled CTest suite on --stage nightly/stable)
ctest --test-dir "${BUILD_DIR}"   --output-on-failure   --parallel "${JOBS}"   --label-exclude "nokokoro|driver=vulkan|driver=cuda|driver=metal|driver=hip|hostonly"   --exclude-regex "ukernel"   --tests-regex "iree/base|iree/hal|iree/vm|check_llvm-cpu|e2e_matmul"   --output-junit "${JUNIT_DIR}/junit_riscv_target_pr.xml"
```

---

## 9. Python Test Cases in IREE (Built-in Compiler/Runtime Python Tests + `pytest` ONNX Suite)

There are **three categories of Python test cases** in an IREE RISC-V 64 RVV pipeline:

### A. Categories of Python Tests & Where They Run (Host `x86_64` vs. Target `riscv64`)

| Python Test Suite | Location in IREE Repo | Where It Runs | What It Verifies |
| :--- | :--- | :--- | :--- |
| **1. IREE ONNX Importer & Compiler Python Tests** | `compiler/bindings/python/test/**` (including `compiler/bindings/python/test/tools/import_onnx_test.py` from [`pkgci_unit_test.yml`](https://github.com/iree-org/iree/blob/main/.github/workflows/pkgci_unit_test.yml)) | **Host (`build-host`)** (built with `-DIREE_BUILD_PYTHON_BINDINGS=ON` per [IREE Python Bindings Guide](https://iree.dev/building-from-source/getting-started/)) | Verifies that [`iree-import-onnx`](https://iree.dev/guides/ml-frameworks/onnx/) and `iree.compiler` Python bindings properly parse `.onnx` protobufs, external weights, and opsets into MLIR |
| **2. IREE Runtime Python Binding Tests** | `runtime/bindings/python/test/**` (`hal_test.py`, `vm_test.py`, `system_api_test.py`) | **Host (`build-host`)** (not cross-compiled in `build-riscv64-rvv` because the target executes `.vmfb` modules via the standalone C binary `iree-run-module` under `qemu-riscv64` without needing a RISC-V Python interpreter) | Verifies IREE's Python `HalTensor` / NumPy buffer interface on the host |
| **3. Auto-Discovered ONNX Model `pytest` Suite** | `ci/riscv_rvv/test_onnx_models_pytest.py` & `ci/riscv_rvv/discover_and_run_onnx.py` | **Host Python (`pytest` + `onnxruntime` + `numpy`) driving Target (`qemu-riscv64 iree-run-module`)** | Parametrizes every discovered `.onnx` model in `tests/onnx_models/stable/**` and `tests/onnx_models/nightly/**` as a Python test case comparing ONNX Runtime `.npy` outputs against IREE RVV `.npy` outputs |

### B. Exact Commands to Run Python Test Cases

1. **Run IREE's Built-in Compiler & ONNX Importer Python Tests via CTest (Included Automatically in `02_run_iree_core_tests.sh`)**:
   ```bash
   # Runs compiler/bindings/python/test/tools/import_onnx_test.py and MLIR Python API tests:
   ctest --test-dir build-host      -R "compiler/bindings/python"      --output-on-failure -j "$(nproc)"      --output-junit build-ci-artifacts/junit_host_python_bindings.xml
   ```
2. **Run Auto-Discovered ONNX Models via `pytest` (`ci/riscv_rvv/test_onnx_models_pytest.py`)**:
   If your CI/CD team prefers running `pytest` directly for the ONNX model verification stage:
   ```bash
   # Run PR / Stable ONNX models via pytest:
   IREE_ONNX_TIER=pr pytest ci/riscv_rvv/test_onnx_models_pytest.py -v      --junitxml=build-ci-artifacts/junit_pytest_onnx_pr.xml

   # Run Nightly (Stable + Nightly) ONNX models via pytest:
   IREE_ONNX_TIER=nightly pytest ci/riscv_rvv/test_onnx_models_pytest.py -v      --junitxml=build-ci-artifacts/junit_pytest_onnx_nightly.xml
   ```

---

## 10. VME Ukernel CTest Suite: Conv2D, Unbatched MatMul & Combined Conv+MatMul Model (`tests/onnx_models/` Currently Skipped)

> **Current Active Configuration (`RUN_ONNX_MODELS_REGISTRY=0`)**: The `tests/onnx_models/` registry is **skipped by default** for now (re-enable anytime with `--run-onnx-models` or `RUN_ONNX_MODELS_REGISTRY=1`). Instead, the active ONNX verification stage runs the **3-part VME Ukernel CTest Suite** (`ci/riscv_rvv/vme_ukernel_suite/`).

### A. The 3 Generator Files & What They Test

| File | Operation Covered | Dimension & Layer Coverage | Generated CTest File |
| :--- | :--- | :--- | :--- |
| `ci/riscv_rvv/vme_ukernel_suite/gen_conv2d_onnx.py` | **Conv2D** | 10 dimension cases (`1x1` pointwise, `3x3`, `5x5`, `7x7`, strided, batched, and odd shapes like `1x7x19x23` and `1x11x17x17`) routed via `--iree-global-opt-use-im2col-for-convs=true` + `--iree-opt-data-tiling` | `conv2d_tests.cmake` |
| `ci/riscv_rvv/vme_ukernel_suite/gen_matmul_onnx.py` | **MatMul (Unbatched 2D)** | 12 `(M, K, N)` cases (`16x16x16` up to `256x512x256`, GEMV `1x128x64`, skinny `4x256x128`, and odd remainder shapes like `17x33x19`, `13x47x29`, `7x513x31`) | `matmul_tests.cmake` |
| `ci/riscv_rvv/vme_ukernel_suite/gen_conv_matmul_model_onnx.py` | **Combined Conv2D + MatMul Model** | 4 end-to-end CNN+MLP models (`Conv -> Relu -> Conv -> Relu -> GlobalAveragePool -> Flatten -> MatMul -> Add -> Relu -> MatMul -> Add`) across `32x32`, `28x28`, odd `19x23`, and `56x56` inputs | `conv_matmul_model_tests.cmake` |

### B. Flow & Commands for the CI/CD Team

Every test case in `ctest -R "vme_ukernel"` executes `run_vme_ukernel_case.py` in this exact order:
1. **IREE VME Ukernel Path First**: `iree-import-onnx` -> `iree-compile` (`--iree-opt-data-tiling --iree-llvmcpu-enable-ukernels=all --iree-global-opt-use-im2col-for-convs=true --iree-llvmcpu-target-cpu-features="${IREE_VME_CPU_FEATURES}"`) -> `qemu-riscv64 iree-run-module` (saving `iree_output_0.npy`).
2. **ONNX Runtime Second**: Runs `CPUExecutionProvider` on the exact same `input_0.npy` (saving `ort_output_0.npy`).
3. **NumPy Comparison**: Asserts `np.allclose(ort_output_0, iree_output_0, atol=1e-3, rtol=1e-3)` and logs `max_abs_diff`, `RMSE`, and `cosine_similarity`.

```bash
# 1. Generate all 3 ONNX test suites (Conv2D, Unbatched MatMul, Combined Conv+MatMul Model):
python3 ci/riscv_rvv/vme_ukernel_suite/gen_conv2d_onnx.py
python3 ci/riscv_rvv/vme_ukernel_suite/gen_matmul_onnx.py
python3 ci/riscv_rvv/vme_ukernel_suite/gen_conv_matmul_model_onnx.py

# 2. Configure CTest & run all VME ukernel cases (add your VME feature flag to IREE_VME_CPU_FEATURES):
export IREE_VME_CPU_FEATURES="+m,+a,+f,+d,+v,+zvl256b"
cmake -B build-vme-ctest -S ci/riscv_rvv/vme_ukernel_suite
ctest --test-dir build-vme-ctest -R "vme_ukernel" --output-on-failure -j "$(nproc)"
```

