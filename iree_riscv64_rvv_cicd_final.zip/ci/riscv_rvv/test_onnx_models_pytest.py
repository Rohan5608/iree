#!/usr/bin/env python3
"""
Pytest Suite for Auto-Discovered IREE RISC-V 64 (RVV) ONNX Models
=================================================================
Allows developers and the CI/CD team to run all auto-discovered ONNX models
(and their ONNX Runtime vs. IREE RVV NumPy output comparisons) as native
Python `pytest` test cases!

Usage Examples:
  # Run all PR / Stable-tier ONNX models via pytest:
  pytest ci/riscv_rvv/test_onnx_models_pytest.py -k "stable" -v --junitxml=build-ci-artifacts/pytest_onnx.xml

  # Run all Nightly + Stable ONNX models via pytest:
  pytest ci/riscv_rvv/test_onnx_models_pytest.py -v

  # Filter by environment variable IREE_ONNX_TIER (pr | stable | nightly | all):
  IREE_ONNX_TIER=pr pytest ci/riscv_rvv/test_onnx_models_pytest.py -v
"""

import os
import sys
from pathlib import Path
import pytest

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from discover_and_run_onnx import discover_models, run_single_model, OnnxModelCase


def _get_discovered_cases():
    models_root = Path(os.environ.get("ONNX_MODELS_ROOT", "tests/onnx_models"))
    tier = os.environ.get("IREE_ONNX_TIER", "all")
    return discover_models(models_root, tier)


DISCOVERED_CASES = _get_discovered_cases()


@pytest.mark.parametrize(
    "case",
    DISCOVERED_CASES,
    ids=[f"{c.tier}_{c.name}" for c in DISCOVERED_CASES],
)
def test_iree_riscv64_rvv_onnx_model(case: OnnxModelCase):
    """
    Executes an auto-discovered ONNX model (+ companion external/separate weights)
    on both ONNX Runtime (CPUExecutionProvider) and IREE RISC-V 64 RVV (QEMU or Board)
    and asserts that all output NumPy tensors match within (atol, rtol).
    """
    work_dir = Path(os.environ.get("ARTIFACTS_ROOT", "build-ci-artifacts")) / "pytest_onnx"
    pipeline_script = os.environ.get(
        "CUSTOM_PIPELINE_SCRIPT",
        str(SCRIPT_DIR / "modules" / "04_run_single_onnx_model.sh"),
    )
    iree_host_bin = os.environ.get("IREE_HOST_BIN_DIR", "build-host/install/bin")
    iree_riscv_bin = os.environ.get("IREE_RISCV_BIN_DIR", "build-riscv64-rvv/tools")
    qemu_bin = os.environ.get("QEMU_RISCV64_BIN", "qemu-riscv64")
    sysroot = os.environ.get("RISCV_SYSROOT", "/opt/riscv/sysroot")

    res = run_single_model(
        case=case,
        pipeline_script=pipeline_script if Path(pipeline_script).exists() else None,
        work_dir=work_dir,
        iree_host_bin=iree_host_bin,
        iree_riscv_bin=iree_riscv_bin,
        qemu_bin=qemu_bin,
        sysroot=sysroot,
        compare_ort=True,
    )
    assert res["status"] == "PASSED", (
        f"ONNX model '{case.name}' (tier={case.tier}) failed verification "
        f"(exit={res['returncode']}):\n{res.get('output', '')}"
    )
