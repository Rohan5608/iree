#!/usr/bin/env bash
# ==============================================================================
# MASTER CI/CD ENTRYPOINT FOR IREE RISC-V 64 (RVV / VME)
# ==============================================================================
# Usage:
#   ./ci/riscv_rvv/ci_entrypoint.sh --stage pr
#   ./ci/riscv_rvv/ci_entrypoint.sh --stage nightly
#   ./ci/riscv_rvv/ci_entrypoint.sh --stage stable --release-version v1.0.0
#
# Note: `tests/onnx_models/` is skipped by default (RUN_ONNX_MODELS_REGISTRY=0).
#       The active ONNX test stage runs the VME Ukernel CTest Suite:
#         1) gen_conv2d_onnx.py           (Conv2D dimensions)
#         2) gen_matmul_onnx.py           (Unbatched 2D MatMul dimensions)
#         3) gen_conv_matmul_model_onnx.py (Combined Conv2D + MatMul models)
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.env"

STAGE="pr"
RELEASE_VERSION=""
SKIP_BUILD=0
SKIP_CORE_TESTS=0
SKIP_VME_SUITE=0
RUN_ONNX_REGISTRY="${RUN_ONNX_MODELS_REGISTRY:-0}"
PACKAGE_RELEASE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage) STAGE="$2"; shift 2 ;;
    --release-version) RELEASE_VERSION="$2"; PACKAGE_RELEASE=1; shift 2 ;;
    --skip-build) SKIP_BUILD=1; shift ;;
    --skip-core-tests) SKIP_CORE_TESTS=1; shift ;;
    --skip-vme-suite) SKIP_VME_SUITE=1; shift ;;
    --run-onnx-models) RUN_ONNX_REGISTRY=1; shift ;;
    --skip-onnx-models) RUN_ONNX_REGISTRY=0; shift ;;
    --package-release) PACKAGE_RELEASE=1; shift ;;
    *) echo "[ERROR] Unknown flag: $1" >&2; exit 1 ;;
  esac
done

if [[ "${STAGE}" == "nightly" || "${STAGE}" == "stable" ]]; then
  PACKAGE_RELEASE=1
fi

BUILD_TYPE="RelWithDebInfo"
[[ "${STAGE}" == "stable" ]] && BUILD_TYPE="Release"

echo "=============================================================================="
echo "IREE RISC-V 64 (RVV / VME) CI/CD | Stage: ${STAGE^^} | Build: ${BUILD_TYPE}"
echo "  VME Ukernel ONNX CTest Suite : $([[ ${SKIP_VME_SUITE} -eq 0 ]] && echo ENABLED || echo SKIPPED)"
echo "  tests/onnx_models/ Registry  : $([[ ${RUN_ONNX_REGISTRY} -eq 1 ]] && echo ENABLED || echo SKIPPED)"
echo "=============================================================================="

# --- Module 00: Fast Pre-Commit & Integrity Check ---
"${SCRIPT_DIR}/modules/00_pre_commit_check.sh"

# --- Module 01: Build Host Compiler + Cross-Compile RISC-V 64 RVV Runtime ---
if [[ "${SKIP_BUILD}" -eq 0 ]]; then
  "${SCRIPT_DIR}/modules/01_build_iree_rvv.sh" --build-type "${BUILD_TYPE}"
fi

# --- Module 02: Run IREE Core CTest Suites (Lit + RVV ukernels + riscv_test.sh) ---
if [[ "${SKIP_CORE_TESTS}" -eq 0 ]]; then
  "${SCRIPT_DIR}/modules/02_run_iree_core_tests.sh" --stage "${STAGE}"
fi

# --- Module 05: VME Ukernel CTest Suite (Conv2D + Unbatched MatMul + Hybrid Model) ---
if [[ "${SKIP_VME_SUITE}" -eq 0 && "${RUN_VME_UKERNEL_ONNX_SUITE:-1}" -eq 1 ]]; then
  echo "==> [Module 05] Generating VME Ukernel ONNX Cases (Conv2D, MatMul, Conv+MatMul Model)..."
  python3 "${SCRIPT_DIR}/vme_ukernel_suite/gen_conv2d_onnx.py"
  python3 "${SCRIPT_DIR}/vme_ukernel_suite/gen_matmul_onnx.py"
  python3 "${SCRIPT_DIR}/vme_ukernel_suite/gen_conv_matmul_model_onnx.py"

  VME_CTEST_DIR="${ARTIFACTS_ROOT}/build-vme-ctest"
  export IREE_HOST_BIN_DIR="$(realpath "${HOST_INSTALL_DIR}/bin")"
  export IREE_RISCV_BIN_DIR="$(realpath "${RISCV_BUILD_DIR}/tools")"

  cmake -B "${VME_CTEST_DIR}" -S "${SCRIPT_DIR}/vme_ukernel_suite"

  VME_LABEL_FILTER=""
  if [[ "${STAGE}" == "pr" || "${STAGE}" == "stable" ]]; then
    VME_LABEL_FILTER="-L stable"
  fi

  ctest --test-dir "${VME_CTEST_DIR}"     -R "vme_ukernel" ${VME_LABEL_FILTER}     --output-on-failure -j "$(nproc || echo 4)"     --output-junit "${ARTIFACTS_ROOT}/junit_vme_ukernel_${STAGE}.xml"
fi

# --- Optional: tests/onnx_models/ Registry (Skipped by default for now) ---
if [[ "${RUN_ONNX_REGISTRY}" -eq 1 ]]; then
  python3 "${SCRIPT_DIR}/discover_and_run_onnx.py"     --models-root "${ONNX_MODELS_ROOT}"     --tier "${STAGE}"     --iree-host-bin "$(realpath "${HOST_INSTALL_DIR}/bin")"     --iree-riscv-bin "$(realpath "${RISCV_BUILD_DIR}/tools")"     --pipeline-script "${SCRIPT_DIR}/modules/04_run_single_onnx_model.sh"     --work-dir "${ARTIFACTS_ROOT}/onnx_${STAGE}"     --junit-xml "${ARTIFACTS_ROOT}/onnx_${STAGE}/junit_onnx_${STAGE}.xml"     --run
else
  echo "==> [INFO] Skipping tests/onnx_models/ registry (RUN_ONNX_MODELS_REGISTRY=0)."
fi

# --- Release Packaging (Nightly & Stable Only) ---
if [[ "${PACKAGE_RELEASE}" -eq 1 ]]; then
  if [[ -z "${RELEASE_VERSION}" ]]; then
    DATE_TAG="$(date -u +%Y%m%d)"
    RELEASE_VERSION="${STAGE}-riscv64-rvv-${DATE_TAG}"
  fi
  PKG_DIR="${ARTIFACTS_ROOT}/dist/iree-${RELEASE_VERSION}"
  mkdir -p "${PKG_DIR}/host-bin" "${PKG_DIR}/riscv64-bin"
  cp "${HOST_INSTALL_DIR}/bin/iree-compile" "${PKG_DIR}/host-bin/" || true
  cp "${HOST_INSTALL_DIR}/bin/iree-import-onnx" "${PKG_DIR}/host-bin/" || true
  cp "${RISCV_BUILD_DIR}/tools/iree-run-module" "${PKG_DIR}/riscv64-bin/" || true
  cp "${RISCV_BUILD_DIR}/tools/iree-benchmark-module" "${PKG_DIR}/riscv64-bin/" || true
  TARBALL="${ARTIFACTS_ROOT}/iree-${RELEASE_VERSION}.tar.gz"
  tar -czvf "${TARBALL}" -C "${ARTIFACTS_ROOT}/dist" "iree-${RELEASE_VERSION}"
  sha256sum "${TARBALL}" > "${TARBALL}.sha256"
  echo "==> Packaged Release Artifact: ${TARBALL} (+ .sha256)"
fi

echo "==> [SUCCESS] IREE RISC-V 64 (RVV / VME) CI/CD Stage '${STAGE}' Completed!"
