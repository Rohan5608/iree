#!/usr/bin/env python3
"""
VME Ukernel ONNX Test Case Generator & CTest Harness Builder
============================================================
Generates ONNX models and CTest definitions for testing IREE's RISC-V VME
ukernel path across three operation categories:
  1. Matrix Multiplication (MatMul) across many (M, K, N) & batched dimensions
  2. 2D Convolution (Conv2D) across many (N, C, H, W, K_out, kH, kW, stride, pad)
     routed via --iree-global-opt-use-im2col-for-convs=true + data-tiling + ukernels
  3. Combined Conv2D + MatMul Hybrid Model (Conv2D -> Relu -> GlobalAvgPool -> MatMul)

Also generates `CTestTestfile.cmake` (or `vme_ukernel_tests.cmake`) so every
single dimension test case can be executed and reported via `ctest`:
  ctest --test-dir build-riscv64-rvv -R "vme_ukernel" --output-on-failure -j $(nproc)
"""

import argparse
import json
import sys
from pathlib import Path
from typing import List, Dict, Any

# ------------------------------------------------------------------------------
# Default Dimension Sweeps (Add or edit any dimensions here!)
# ------------------------------------------------------------------------------
MATMUL_CASES: List[Dict[str, Any]] = [
    # Aligned power-of-two tiles
    {"name": "matmul_f32_16x16x16", "M": 16, "K": 16, "N": 16, "dtype": "float32", "tier": "stable"},
    {"name": "matmul_f32_32x64x32", "M": 32, "K": 64, "N": 32, "dtype": "float32", "tier": "stable"},
    {"name": "matmul_f32_64x128x64", "M": 64, "K": 128, "N": 64, "dtype": "float32", "tier": "stable"},
    {"name": "matmul_f32_128x256x128", "M": 128, "K": 256, "N": 128, "dtype": "float32", "tier": "nightly"},
    # Non-multiple / odd dimensions to stress VME remainder & tail-padding loops
    {"name": "matmul_f32_17x33x19_odd", "M": 17, "K": 33, "N": 19, "dtype": "float32", "tier": "stable"},
    {"name": "matmul_f32_1x128x64_gemv", "M": 1, "K": 128, "N": 64, "dtype": "float32", "tier": "stable"},
    {"name": "matmul_f32_7x513x31_skinny", "M": 7, "K": 513, "N": 31, "dtype": "float32", "tier": "nightly"},
    # Batched MatMul
    {"name": "bmm_f32_4x32x64x32", "B": 4, "M": 32, "K": 64, "N": 32, "dtype": "float32", "tier": "stable"},
    {"name": "bmm_f32_8x19x45x23_odd", "B": 8, "M": 19, "K": 45, "N": 23, "dtype": "float32", "tier": "nightly"},
]

CONV2D_CASES: List[Dict[str, Any]] = [
    # Standard 3x3 & 1x1 convolutions
    {"name": "conv2d_f32_1x3x32x32_k3s1p1", "N": 1, "Cin": 3, "H": 32, "W": 32, "Cout": 16, "kH": 3, "kW": 3, "stride": 1, "pad": 1, "tier": "stable"},
    {"name": "conv2d_f32_1x16x28x28_k3s1p1", "N": 1, "Cin": 16, "H": 28, "W": 28, "Cout": 32, "kH": 3, "kW": 3, "stride": 1, "pad": 1, "tier": "stable"},
    {"name": "conv2d_f32_1x32x28x28_k1s1p0_pw", "N": 1, "Cin": 32, "H": 28, "W": 28, "Cout": 64, "kH": 1, "kW": 1, "stride": 1, "pad": 0, "tier": "stable"},
    {"name": "conv2d_f32_1x3x64x64_k3s2p1", "N": 1, "Cin": 3, "H": 64, "W": 64, "Cout": 32, "kH": 3, "kW": 3, "stride": 2, "pad": 1, "tier": "stable"},
    # Odd / non-multiple spatial & channel dimensions to stress im2col + VME ukernel packing
    {"name": "conv2d_f32_1x7x19x23_k3s1p0_odd", "N": 1, "Cin": 7, "H": 19, "W": 23, "Cout": 13, "kH": 3, "kW": 3, "stride": 1, "pad": 0, "tier": "stable"},
    {"name": "conv2d_f32_2x64x56x56_k3s1p1_batched", "N": 2, "Cin": 64, "H": 56, "W": 56, "Cout": 64, "kH": 3, "kW": 3, "stride": 1, "pad": 1, "tier": "nightly"},
    {"name": "conv2d_f32_1x3x224x224_k7s2p3_resnet_stem", "N": 1, "Cin": 3, "H": 224, "W": 224, "Cout": 64, "kH": 7, "kW": 7, "stride": 2, "pad": 3, "tier": "nightly"},
]

HYBRID_MODEL_CASES: List[Dict[str, Any]] = [
    {
        "name": "model_conv_matmul_f32_1x3x32x32",
        "N": 1, "Cin": 3, "H": 32, "W": 32, "Cout": 16, "kH": 3, "kW": 3, "hidden": 32, "num_classes": 10,
        "tier": "stable",
    },
    {
        "name": "model_conv_matmul_f32_1x16x56x56",
        "N": 1, "Cin": 16, "H": 56, "W": 56, "Cout": 64, "kH": 3, "kW": 3, "hidden": 128, "num_classes": 100,
        "tier": "nightly",
    },
]


def build_matmul_onnx(cfg: Dict[str, Any], out_path: Path) -> Dict[str, Any]:
    import numpy as np
    import onnx
    from onnx import helper, TensorProto

    rng = np.random.default_rng(42)
    B = cfg.get("B")
    M, K, N = cfg["M"], cfg["K"], cfg["N"]

    a_shape = [B, M, K] if B else [M, K]
    b_shape = [B, K, N] if B else [K, N]
    y_shape = [B, M, N] if B else [M, N]

    b_weights = rng.uniform(-0.5, 0.5, size=b_shape).astype(np.float32)
    b_init = helper.make_tensor("B_weights", TensorProto.FLOAT, b_shape, b_weights.flatten().tolist())

    inp = helper.make_tensor_value_info("A", TensorProto.FLOAT, a_shape)
    out = helper.make_tensor_value_info("Y", TensorProto.FLOAT, y_shape)

    node = helper.make_node("MatMul", inputs=["A", "B_weights"], outputs=["Y"])
    graph = helper.make_graph([node], cfg["name"], [inp], [out], initializer=[b_init])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    onnx.save(model, str(out_path))
    return {"op": "matmul", "inputs": [f"{'x'.join(map(str, a_shape))}xf32"], **cfg}


def build_conv2d_onnx(cfg: Dict[str, Any], out_path: Path) -> Dict[str, Any]:
    import numpy as np
    import onnx
    from onnx import helper, TensorProto

    rng = np.random.default_rng(42)
    N, Cin, H, W = cfg["N"], cfg["Cin"], cfg["H"], cfg["W"]
    Cout, kH, kW = cfg["Cout"], cfg["kH"], cfg["kW"]
    stride, pad = cfg["stride"], cfg["pad"]
    Hout = (H + 2 * pad - kH) // stride + 1
    Wout = (W + 2 * pad - kW) // stride + 1

    w_arr = rng.uniform(-0.25, 0.25, size=(Cout, Cin, kH, kW)).astype(np.float32)
    b_arr = rng.uniform(-0.1, 0.1, size=(Cout,)).astype(np.float32)

    w_init = helper.make_tensor("W", TensorProto.FLOAT, [Cout, Cin, kH, kW], w_arr.flatten().tolist())
    b_init = helper.make_tensor("B", TensorProto.FLOAT, [Cout], b_arr.flatten().tolist())

    inp = helper.make_tensor_value_info("X", TensorProto.FLOAT, [N, Cin, H, W])
    out = helper.make_tensor_value_info("Y", TensorProto.FLOAT, [N, Cout, Hout, Wout])

    node = helper.make_node(
        "Conv",
        inputs=["X", "W", "B"],
        outputs=["Y"],
        kernel_shape=[kH, kW],
        strides=[stride, stride],
        pads=[pad, pad, pad, pad],
    )
    graph = helper.make_graph([node], cfg["name"], [inp], [out], initializer=[w_init, b_init])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    onnx.save(model, str(out_path))
    return {"op": "conv2d", "inputs": [f"{N}x{Cin}x{H}x{W}xf32"], **cfg}


def build_conv_matmul_hybrid_onnx(cfg: Dict[str, Any], out_path: Path) -> Dict[str, Any]:
    """Builds an ONNX model containing Conv2D -> Relu -> GlobalAveragePool -> Flatten -> MatMul -> Add -> MatMul."""
    import numpy as np
    import onnx
    from onnx import helper, TensorProto

    rng = np.random.default_rng(42)
    N, Cin, H, W = cfg["N"], cfg["Cin"], cfg["H"], cfg["W"]
    Cout, kH, kW = cfg["Cout"], cfg["kH"], cfg["kW"]
    hidden, num_classes = cfg["hidden"], cfg["num_classes"]

    conv_w = rng.uniform(-0.2, 0.2, size=(Cout, Cin, kH, kW)).astype(np.float32)
    conv_b = rng.uniform(-0.05, 0.05, size=(Cout,)).astype(np.float32)
    fc1_w = rng.uniform(-0.2, 0.2, size=(Cout, hidden)).astype(np.float32)
    fc1_b = rng.uniform(-0.05, 0.05, size=(hidden,)).astype(np.float32)
    fc2_w = rng.uniform(-0.2, 0.2, size=(hidden, num_classes)).astype(np.float32)
    fc2_b = rng.uniform(-0.05, 0.05, size=(num_classes,)).astype(np.float32)

    initializers = [
        helper.make_tensor("conv_w", TensorProto.FLOAT, [Cout, Cin, kH, kW], conv_w.flatten().tolist()),
        helper.make_tensor("conv_b", TensorProto.FLOAT, [Cout], conv_b.flatten().tolist()),
        helper.make_tensor("fc1_w", TensorProto.FLOAT, [Cout, hidden], fc1_w.flatten().tolist()),
        helper.make_tensor("fc1_b", TensorProto.FLOAT, [hidden], fc1_b.flatten().tolist()),
        helper.make_tensor("fc2_w", TensorProto.FLOAT, [hidden, num_classes], fc2_w.flatten().tolist()),
        helper.make_tensor("fc2_b", TensorProto.FLOAT, [num_classes], fc2_b.flatten().tolist()),
    ]

    nodes = [
        helper.make_node("Conv", ["X", "conv_w", "conv_b"], ["conv_out"], kernel_shape=[kH, kW], strides=[1, 1], pads=[1, 1, 1, 1]),
        helper.make_node("Relu", ["conv_out"], ["relu1"]),
        helper.make_node("GlobalAveragePool", ["relu1"], ["gap_out"]),
        helper.make_node("Flatten", ["gap_out"], ["flat_out"], axis=1),
        helper.make_node("MatMul", ["flat_out", "fc1_w"], ["fc1_mm"]),
        helper.make_node("Add", ["fc1_mm", "fc1_b"], ["fc1_out"]),
        helper.make_node("Relu", ["fc1_out"], ["relu2"]),
        helper.make_node("MatMul", ["relu2", "fc2_w"], ["fc2_mm"]),
        helper.make_node("Add", ["fc2_mm", "fc2_b"], ["logits"]),
    ]

    inp = helper.make_tensor_value_info("X", TensorProto.FLOAT, [N, Cin, H, W])
    out = helper.make_tensor_value_info("logits", TensorProto.FLOAT, [N, num_classes])
    graph = helper.make_graph(nodes, cfg["name"], [inp], [out], initializer=initializers)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    onnx.save(model, str(out_path))
    return {"op": "conv_matmul_model", "inputs": [f"{N}x{Cin}x{H}x{W}xf32"], **cfg}


def emit_ctest_cmake(cases: List[Dict[str, Any]], out_cmake: Path, runner_script: Path, onnx_root: Path) -> None:
    """Writes a CMake / CTestTestfile.cmake file registering every dimension case as a CTest test."""
    lines = [
        "# Auto-generated CTest Suite for RISC-V VME Ukernel (MatMul, Conv2D, Conv+MatMul Model)",
        "# Runs each case through: 1) IREE VME Ukernel Path -> 2) ONNX Runtime -> 3) NumPy Comparison",
        "",
    ]
    for c in cases:
        test_name = f"vme_ukernel_{c['tier']}_{c['name']}"
        onnx_file = (onnx_root / c["op"] / f"{c['name']}.onnx").as_posix()
        lines.append(
            f'add_test(NAME {test_name}\n'
            f'  COMMAND "${{Python3_EXECUTABLE}}" "{runner_script.as_posix()}"\n'
            f'    --name "{c["name"]}"\n'
            f'    --op "{c["op"]}"\n'
            f'    --onnx "{onnx_file}"\n'
            f'    --atol 1e-3 --rtol 1e-3\n'
            f')'
        )
        lines.append(
            f'set_tests_properties({test_name} PROPERTIES\n'
            f'  LABELS "vme;ukernel;rvv;{c["op"]};{c["tier"]}"\n'
            f')'
        )
    out_cmake.parent.mkdir(parents=True, exist_ok=True)
    out_cmake.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate MatMul, Conv2D & Hybrid ONNX cases + CTest definitions for VME ukernel testing")
    parser.add_argument("--out-dir", type=Path, default=Path("tests/vme_ukernel_onnx/generated"),
                        help="Directory to write generated .onnx files and manifest.json")
    parser.add_argument("--emit-ctest-cmake", type=Path, default=Path("ci/riscv_rvv/vme_ukernel_suite/vme_ukernel_tests.cmake"),
                        help="Output CMake file containing add_test() entries for CTest")
    args = parser.parse_args()

    all_cases: List[Dict[str, Any]] = []

    for cfg in MATMUL_CASES:
        onnx_path = args.out_dir / "matmul" / f"{cfg['name']}.onnx"
        all_cases.append(build_matmul_onnx(cfg, onnx_path))

    for cfg in CONV2D_CASES:
        onnx_path = args.out_dir / "conv2d" / f"{cfg['name']}.onnx"
        all_cases.append(build_conv2d_onnx(cfg, onnx_path))

    for cfg in HYBRID_MODEL_CASES:
        onnx_path = args.out_dir / "conv_matmul_model" / f"{cfg['name']}.onnx"
        all_cases.append(build_conv_matmul_hybrid_onnx(cfg, onnx_path))

    args.out_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = args.out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(all_cases, indent=2), encoding="utf-8")

    runner_script = Path(__file__).resolve().parent / "run_vme_ukernel_case.py"
    emit_ctest_cmake(all_cases, args.emit_ctest_cmake, runner_script, args.out_dir.resolve())

    print(f"Generated {len(all_cases)} VME ukernel ONNX test cases in {args.out_dir}")
    print(f"Generated CTest definitions in {args.emit_ctest_cmake}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
