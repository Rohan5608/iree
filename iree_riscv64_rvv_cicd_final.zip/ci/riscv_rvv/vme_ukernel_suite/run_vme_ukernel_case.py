#!/usr/bin/env python3
"""
CTest Runner for a Single VME Ukernel Test Case (MatMul / Conv2D / Hybrid Model)
================================================================================
Execution Order (as requested):
  1. Generate deterministic NumPy input tensor (input_0.npy).
  2. FIRST: Run through the IREE RISC-V 64 VME Ukernel Path:
       - iree-import-onnx
       - iree-compile with --iree-opt-data-tiling, --iree-llvmcpu-enable-ukernels=all,
         --iree-global-opt-use-im2col-for-convs=true (routes Conv2D -> im2col + mmt4d),
         and your VME CPU features (IREE_VME_CPU_FEATURES)
       - (Optional --verify-ukernel-ir) Asserts iree_codegen.ukernel.mmt4d was emitted
       - Execute via qemu-riscv64 iree-run-module -> saves iree_output_0.npy
  3. THEN: Run the exact same input_0.npy through ONNX Runtime (CPUExecutionProvider)
       -> saves ort_output_0.npy
  4. Compare iree_output_0.npy vs. ort_output_0.npy using NumPy np.allclose(atol, rtol)
     and print full accuracy metrics (max_abs_diff, mean_abs_diff, RMSE, cosine_sim).
"""

import argparse
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path

import numpy as np

SUITE_DIR = Path(__file__).resolve().parent
MODULES_DIR = SUITE_DIR.parent / "modules"
if str(MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(MODULES_DIR))

from importlib.machinery import SourceFileLoader
cmp_mod = SourceFileLoader("ort_vs_iree_numpy", str(MODULES_DIR / "03_ort_vs_iree_numpy.py")).load_module()


def run_cmd(cmd, label: str) -> str:
    print(f"==> [{label}] $ {' '.join(shlex.quote(str(c)) for c in cmd)}")
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if proc.returncode != 0:
        print(proc.stdout, file=sys.stderr)
        raise RuntimeError(f"Step '{label}' failed with exit code {proc.returncode}")
    return proc.stdout


def main() -> int:
    parser = argparse.ArgumentParser(description="Run single VME ukernel ONNX test case: IREE VME -> ORT -> NumPy Compare")
    parser.add_argument("--name", required=True, help="Test case name")
    parser.add_argument("--op", required=True, choices=["matmul", "conv2d", "conv_matmul_model"], help="Operation category")
    parser.add_argument("--onnx", type=Path, required=True, help="Path to .onnx file")
    parser.add_argument("--work-dir", type=Path, default=Path("build-ci-artifacts/vme_ukernel_suite"))
    parser.add_argument("--iree-host-bin", default=os.environ.get("IREE_HOST_BIN_DIR", "build-host/install/bin"))
    parser.add_argument("--iree-riscv-bin", default=os.environ.get("IREE_RISCV_BIN_DIR", "build-riscv64-rvv/tools"))
    parser.add_argument("--qemu-bin", default=os.environ.get("QEMU_RISCV64_BIN", "qemu-riscv64"))
    parser.add_argument("--qemu-cpu", default=os.environ.get("QEMU_VME_CPU_ARGS", "rv64,v=true,vlen=256,vext_spec=v1.0"))
    parser.add_argument("--sysroot", default=os.environ.get("RISCV_SYSROOT", "/opt/riscv/sysroot"))
    parser.add_argument("--vme-features", default=os.environ.get("IREE_VME_CPU_FEATURES", "+m,+a,+f,+d,+v,+zvl256b"))
    parser.add_argument("--verify-ukernel-ir", action="store_true",
                        help="Verify compiled dispatch IR contains iree_codegen.ukernel.mmt4d (no silent fallback)")
    parser.add_argument("--atol", type=float, default=1e-3)
    parser.add_argument("--rtol", type=float, default=1e-3)
    args = parser.parse_args()

    case_dir = args.work_dir / args.op / args.name
    inputs_dir = case_dir / "inputs"
    iree_out_dir = case_dir / "iree_outputs"
    ort_out_dir = case_dir / "ort_outputs"
    for d in (case_dir, inputs_dir, iree_out_dir, ort_out_dir):
        d.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------------------------
    # STEP 0: Generate deterministic NumPy inputs matching the ONNX graph
    # --------------------------------------------------------------------------
    import onnxruntime as ort
    sess = ort.InferenceSession(str(args.onnx), providers=["CPUExecutionProvider"])
    rng = np.random.default_rng(42)
    feed_dict = {}
    input_npy_paths = []
    for idx, inp_meta in enumerate(sess.get_inputs()):
        shape = tuple(int(d) if isinstance(d, int) and d > 0 else 1 for d in (inp_meta.shape or [1]))
        np_dtype = cmp_mod.ORT_TYPE_TO_NP.get(inp_meta.type, np.float32)
        arr = cmp_mod.make_random_array(shape, np_dtype, rng)
        npy_path = inputs_dir / f"input_{idx}.npy"
        np.save(npy_path, arr)
        feed_dict[inp_meta.name] = arr
        input_npy_paths.append(npy_path)

    output_names = [o.name for o in sess.get_outputs()]
    iree_output_paths = [iree_out_dir / f"iree_output_{i}.npy" for i in range(len(output_names))]

    # --------------------------------------------------------------------------
    # STEP 1 (FIRST): Compile & Run via IREE RISC-V 64 VME Ukernel Path
    # --------------------------------------------------------------------------
    mlir_path = case_dir / f"{args.name}.mlir"
    vmfb_path = case_dir / f"{args.name}_vme.vmfb"

    iree_import_onnx = str(Path(args.iree_host_bin) / "iree-import-onnx") if args.iree_host_bin else "iree-import-onnx"
    iree_compile = str(Path(args.iree_host_bin) / "iree-compile") if args.iree_host_bin else "iree-compile"
    iree_run_module = str(Path(args.iree_riscv_bin) / "iree-run-module") if args.iree_riscv_bin else "iree-run-module"

    run_cmd([iree_import_onnx, str(args.onnx), "--opset-version", "17", "-o", str(mlir_path)], "1A. ONNX -> MLIR")

    compile_cmd = [
        iree_compile,
        str(mlir_path),
        "--iree-hal-target-device=local",
        "--iree-hal-local-target-device-backends=llvm-cpu",
        "--iree-llvmcpu-target-triple=riscv64-unknown-linux-gnu",
        "--iree-llvmcpu-target-abi=lp64d",
        f"--iree-llvmcpu-target-cpu-features={args.vme_features}",
        "--riscv-v-fixed-length-vector-lmul-max=8",
        "--iree-opt-data-tiling",
        "--iree-llvmcpu-enable-ukernels=all",
        "--iree-global-opt-use-im2col-for-convs=true",
    ]
    if args.verify_ukernel_ir:
        dump_dir = case_dir / "ir_dump"
        dump_dir.mkdir(parents=True, exist_ok=True)
        compile_cmd.append(f"--iree-hal-dump-executable-intermediates-to={dump_dir}")

    compile_cmd.extend(["-o", str(vmfb_path)])
    run_cmd(compile_cmd, "1B. IREE VME Ukernel Compile")

    if args.verify_ukernel_ir:
        ir_files = list((case_dir / "ir_dump").rglob("*.mlir"))
        found_ukernel = any("ukernel.mmt4d" in f.read_text(encoding="utf-8", errors="ignore") for f in ir_files)
        if not found_ukernel:
            raise RuntimeError(f"[FAIL] Silent fallback detected! 'ukernel.mmt4d' was NOT emitted in IR for {args.name}.")
        print("==> [IR CHECK] Verified 'iree_codegen.ukernel.mmt4d' emitted in dispatch IR!")

    run_module_cmd = []
    if args.qemu_bin:
        run_module_cmd.extend([args.qemu_bin, "-cpu", args.qemu_cpu])
        if args.sysroot:
            run_module_cmd.extend(["-L", args.sysroot])
    run_module_cmd.extend([
        iree_run_module,
        "--device=local-task",
        f"--module={vmfb_path}",
        "--function=main_graph",
        *[f"--input=@{p}" for p in input_npy_paths],
        *[f"--output=@{p}" for p in iree_output_paths],
    ])
    run_cmd(run_module_cmd, "1C. IREE VME Target Execution (QEMU / Board)")

    # --------------------------------------------------------------------------
    # STEP 2 (THEN): Run ONNX Runtime on the Exact Same Input .npy Tensors
    # --------------------------------------------------------------------------
    print(f"==> [2. ONNX Runtime] Running golden reference for '{args.name}'...")
    ort_results = sess.run(output_names, feed_dict)
    ort_output_paths = []
    for idx, arr in enumerate(ort_results):
        p = ort_out_dir / f"ort_output_{idx}.npy"
        np.save(p, np.asarray(arr))
        ort_output_paths.append(p)

    # --------------------------------------------------------------------------
    # STEP 3: Compare IREE VME Ukernel Output vs. ONNX Runtime Golden Output
    # --------------------------------------------------------------------------
    ok, metrics, log_str = cmp_mod.compare_numpy_outputs(
        ort_output_paths=ort_output_paths,
        iree_output_paths=iree_output_paths,
        atol=args.atol,
        rtol=args.rtol,
    )
    print(log_str)
    (case_dir / "comparison_report.json").write_text(
        json.dumps({"case": args.name, "op": args.op, "status": "PASSED" if ok else "FAILED", "outputs": metrics}, indent=2),
        encoding="utf-8",
    )
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
