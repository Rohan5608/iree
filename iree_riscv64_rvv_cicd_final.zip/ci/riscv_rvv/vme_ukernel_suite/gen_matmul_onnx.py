#!/usr/bin/env python3
"""
File 2: Unbatched 2D MatMul (M x K * K x N) ONNX Test Case Generator & CTest Harness
====================================================================================
Generates standalone 2D Matrix Multiplication .onnx models (NO batch dimension:
A=[M, K], B=[K, N], Y=[M, N]) across diverse dimensions and emits `matmul_tests.cmake`
so every MatMul dimension runs through:
  1) IREE VME Ukernel Path (data-tiling + mmt4d + qemu-riscv64)
  2) ONNX Runtime (CPUExecutionProvider)
  3) NumPy np.allclose(atol, rtol) comparison via CTest.
"""

import argparse
import json
import sys
from pathlib import Path
from typing import List, Dict, Any

# Unbatched 2D MatMul cases: A[M, K] x B[K, N] -> Y[M, N]
MATMUL_CASES: List[Dict[str, Any]] = [
    # Square & aligned power-of-two tiles
    {"name": "matmul_f32_16x16x16", "M": 16, "K": 16, "N": 16, "tier": "stable"},
    {"name": "matmul_f32_32x64x32", "M": 32, "K": 64, "N": 32, "tier": "stable"},
    {"name": "matmul_f32_64x128x64", "M": 64, "K": 128, "N": 64, "tier": "stable"},
    {"name": "matmul_f32_128x256x128", "M": 128, "K": 256, "N": 128, "tier": "nightly"},
    {"name": "matmul_f32_256x512x256", "M": 256, "K": 512, "N": 256, "tier": "nightly"},
    # GEMV / M=1 and skinny shapes
    {"name": "matmul_f32_1x128x64_gemv", "M": 1, "K": 128, "N": 64, "tier": "stable"},
    {"name": "matmul_f32_4x256x128_skinny_m", "M": 4, "K": 256, "N": 128, "tier": "stable"},
    {"name": "matmul_f32_64x16x256_tall_n", "M": 64, "K": 16, "N": 256, "tier": "nightly"},
    # Odd / non-multiple dimensions to stress VME remainder & tail-padding loops
    {"name": "matmul_f32_17x33x19_odd", "M": 17, "K": 33, "N": 19, "tier": "stable"},
    {"name": "matmul_f32_13x47x29_odd", "M": 13, "K": 47, "N": 29, "tier": "stable"},
    {"name": "matmul_f32_7x513x31_odd_k", "M": 7, "K": 513, "N": 31, "tier": "nightly"},
    {"name": "matmul_f32_65x129x67_off_pow2", "M": 65, "K": 129, "N": 67, "tier": "nightly"},
]


def build_matmul_onnx(cfg: Dict[str, Any], out_path: Path) -> Dict[str, Any]:
    import numpy as np
    import onnx
    from onnx import helper, TensorProto

    rng = np.random.default_rng(42)
    M, K, N = cfg["M"], cfg["K"], cfg["N"]

    a_shape = [M, K]
    b_shape = [K, N]
    y_shape = [M, N]

    b_weights = rng.uniform(-0.5, 0.5, size=b_shape).astype(np.float32)
    b_init = helper.make_tensor("B_weights", TensorProto.FLOAT, b_shape, b_weights.flatten().tolist())

    inp = helper.make_tensor_value_info("A", TensorProto.FLOAT, a_shape)
    out = helper.make_tensor_value_info("Y", TensorProto.FLOAT, y_shape)

    node = helper.make_node("MatMul", inputs=["A", "B_weights"], outputs=["Y"])
    graph = helper.make_graph([node], cfg["name"], [inp], [out], initializer=[b_init])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    onnx.save(model, str(out_path))
    return {"op": "matmul", "inputs": [f"{M}x{K}xf32"], **cfg}


def emit_ctest_cmake(cases: List[Dict[str, Any]], out_cmake: Path, runner_script: Path, onnx_root: Path) -> None:
    lines = ["# Auto-generated CTest Suite for VME Ukernel Unbatched MatMul Cases", ""]
    for c in cases:
        test_name = f"vme_ukernel_{c['tier']}_{c['name']}"
        onnx_file = (onnx_root / f"{c['name']}.onnx").as_posix()
        lines.append(
            f'add_test(NAME {test_name}\n'
            f'  COMMAND "${{Python3_EXECUTABLE}}" "{runner_script.as_posix()}"\n'
            f'    --name "{c["name"]}"\n'
            f'    --op "matmul"\n'
            f'    --onnx "{onnx_file}"\n'
            f'    --atol 1e-3 --rtol 1e-3\n'
            f')'
        )
        lines.append(
            f'set_tests_properties({test_name} PROPERTIES LABELS "vme;ukernel;rvv;matmul;{c["tier"]}")'
        )
    out_cmake.parent.mkdir(parents=True, exist_ok=True)
    out_cmake.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate unbatched 2D MatMul ONNX test cases + CTest definitions")
    parser.add_argument("--out-dir", type=Path, default=Path("tests/vme_ukernel_onnx/matmul"))
    parser.add_argument("--emit-ctest-cmake", type=Path, default=Path("ci/riscv_rvv/vme_ukernel_suite/matmul_tests.cmake"))
    args = parser.parse_args()

    generated = []
    for cfg in MATMUL_CASES:
        onnx_path = args.out_dir / f"{cfg['name']}.onnx"
        generated.append(build_matmul_onnx(cfg, onnx_path))

    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "manifest.json").write_text(json.dumps(generated, indent=2), encoding="utf-8")

    runner_script = Path(__file__).resolve().parent / "run_vme_ukernel_case.py"
    emit_ctest_cmake(generated, args.emit_ctest_cmake, runner_script, args.out_dir.resolve())

    print(f"Generated {len(generated)} unbatched 2D MatMul ONNX test cases in {args.out_dir}")
    print(f"Generated CTest file: {args.emit_ctest_cmake}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
