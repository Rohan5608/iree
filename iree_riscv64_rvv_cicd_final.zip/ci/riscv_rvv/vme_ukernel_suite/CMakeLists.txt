cmake_minimum_required(VERSION 3.21)
project(iree_vme_ukernel_onnx_tests NONE)

enable_testing()
find_package(Python3 REQUIRED COMPONENTS Interpreter)

foreach(_sub_cmake IN ITEMS
  conv2d_tests.cmake
  matmul_tests.cmake
  conv_matmul_model_tests.cmake
)
  if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/${_sub_cmake}")
    include("${CMAKE_CURRENT_LIST_DIR}/${_sub_cmake}")
  endif()
endforeach()
