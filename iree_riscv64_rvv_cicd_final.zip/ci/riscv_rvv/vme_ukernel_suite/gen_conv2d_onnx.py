#!/usr/bin/env python3
"""
File 1: Conv2D ONNX Test Case Generator & CTest Harness for VME Ukernel
======================================================================
Generates standalone Conv2D .onnx models across diverse (N, Cin, H, W, Cout, kH, kW, stride, pad)
dimensions and emits `conv2d_tests.cmake` so every Conv2D dimension runs through:
  1) IREE VME Ukernel Path (im2col + mmt4d + qemu-riscv64)
  2) ONNX Runtime (CPUExecutionProvider)
  3) NumPy np.allclose(atol, rtol) comparison via CTest.
"""

import argparse
import json
import sys
from pathlib import Path
from typing import List, Dict, Any

CONV2D_CASES: List[Dict[str, Any]] = [
    # Standard 3x3 and 1x1 convolutions
    {"name": "conv2d_f32_1x3x32x32_k3s1p1", "N": 1, "Cin": 3, "H": 32, "W": 32, "Cout": 16, "kH": 3, "kW": 3, "stride": 1, "pad": 1, "tier": "stable"},
    {"name": "conv2d_f32_1x16x28x28_k3s1p1", "N": 1, "Cin": 16, "H": 28, "W": 28, "Cout": 32, "kH": 3, "kW": 3, "stride": 1, "pad": 1, "tier": "stable"},
    {"name": "conv2d_f32_1x32x28x28_k1s1p0_pw", "N": 1, "Cin": 32, "H": 28, "W": 28, "Cout": 64, "kH": 1, "kW": 1, "stride": 1, "pad": 0, "tier": "stable"},
    {"name": "conv2d_f32_1x64x14x14_k1s1p0_pw", "N": 1, "Cin": 64, "H": 14, "W": 14, "Cout": 128, "kH": 1, "kW": 1, "stride": 1, "pad": 0, "tier": "stable"},
    # Strided & larger kernel convolutions
    {"name": "conv2d_f32_1x3x64x64_k3s2p1", "N": 1, "Cin": 3, "H": 64, "W": 64, "Cout": 32, "kH": 3, "kW": 3, "stride": 2, "pad": 1, "tier": "stable"},
    {"name": "conv2d_f32_1x16x32x32_k5s1p2", "N": 1, "Cin": 16, "H": 32, "W": 32, "Cout": 32, "kH": 5, "kW": 5, "stride": 1, "pad": 2, "tier": "nightly"},
    {"name": "conv2d_f32_1x3x224x224_k7s2p3", "N": 1, "Cin": 3, "H": 224, "W": 224, "Cout": 64, "kH": 7, "kW": 7, "stride": 2, "pad": 3, "tier": "nightly"},
    # Odd / non-multiple dimensions to stress im2col + VME ukernel tail padding
    {"name": "conv2d_f32_1x7x19x23_k3s1p0_odd", "N": 1, "Cin": 7, "H": 19, "W": 23, "Cout": 13, "kH": 3, "kW": 3, "stride": 1, "pad": 0, "tier": "stable"},
    {"name": "conv2d_f32_1x11x17x17_k3s2p1_odd", "N": 1, "Cin": 11, "H": 17, "W": 17, "Cout": 29, "kH": 3, "kW": 3, "stride": 2, "pad": 1, "tier": "nightly"},
    {"name": "conv2d_f32_2x64x56x56_k3s1p1", "N": 2, "Cin": 64, "H": 56, "W": 56, "Cout": 64, "kH": 3, "kW": 3, "stride": 1, "pad": 1, "tier": "nightly"},
]


def build_conv2d_onnx(cfg: Dict[str, Any], out_path: Path) -> Dict[str, Any]:
    import numpy as np
    import onnx
    from onnx import helper, TensorProto

    rng = np.random.default_rng(42)
    N, Cin, H, W = cfg["N"], cfg["Cin"], cfg["H"], cfg["W"]
    Cout, kH, kW = cfg["Cout"], cfg["kH"], cfg["kW"]
    stride, pad = cfg["stride"], cfg["pad"]
    Hout = (H + 2 * pad - kH) // stride + 1
    Wout = (W + 2 * pad - kW) // stride + 1

    w_arr = rng.uniform(-0.25, 0.25, size=(Cout, Cin, kH, kW)).astype(np.float32)
    b_arr = rng.uniform(-0.1, 0.1, size=(Cout,)).astype(np.float32)

    w_init = helper.make_tensor("W", TensorProto.FLOAT, [Cout, Cin, kH, kW], w_arr.flatten().tolist())
    b_init = helper.make_tensor("B", TensorProto.FLOAT, [Cout], b_arr.flatten().tolist())

    inp = helper.make_tensor_value_info("X", TensorProto.FLOAT, [N, Cin, H, W])
    out = helper.make_tensor_value_info("Y", TensorProto.FLOAT, [N, Cout, Hout, Wout])

    node = helper.make_node(
        "Conv",
        inputs=["X", "W", "B"],
        outputs=["Y"],
        kernel_shape=[kH, kW],
        strides=[stride, stride],
        pads=[pad, pad, pad, pad],
    )
    graph = helper.make_graph([node], cfg["name"], [inp], [out], initializer=[w_init, b_init])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    onnx.save(model, str(out_path))
    return {"op": "conv2d", "inputs": [f"{N}x{Cin}x{H}x{W}xf32"], **cfg}


def emit_ctest_cmake(cases: List[Dict[str, Any]], out_cmake: Path, runner_script: Path, onnx_root: Path) -> None:
    lines = ["# Auto-generated CTest Suite for VME Ukernel Conv2D Cases", ""]
    for c in cases:
        test_name = f"vme_ukernel_{c['tier']}_{c['name']}"
        onnx_file = (onnx_root / f"{c['name']}.onnx").as_posix()
        lines.append(
            f'add_test(NAME {test_name}\n'
            f'  COMMAND "${{Python3_EXECUTABLE}}" "{runner_script.as_posix()}"\n'
            f'    --name "{c["name"]}"\n'
            f'    --op "conv2d"\n'
            f'    --onnx "{onnx_file}"\n'
            f'    --atol 1e-3 --rtol 1e-3\n'
            f')'
        )
        lines.append(
            f'set_tests_properties({test_name} PROPERTIES LABELS "vme;ukernel;rvv;conv2d;{c["tier"]}")'
        )
    out_cmake.parent.mkdir(parents=True, exist_ok=True)
    out_cmake.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate Conv2D ONNX test cases + CTest definitions for VME ukernel")
    parser.add_argument("--out-dir", type=Path, default=Path("tests/vme_ukernel_onnx/conv2d"))
    parser.add_argument("--emit-ctest-cmake", type=Path, default=Path("ci/riscv_rvv/vme_ukernel_suite/conv2d_tests.cmake"))
    args = parser.parse_args()

    generated = []
    for cfg in CONV2D_CASES:
        onnx_path = args.out_dir / f"{cfg['name']}.onnx"
        generated.append(build_conv2d_onnx(cfg, onnx_path))

    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "manifest.json").write_text(json.dumps(generated, indent=2), encoding="utf-8")

    runner_script = Path(__file__).resolve().parent / "run_vme_ukernel_case.py"
    emit_ctest_cmake(generated, args.emit_ctest_cmake, runner_script, args.out_dir.resolve())

    print(f"Generated {len(generated)} Conv2D ONNX test cases in {args.out_dir}")
    print(f"Generated CTest file: {args.emit_ctest_cmake}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
