#!/usr/bin/env python3
"""
File 3: Combined Conv2D + MatMul Model ONNX Generator & CTest Harness for VME Ukernel
======================================================================================
Generates end-to-end ONNX models that combine BOTH Convolution and Matrix Multiplication
layers (Conv2D -> Relu -> Conv2D -> Relu -> GlobalAveragePool -> Flatten -> MatMul -> Add -> MatMul)
across multiple input resolutions and emits `conv_matmul_model_tests.cmake` so every
model runs through:
  1) IREE VME Ukernel Path (im2col + mmt4d + qemu-riscv64)
  2) ONNX Runtime (CPUExecutionProvider)
  3) NumPy np.allclose(atol, rtol) comparison via CTest.
"""

import argparse
import json
import sys
from pathlib import Path
from typing import List, Dict, Any

HYBRID_MODEL_CASES: List[Dict[str, Any]] = [
    {
        "name": "model_cnn_mlp_f32_1x3x32x32",
        "N": 1, "Cin": 3, "H": 32, "W": 32, "Cmid": 16, "Cout": 32,
        "hidden": 64, "num_classes": 10, "tier": "stable",
    },
    {
        "name": "model_cnn_mlp_f32_1x16x28x28",
        "N": 1, "Cin": 16, "H": 28, "W": 28, "Cmid": 32, "Cout": 64,
        "hidden": 128, "num_classes": 10, "tier": "stable",
    },
    {
        "name": "model_cnn_mlp_f32_1x7x19x23_odd",
        "N": 1, "Cin": 7, "H": 19, "W": 23, "Cmid": 13, "Cout": 29,
        "hidden": 41, "num_classes": 7, "tier": "stable",
    },
    {
        "name": "model_cnn_mlp_f32_1x16x56x56_large",
        "N": 1, "Cin": 16, "H": 56, "W": 56, "Cmid": 32, "Cout": 64,
        "hidden": 128, "num_classes": 100, "tier": "nightly",
    },
]


def build_conv_matmul_model_onnx(cfg: Dict[str, Any], out_path: Path) -> Dict[str, Any]:
    import numpy as np
    import onnx
    from onnx import helper, TensorProto

    rng = np.random.default_rng(42)
    N, Cin, H, W = cfg["N"], cfg["Cin"], cfg["H"], cfg["W"]
    Cmid, Cout = cfg["Cmid"], cfg["Cout"]
    hidden, num_classes = cfg["hidden"], cfg["num_classes"]

    conv1_w = rng.uniform(-0.2, 0.2, size=(Cmid, Cin, 3, 3)).astype(np.float32)
    conv1_b = rng.uniform(-0.05, 0.05, size=(Cmid,)).astype(np.float32)
    conv2_w = rng.uniform(-0.2, 0.2, size=(Cout, Cmid, 3, 3)).astype(np.float32)
    conv2_b = rng.uniform(-0.05, 0.05, size=(Cout,)).astype(np.float32)
    fc1_w = rng.uniform(-0.2, 0.2, size=(Cout, hidden)).astype(np.float32)
    fc1_b = rng.uniform(-0.05, 0.05, size=(hidden,)).astype(np.float32)
    fc2_w = rng.uniform(-0.2, 0.2, size=(hidden, num_classes)).astype(np.float32)
    fc2_b = rng.uniform(-0.05, 0.05, size=(num_classes,)).astype(np.float32)

    initializers = [
        helper.make_tensor("conv1_w", TensorProto.FLOAT, [Cmid, Cin, 3, 3], conv1_w.flatten().tolist()),
        helper.make_tensor("conv1_b", TensorProto.FLOAT, [Cmid], conv1_b.flatten().tolist()),
        helper.make_tensor("conv2_w", TensorProto.FLOAT, [Cout, Cmid, 3, 3], conv2_w.flatten().tolist()),
        helper.make_tensor("conv2_b", TensorProto.FLOAT, [Cout], conv2_b.flatten().tolist()),
        helper.make_tensor("fc1_w", TensorProto.FLOAT, [Cout, hidden], fc1_w.flatten().tolist()),
        helper.make_tensor("fc1_b", TensorProto.FLOAT, [hidden], fc1_b.flatten().tolist()),
        helper.make_tensor("fc2_w", TensorProto.FLOAT, [hidden, num_classes], fc2_w.flatten().tolist()),
        helper.make_tensor("fc2_b", TensorProto.FLOAT, [num_classes], fc2_b.flatten().tolist()),
    ]

    nodes = [
        helper.make_node("Conv", ["X", "conv1_w", "conv1_b"], ["c1"], kernel_shape=[3, 3], strides=[1, 1], pads=[1, 1, 1, 1]),
        helper.make_node("Relu", ["c1"], ["r1"]),
        helper.make_node("Conv", ["r1", "conv2_w", "conv2_b"], ["c2"], kernel_shape=[3, 3], strides=[2, 2], pads=[1, 1, 1, 1]),
        helper.make_node("Relu", ["c2"], ["r2"]),
        helper.make_node("GlobalAveragePool", ["r2"], ["gap"]),
        helper.make_node("Flatten", ["gap"], ["flat"], axis=1),
        helper.make_node("MatMul", ["flat", "fc1_w"], ["mm1"]),
        helper.make_node("Add", ["mm1", "fc1_b"], ["a1"]),
        helper.make_node("Relu", ["a1"], ["r3"]),
        helper.make_node("MatMul", ["r3", "fc2_w"], ["mm2"]),
        helper.make_node("Add", ["mm2", "fc2_b"], ["logits"]),
    ]

    inp = helper.make_tensor_value_info("X", TensorProto.FLOAT, [N, Cin, H, W])
    out = helper.make_tensor_value_info("logits", TensorProto.FLOAT, [N, num_classes])
    graph = helper.make_graph(nodes, cfg["name"], [inp], [out], initializer=initializers)
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 17)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    onnx.save(model, str(out_path))
    return {"op": "conv_matmul_model", "inputs": [f"{N}x{Cin}x{H}x{W}xf32"], **cfg}


def emit_ctest_cmake(cases: List[Dict[str, Any]], out_cmake: Path, runner_script: Path, onnx_root: Path) -> None:
    lines = ["# Auto-generated CTest Suite for VME Ukernel Combined Conv2D + MatMul Models", ""]
    for c in cases:
        test_name = f"vme_ukernel_{c['tier']}_{c['name']}"
        onnx_file = (onnx_root / f"{c['name']}.onnx").as_posix()
        lines.append(
            f'add_test(NAME {test_name}\n'
            f'  COMMAND "${{Python3_EXECUTABLE}}" "{runner_script.as_posix()}"\n'
            f'    --name "{c["name"]}"\n'
            f'    --op "conv_matmul_model"\n'
            f'    --onnx "{onnx_file}"\n'
            f'    --atol 1e-3 --rtol 1e-3\n'
            f')'
        )
        lines.append(
            f'set_tests_properties({test_name} PROPERTIES LABELS "vme;ukernel;rvv;conv_matmul_model;{c["tier"]}")'
        )
    out_cmake.parent.mkdir(parents=True, exist_ok=True)
    out_cmake.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate Combined Conv2D+MatMul ONNX models + CTest definitions")
    parser.add_argument("--out-dir", type=Path, default=Path("tests/vme_ukernel_onnx/conv_matmul_model"))
    parser.add_argument("--emit-ctest-cmake", type=Path, default=Path("ci/riscv_rvv/vme_ukernel_suite/conv_matmul_model_tests.cmake"))
    args = parser.parse_args()

    generated = []
    for cfg in HYBRID_MODEL_CASES:
        onnx_path = args.out_dir / f"{cfg['name']}.onnx"
        generated.append(build_conv_matmul_model_onnx(cfg, onnx_path))

    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "manifest.json").write_text(json.dumps(generated, indent=2), encoding="utf-8")

    runner_script = Path(__file__).resolve().parent / "run_vme_ukernel_case.py"
    emit_ctest_cmake(generated, args.emit_ctest_cmake, runner_script, args.out_dir.resolve())

    print(f"Generated {len(generated)} Combined Conv2D+MatMul ONNX models in {args.out_dir}")
    print(f"Generated CTest file: {args.emit_ctest_cmake}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
