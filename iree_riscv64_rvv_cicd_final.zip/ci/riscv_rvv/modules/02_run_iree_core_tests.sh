#!/usr/bin/env bash
# ==============================================================================
# MODULE 02: Run IREE Core CTest Suites by CI Stage (pr | nightly | stable)
# ==============================================================================
# Usage:
#   ./ci/riscv_rvv/modules/02_run_iree_core_tests.sh --stage <pr|nightly|stable>
#
# Execution Behavior:
#   1. Runs Host Compiler Lit Tests (RISC-V & LLVMCPU RVV codegen).
#   2. If RISCV_TEST_SCRIPT (default: ./riscv_test.sh) exists in the repo,
#      exports QEMU_CPU="${QEMU_CPU_ARGS}" and delegates RISC-V target testing
#      (ukernel + HAL/VM + check_llvm-cpu + e2e_matmul) directly to riscv_test.sh!
#   3. Otherwise, falls back to the explicit Layer B / C / D ctest commands.
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../config.env"

STAGE="pr"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage) STAGE="$2"; shift 2 ;;
    *) echo "[ERROR] Unknown argument: $1" >&2; exit 1 ;;
  esac
done

JUNIT_DIR="${ARTIFACTS_ROOT}/junit_core_${STAGE}"
mkdir -p "${JUNIT_DIR}"
JOBS="$(nproc || echo 4)"

echo "==> [Module 02] Layer A: Host Compiler Lit Tests (RISC-V & LLVMCPU RVV Codegen)"
if [[ "${STAGE}" == "nightly" ]]; then
  ctest --test-dir "${HOST_BUILD_DIR}" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_host_lit_full.xml"
else
  ctest --test-dir "${HOST_BUILD_DIR}" \
    -R "compiler/src/iree/compiler/Codegen/LLVMCPU|riscv|compiler/bindings/python" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_host_lit_riscv.xml"
fi

# Export QEMU RVV 1.0 environment variables so riscv_test.sh / ctest emulates RVV
export QEMU_CPU="${QEMU_CPU_ARGS}"
export IREE_VULKAN_DISABLE="${IREE_VULKAN_DISABLE:-1}"
export IREE_CUDA_DISABLE="${IREE_CUDA_DISABLE:-1}"
export IREE_HIP_DISABLE="${IREE_HIP_DISABLE:-1}"
export CTEST_PARALLEL_LEVEL="${JOBS}"

if [[ -n "${RISCV_TEST_SCRIPT:-}" && -f "${RISCV_TEST_SCRIPT}" ]]; then
  echo "==> [Module 02] Delegating RISC-V Target Tests (Layers B/C/D) to ${RISCV_TEST_SCRIPT}"
  echo "    QEMU_CPU=${QEMU_CPU} | RISCV_BUILD_DIR=${RISCV_BUILD_DIR} | STAGE=${STAGE}"
  chmod +x "${RISCV_TEST_SCRIPT}" || true

  # Export stage-aware regex filter & JUnit path in case riscv_test.sh reads them
  if [[ "${STAGE}" == "pr" ]]; then
    export IREE_CTEST_TESTS_REGEX="${IREE_CTEST_TESTS_REGEX:-ukernel|iree/base|iree/hal|iree/vm|check_llvm-cpu|e2e_matmul}"
  fi
  export IREE_CTEST_JUNIT_XML="${JUNIT_DIR}/junit_riscv_test_sh_${STAGE}.xml"

  "${RISCV_TEST_SCRIPT}" "${RISCV_BUILD_DIR}" --stage "${STAGE}"
  echo "==> [Module 02] ${RISCV_TEST_SCRIPT} completed for stage '${STAGE}'!"
  exit 0
fi

echo "==> [Module 02] (${RISCV_TEST_SCRIPT:-riscv_test.sh} not found; running explicit CTest Layers B, C, D)"

echo "==> [Module 02] Layer B: RISC-V 64 RVV Microkernel (ukernel: mmt4d/pack/unpack) Tests"
ctest --test-dir "${RISCV_BUILD_DIR}" \
  -R "ukernel" \
  --output-on-failure -j "${JOBS}" \
  --output-junit "${JUNIT_DIR}/junit_riscv_rvv_ukernel.xml"

echo "==> [Module 02] Layer C: RISC-V 64 Core Runtime, HAL & VM Tests"
if [[ "${STAGE}" == "pr" ]]; then
  ctest --test-dir "${RISCV_BUILD_DIR}" \
    -R "iree/base|iree/hal|iree/vm" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_riscv_runtime_core.xml"
else
  ctest --test-dir "${RISCV_BUILD_DIR}" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_riscv_runtime_full.xml"
fi

echo "==> [Module 02] Layer D: End-to-End Data-Tiled Matmul & Check Suite (RVV Verification)"
ctest --test-dir "${RISCV_BUILD_DIR}" \
  -L "driver=local-task" \
  -R "check_llvm-cpu|e2e_matmul" \
  --output-on-failure -j "${JOBS}" \
  --output-junit "${JUNIT_DIR}/junit_riscv_e2e_matmul.xml"

echo "==> [Module 02] All Core IREE CTest Gates Passed for stage '${STAGE}'!"
