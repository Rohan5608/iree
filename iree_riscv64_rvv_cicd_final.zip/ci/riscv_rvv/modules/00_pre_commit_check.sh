#!/usr/bin/env bash
# ==============================================================================
# MODULE 00: Fast Pre-Commit & Pre-Push Hook for IREE RISC-V 64 (RVV) & ONNX Suite
# ==============================================================================
# Runs in < 3 seconds before `git commit` (or as Step 0 in CI) to catch mistakes
# early before triggering a full cross-compile or CI run:
#   1. Validates all staged/discovered .onnx files reside under a valid tier
#      (`tests/onnx_models/stable/` or `tests/onnx_models/nightly/`) or declare
#      "tier": "stable" | "nightly" in meta.json.
#   2. Checks that any external weight file referenced by an .onnx protobuf
#      (e.g., model.onnx.data, .weights, .bin) actually exists and is not missing.
#   3. Validates meta.json syntax, tolerances (atol/rtol > 0), and RVV feature
#      flags (+v).
#   4. Validates shell script (`bash -n`) and Python (`py_compile`) syntax in
#      ci/riscv_rvv/.
#
# To install as a local Git pre-commit hook in your repo:
#   ./ci/riscv_rvv/modules/00_pre_commit_check.sh --install-hook
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../../.." && pwd)"

if [[ "${1:-}" == "--install-hook" ]]; then
  HOOK_PATH="${REPO_ROOT}/.git/hooks/pre-commit"
  mkdir -p "$(dirname "${HOOK_PATH}")"
  cat << 'EOF' > "${HOOK_PATH}"
#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(git rev-parse --show-toplevel)"
exec "${REPO_ROOT}/ci/riscv_rvv/modules/00_pre_commit_check.sh"
EOF
  chmod +x "${HOOK_PATH}"
  echo "==> [Module 00] Installed Git pre-commit hook at ${HOOK_PATH}"
  exit 0
fi

echo "==> [Module 00] Running Pre-Commit Validation Checks..."

# 1. Shell script syntax check
echo "  [1/3] Checking Bash syntax for ci/riscv_rvv/**/*.sh..."
for sh_file in "${REPO_ROOT}"/ci/riscv_rvv/*.sh "${REPO_ROOT}"/ci/riscv_rvv/modules/*.sh; do
  if [[ -f "${sh_file}" ]]; then
    bash -n "${sh_file}"
  fi
done

# 2. Python syntax compilation check
echo "  [2/3] Checking Python syntax for ci/riscv_rvv/**/*.py..."
for py_file in "${REPO_ROOT}"/ci/riscv_rvv/*.py "${REPO_ROOT}"/ci/riscv_rvv/modules/*.py; do
  if [[ -f "${py_file}" ]]; then
    python3 -m py_compile "${py_file}"
  fi
done

# 3. ONNX Model Tier, External Weights & meta.json Integrity Check
echo "  [3/3] Validating ONNX model tiers, external weight references, and meta.json schemas..."
python3 - "${REPO_ROOT}/tests/onnx_models" << 'PYEOF'
import json
import sys
from pathlib import Path

models_root = Path(sys.argv[1])
if not models_root.exists():
    print("    [OK] No tests/onnx_models directory present yet.")
    sys.exit(0)

errors = []

# Validate every meta.json file
for meta_file in sorted(models_root.rglob("meta.json")):
    try:
        data = json.loads(meta_file.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid JSON in {meta_file}: {exc}")
        continue

    tier = str(data.get("tier", "")).lower()
    if tier and tier not in ("stable", "nightly"):
        errors.append(f"{meta_file}: 'tier' must be 'stable' or 'nightly' (got '{tier}')")

    rvv_feat = str(data.get("rvv_cpu_features", "+v"))
    if "+v" not in rvv_feat and "+zve" not in rvv_feat:
        errors.append(f"{meta_file}: 'rvv_cpu_features' ('{rvv_feat}') does not enable RVV (+v or +zve*)")

    for tol_key in ("atol", "rtol"):
        if tol_key in data and float(data[tol_key]) <= 0:
            errors.append(f"{meta_file}: '{tol_key}' must be > 0")

# Validate every .onnx file and check if referenced external weights exist
try:
    import onnx
    HAS_ONNX = True
except ImportError:
    HAS_ONNX = False

for onnx_file in sorted(models_root.rglob("*.onnx")):
    rel_parts = [p.lower() for p in onnx_file.relative_to(models_root).parts]
    meta_file = onnx_file.parent / "meta.json"
    has_valid_tier = ("stable" in rel_parts) or ("nightly" in rel_parts) or onnx_file.stem.endswith(("_stable", "_nightly"))
    if meta_file.exists():
        try:
            m = json.loads(meta_file.read_text(encoding="utf-8"))
            if str(m.get("tier", "")).lower() in ("stable", "nightly"):
                has_valid_tier = True
        except Exception:
            pass
    if not has_valid_tier:
        errors.append(
            f"{onnx_file}: Model is not identifiable as 'stable' or 'nightly'. "
            "Place it under tests/onnx_models/stable/ or tests/onnx_models/nightly/ or set 'tier' in meta.json."
        )

    if HAS_ONNX:
        try:
            model_proto = onnx.load(str(onnx_file), load_external_data=False)
            for tensor in model_proto.graph.initializer:
                if tensor.HasField("data_location") and tensor.data_location == onnx.TensorProto.EXTERNAL:
                    for entry in tensor.external_data:
                        if entry.key == "location":
                            weight_path = onnx_file.parent / entry.value
                            if not weight_path.exists():
                                errors.append(
                                    f"{onnx_file}: Missing external weight file '{entry.value}' "
                                    f"(expected at {weight_path}). Make sure you add the weights file!"
                                )
        except Exception as exc:
            errors.append(f"{onnx_file}: Failed ONNX protobuf header check: {exc}")

if errors:
    print("\n[PRE-COMMIT FAILED] Found the following issues:", file=sys.stderr)
    for err in errors:
        print(f"  - {err}", file=sys.stderr)
    sys.exit(1)

print("    [OK] All ONNX models, meta.json schemas, and external weight references are valid.")
PYEOF

echo "==> [Module 00] All Pre-Commit Checks Passed!"
