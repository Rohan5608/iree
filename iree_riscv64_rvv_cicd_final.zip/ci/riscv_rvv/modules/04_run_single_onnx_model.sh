#!/usr/bin/env bash
# ==============================================================================
# MODULE 04: Single ONNX Model Execution Wrapper (Custom Script or IREE RVV Flow)
# ==============================================================================
# Supports:
#   1. Embedded weights inside model.onnx
#   2. External ONNX data weights (.onnx.data, .weights, .bin) in ONNX_MODEL_DIR
#   3. Separate/decoupled weights passed as graph inputs (via ONNX_INPUT_NPY_FILES)
#      or as IREE Parameter Archives (.irpa, .safetensors, .gguf via ONNX_PARAM_ARCHIVE)
#   4. Execution on QEMU (qemu-riscv64 -cpu rv64,v=true,vlen=256,vext_spec=v1.0)
#      OR native physical RISC-V 64 RVV hardware (when QEMU_RISCV64_BIN="").
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../config.env"

echo "=================================================================="
echo "Model              : ${ONNX_MODEL_NAME} (Tier: ${ONNX_MODEL_TIER})"
echo "ONNX File          : ${ONNX_MODEL_PATH}"
echo "External Weights   : ${ONNX_WEIGHTS_PATHS:-<embedded or input-fed>}"
echo "Parameter Archive  : ${ONNX_PARAM_ARCHIVE:-<none>}"
echo "Input .npy Files   : ${ONNX_INPUT_NPY_FILES}"
echo "ORT Golden .npy    : ${ORT_OUTPUT_NPY_FILES}"
echo "IREE Target .npy   : ${IREE_OUTPUT_NPY_FILES}"
echo "Target Runner      : ${QEMU_RISCV64_BIN:-Native RISC-V 64 Hardware}"
echo "=================================================================="

# If USER_ACTUAL_SCRIPT is configured and executable, delegate to your script:
if [[ -n "${USER_ACTUAL_SCRIPT:-}" && -x "${USER_ACTUAL_SCRIPT}" ]]; then
  echo "[Module 04] Delegating to custom pipeline script: ${USER_ACTUAL_SCRIPT}"
  exec "${USER_ACTUAL_SCRIPT}" \
    "${ONNX_MODEL_PATH}" \
    "${ONNX_FIRST_WEIGHT_PATH:-}" \
    "${MODEL_ARTIFACT_DIR}" \
    "${ONNX_MODEL_TIER}" \
    "${ONNX_INPUT_NPY_FILES}" \
    "${IREE_OUTPUT_NPY_FILES}"
fi

# Built-in Standard IREE ONNX -> MLIR -> RISC-V 64 RVV VMFB -> QEMU/Hardware Flow
MLIR_OUT="$(realpath -m "${MODEL_ARTIFACT_DIR}/${ONNX_MODEL_NAME}.mlir")"
VMFB_OUT="$(realpath -m "${MODEL_ARTIFACT_DIR}/${ONNX_MODEL_NAME}_riscv64_rvv.vmfb")"
ONNX_ABS="$(realpath "${ONNX_MODEL_PATH}")"
MODEL_DIR_ABS="$(realpath "${ONNX_MODEL_DIR:-$(dirname "${ONNX_MODEL_PATH}")}")"

IREE_IMPORT_ONNX="${IREE_HOST_BIN_DIR:+${IREE_HOST_BIN_DIR}/}iree-import-onnx"
IREE_COMPILE="${IREE_HOST_BIN_DIR:+${IREE_HOST_BIN_DIR}/}iree-compile"
IREE_RUN_MODULE="${IREE_RISCV_BIN_DIR:+${IREE_RISCV_BIN_DIR}/}iree-run-module"

# 1. Import ONNX to MLIR from inside MODEL_DIR_ABS so external weights (.onnx.data / .weights) resolve cleanly
(
  cd "${MODEL_DIR_ABS}"
  "${IREE_IMPORT_ONNX}" "${ONNX_ABS}" \
    --opset-version "${ONNX_OPSET_VERSION:-17}" \
    -o "${MLIR_OUT}"
)

# 2. Cross-Compile MLIR to RISC-V 64 RVV VMFB (with data-tiling & RVV ukernels enabled)
"${IREE_COMPILE}" "${MLIR_OUT}" \
  --iree-hal-target-device=local \
  --iree-hal-local-target-device-backends=llvm-cpu \
  --iree-llvmcpu-target-triple="${IREE_RVV_TARGET_TRIPLE}" \
  --iree-llvmcpu-target-abi="${IREE_RVV_TARGET_ABI}" \
  --iree-llvmcpu-target-cpu-features="${IREE_RVV_CPU_FEATURES}" \
  --riscv-v-fixed-length-vector-lmul-max="${IREE_RVV_LMUL_MAX:-8}" \
  --iree-opt-data-tiling \
  --iree-llvmcpu-enable-ukernels="${IREE_ENABLE_UKERNELS:-all}" \
  -o "${VMFB_OUT}"

# 3. Assemble --input=@.../input_0.npy, optional --parameters=..., and --output=@.../iree_output_0.npy
RUN_IO_FLAGS=()
if [[ -n "${ONNX_PARAM_ARCHIVE:-}" ]]; then
  RUN_IO_FLAGS+=("--parameters=${ONNX_PARAM_ARCHIVE}")
fi

IFS=':' read -r -a IN_NPY_ARR <<< "${ONNX_INPUT_NPY_FILES:-}"
for npy in "${IN_NPY_ARR[@]}"; do
  [[ -n "${npy}" ]] && RUN_IO_FLAGS+=("--input=@${npy}")
done

IFS=':' read -r -a OUT_NPY_ARR <<< "${IREE_OUTPUT_NPY_FILES:-}"
for npy in "${OUT_NPY_ARR[@]}"; do
  [[ -n "${npy}" ]] && RUN_IO_FLAGS+=("--output=@${npy}")
done

# 4. Execute on QEMU (emulating RISC-V 64 RVV 1.0) or physical RISC-V 64 board
if [[ -n "${QEMU_RISCV64_BIN:-}" ]]; then
  "${QEMU_RISCV64_BIN}" \
    -cpu "${QEMU_CPU_ARGS}" \
    ${RISCV_SYSROOT:+-L "${RISCV_SYSROOT}"} \
    "${IREE_RUN_MODULE}" \
    --device=local-task \
    --module="${VMFB_OUT}" \
    --function="${ONNX_ENTRY_FUNCTION}" \
    "${RUN_IO_FLAGS[@]}"
else
  "${IREE_RUN_MODULE}" \
    --device=local-task \
    --module="${VMFB_OUT}" \
    --function="${ONNX_ENTRY_FUNCTION}" \
    "${RUN_IO_FLAGS[@]}"
fi
