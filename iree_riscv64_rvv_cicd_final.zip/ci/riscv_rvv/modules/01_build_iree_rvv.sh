#!/usr/bin/env bash
# ==============================================================================
# MODULE 01: Build Host IREE Compiler & Cross-Compile RISC-V 64 (RVV) Runtime
# ==============================================================================
# Usage:
#   ./ci/riscv_rvv/modules/01_build_iree_rvv.sh [--build-type RelWithDebInfo|Release]
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../config.env"

BUILD_TYPE="${BUILD_TYPE:-RelWithDebInfo}"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --build-type) BUILD_TYPE="$2"; shift 2 ;;
    *) echo "[ERROR] Unknown argument: $1" >&2; exit 1 ;;
  esac
done

echo "==> [Module 01] Step 1/2: Building Host IREE Compiler (BUILD_TYPE=${BUILD_TYPE})"
cmake -G Ninja -B "${HOST_BUILD_DIR}" . \
  -DCMAKE_C_COMPILER=clang \
  -DCMAKE_CXX_COMPILER=clang++ \
  -DCMAKE_BUILD_TYPE="${BUILD_TYPE}" \
  -DCMAKE_INSTALL_PREFIX="${HOST_INSTALL_DIR}" \
  -DIREE_ENABLE_ASSERTIONS=ON \
  -DIREE_ENABLE_LLD=ON \
  -DIREE_BUILD_COMPILER=ON \
  -DIREE_BUILD_TESTS=ON \
  -DIREE_BUILD_SAMPLES=OFF \
  -DIREE_TARGET_BACKEND_LLVM_CPU=ON \
  -DIREE_BUILD_PYTHON_BINDINGS=ON

cmake --build "${HOST_BUILD_DIR}" --target install iree-test-deps

echo "==> [Module 01] Step 2/2: Cross-Compiling IREE Runtime & Tests for riscv64 (RVV)"
cmake -G Ninja -B "${RISCV_BUILD_DIR}" . \
  -DCMAKE_TOOLCHAIN_FILE="./build_tools/cmake/linux_riscv64.cmake" \
  -DIREE_HOST_BIN_DIR="$(realpath "${HOST_INSTALL_DIR}/bin")" \
  -DRISCV_TOOLCHAIN_ROOT="${RISCV_TOOLCHAIN_ROOT}" \
  -DCMAKE_BUILD_TYPE="${BUILD_TYPE}" \
  -DIREE_BUILD_COMPILER=OFF \
  -DIREE_BUILD_TESTS=ON \
  -DIREE_BUILD_SAMPLES=ON \
  -DIREE_ENABLE_CPUINFO=ON

cmake --build "${RISCV_BUILD_DIR}"
cmake --build "${RISCV_BUILD_DIR}" --target iree-test-deps
echo "==> [Module 01] Build Complete!"
