#!/usr/bin/env python3
"""
IREE RISC-V 64 (RVV) ONNX Auto-Discovery, Runner & ONNX Runtime vs IREE Comparator
==================================================================================
1. Automatically discovers ONNX models (.onnx) and companion external weights
   (.onnx.data, .weights, .bin, .pb, or external data files in the same folder).
2. Identifies each model's release tier ("stable", "nightly", "pr").
3. Generates deterministic NumPy inputs (.npy) matching the ONNX graph's input
   names, shapes, and dtypes (or loads user-provided input_*.npy files).
4. Runs ONNX Runtime (CPUExecutionProvider) on those NumPy inputs and saves
   golden reference outputs (ort_output_0.npy, ...).
5. Runs the IREE RISC-V 64 RVV path (either via your custom pipeline script or
   the default iree-import-onnx -> iree-compile -> qemu-riscv64 iree-run-module
   pipeline) using the exact same input .npy files and dumps IREE outputs to
   iree_output_0.npy, ...
6. Compares ONNX Runtime NumPy outputs vs. IREE RVV NumPy outputs using
   np.allclose(atol, rtol), calculating max_abs_diff, mean_abs_diff, max_rel_diff,
   RMSE, and cosine similarity, and writes JUnit XML + JSON/Markdown comparison
   reports for CI/CD.
"""

import argparse
import json
import math
import os
import re
import shlex
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple

import numpy as np


WEIGHT_EXTENSIONS = {".data", ".weights", ".bin", ".pb", ".params", ".raw"}

ORT_TYPE_TO_NP = {
    "tensor(float)": np.float32,
    "tensor(float16)": np.float16,
    "tensor(double)": np.float64,
    "tensor(int64)": np.int64,
    "tensor(int32)": np.int32,
    "tensor(int16)": np.int16,
    "tensor(int8)": np.int8,
    "tensor(uint8)": np.uint8,
    "tensor(bool)": np.bool_,
}

IREE_DTYPE_TO_NP = {
    "f32": np.float32,
    "f16": np.float16,
    "f64": np.float64,
    "i64": np.int64,
    "i32": np.int32,
    "i16": np.int16,
    "i8": np.int8,
    "u8": np.uint8,
    "i1": np.bool_,
}


@dataclass
class OnnxModelCase:
    name: str
    tier: str  # "stable" or "nightly"
    run_on_pr: bool
    onnx_path: str
    weights_paths: List[str] = field(default_factory=list)
    model_dir: str = ""
    entry_function: str = "main_graph"
    inputs: List[str] = field(default_factory=list)  # Optional fallback specs e.g. ["1x3x224x224xf32"]
    opset_version: int = 17
    rvv_cpu_features: str = "+m,+a,+f,+d,+v,+zvl256b"
    rvv_lmul_max: int = 8
    extra_compile_flags: List[str] = field(default_factory=list)
    extra_pipeline_args: List[str] = field(default_factory=list)
    atol: float = 1e-3
    rtol: float = 1e-3
    seed: int = 42
    timeout_sec: int = 600


def find_companion_weights(onnx_file: Path) -> List[str]:
    """Finds external weights/data files associated with an ONNX model."""
    parent = onnx_file.parent
    weights = []
    for item in sorted(parent.iterdir()):
        if item == onnx_file or item.name == "meta.json" or item.suffix in (".onnx", ".npy", ".npz"):
            continue
        if (
            item.name.startswith(onnx_file.name + ".")
            or item.suffix.lower() in WEIGHT_EXTENSIONS
            or "weight" in item.name.lower()
            or item.name.endswith(".onnx_data")
        ):
            weights.append(str(item.as_posix()))
    return weights


def discover_models(root_dir: Path, requested_tier: str) -> List[OnnxModelCase]:
    """
    Scans root_dir (e.g., tests/onnx_models) for .onnx files.
    Tier resolution priority:
      1. meta.json "tier" field ("stable" or "nightly")
      2. Parent directory name ("stable" or "nightly")
      3. Filename suffix (*_stable.onnx vs *_nightly.onnx)
      4. Default: "nightly"
    """
    if not root_dir.exists():
        return []

    discovered: List[OnnxModelCase] = []
    onnx_files = sorted(root_dir.rglob("*.onnx"))

    for onnx_path in onnx_files:
        rel_parts = [p.lower() for p in onnx_path.relative_to(root_dir).parts]
        tier = "nightly"
        if "stable" in rel_parts or onnx_path.stem.endswith("_stable"):
            tier = "stable"
        elif "nightly" in rel_parts or onnx_path.stem.endswith("_nightly"):
            tier = "nightly"

        run_on_pr = (tier == "stable")
        meta_path = onnx_path.parent / "meta.json"
        meta: Dict[str, Any] = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception as exc:
                print(f"[WARN] Failed to parse {meta_path}: {exc}", file=sys.stderr)

        tier = meta.get("tier", tier).lower()
        run_on_pr = bool(meta.get("run_on_pr", tier == "stable"))

        if onnx_path.parent != root_dir and onnx_path.parent.name.lower() not in ("stable", "nightly"):
            model_name = onnx_path.parent.name
        else:
            model_name = onnx_path.stem

        model_name = meta.get("name", model_name)
        weights = meta.get("weights", find_companion_weights(onnx_path))

        case = OnnxModelCase(
            name=model_name,
            tier=tier,
            run_on_pr=run_on_pr,
            onnx_path=str(onnx_path.as_posix()),
            weights_paths=weights,
            model_dir=str(onnx_path.parent.as_posix()),
            entry_function=meta.get("entry_function", "main_graph"),
            inputs=meta.get("inputs", []),
            opset_version=int(meta.get("opset_version", 17)),
            rvv_cpu_features=meta.get("rvv_cpu_features", "+m,+a,+f,+d,+v,+zvl256b"),
            rvv_lmul_max=int(meta.get("rvv_lmul_max", 8)),
            extra_compile_flags=meta.get("extra_compile_flags", []),
            extra_pipeline_args=meta.get("extra_pipeline_args", []),
            atol=float(meta.get("atol", 1e-3)),
            rtol=float(meta.get("rtol", 1e-3)),
            seed=int(meta.get("seed", 42)),
            timeout_sec=int(meta.get("timeout_sec", 600)),
        )

        if requested_tier == "pr" and not case.run_on_pr:
            continue
        elif requested_tier == "stable" and case.tier != "stable":
            continue
        elif requested_tier == "nightly" and case.tier not in ("stable", "nightly"):
            continue

        discovered.append(case)

    return discovered


def parse_iree_shape_spec(spec: str) -> Tuple[Tuple[int, ...], Any]:
    """Parses an IREE shape spec like '1x3x224x224xf32=0' into ((1, 3, 224, 224), np.float32)."""
    lhs = spec.split("=")[0].strip()
    parts = lhs.split("x")
    dtype_str = parts[-1].lower()
    dims = tuple(int(d) for d in parts[:-1]) if len(parts) > 1 else (1,)
    np_dtype = IREE_DTYPE_TO_NP.get(dtype_str, np.float32)
    return dims, np_dtype


def make_random_array(shape: Tuple[int, ...], np_dtype: Any, rng: np.random.Generator) -> np.ndarray:
    """Generates a deterministic random array for testing both ONNX Runtime and IREE."""
    if np.issubdtype(np_dtype, np.floating):
        return rng.uniform(-1.0, 1.0, size=shape).astype(np_dtype)
    elif np.issubdtype(np_dtype, np.bool_):
        return rng.integers(0, 2, size=shape).astype(np_dtype)
    else:
        return rng.integers(0, 10, size=shape).astype(np_dtype)


def load_pb_tensor(pb_path: Path) -> np.ndarray:
    """Loads an ONNX TensorProto (.pb) input or weight file into a NumPy array."""
    import onnx
    from onnx import numpy_helper
    tensor_proto = onnx.TensorProto()
    tensor_proto.ParseFromString(pb_path.read_bytes())
    return numpy_helper.to_array(tensor_proto)


def prepare_inputs_and_run_ort(
    case: OnnxModelCase,
    inputs_dir: Path,
    ort_outputs_dir: Path,
) -> Tuple[List[Path], List[Path], str]:
    """
    1. Resolves inputs and any decoupled input-fed weights from:
         - <model_dir>/<input_name>.npy or <model_dir>/input_<idx>.npy
         - <model_dir>/inputs/<input_name>.npy or <model_dir>/weights/<input_name>.npy
         - <model_dir>/inputs.npz or <model_dir>/weights.npz
         - <model_dir>/test_data_set_0/input_<idx>.pb
         - meta.json "inputs" specs or seeded random tensors matching ONNX graph signature
    2. Runs ONNX Runtime (CPUExecutionProvider) from inside case.model_dir so external
       weights (.onnx.data, .weights, .bin) resolve automatically.
    3. Saves input_0.npy..input_N.npy and golden ort_output_0.npy..ort_output_M.npy.
    """
    import onnxruntime as ort

    onnx_abs = Path(case.onnx_path).resolve()
    model_dir_path = Path(case.model_dir).resolve() if case.model_dir else onnx_abs.parent
    inputs_dir = inputs_dir.resolve()
    ort_outputs_dir = ort_outputs_dir.resolve()

    inputs_dir.mkdir(parents=True, exist_ok=True)
    ort_outputs_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(case.seed)
    logs = []

    npz_archives: Dict[str, Any] = {}
    for npz_file in sorted(model_dir_path.glob("*.npz")):
        try:
            npz_archives[npz_file.name] = np.load(npz_file)
            logs.append(f"Loaded NumPy archive '{npz_file.name}' (keys={list(npz_archives[npz_file.name].keys())})")
        except Exception as exc:
            logs.append(f"[WARN] Failed to load {npz_file}: {exc}")

    prev_cwd = os.getcwd()
    try:
        os.chdir(model_dir_path)
        sess = ort.InferenceSession(
            str(onnx_abs),
            providers=["CPUExecutionProvider"],
        )
    finally:
        os.chdir(prev_cwd)

    ort_inputs = sess.get_inputs()
    ort_outputs_meta = sess.get_outputs()

    feed_dict: Dict[str, np.ndarray] = {}
    input_npy_paths: List[Path] = []

    for idx, inp_meta in enumerate(ort_inputs):
        safe_name = inp_meta.name.replace("/", "_").replace(":", "_")
        candidate_npys = [
            model_dir_path / f"{inp_meta.name}.npy",
            model_dir_path / f"{safe_name}.npy",
            model_dir_path / "inputs" / f"{inp_meta.name}.npy",
            model_dir_path / "inputs" / f"{safe_name}.npy",
            model_dir_path / "weights" / f"{inp_meta.name}.npy",
            model_dir_path / "weights" / f"{safe_name}.npy",
            model_dir_path / f"input_{idx}.npy",
            model_dir_path / "inputs" / f"input_{idx}.npy",
        ]
        loaded_arr = None
        for cand in candidate_npys:
            if cand.exists():
                loaded_arr = np.load(cand)
                logs.append(f"Loaded custom .npy '{cand.relative_to(model_dir_path)}' for '{inp_meta.name}': shape={loaded_arr.shape}, dtype={loaded_arr.dtype}")
                break

        if loaded_arr is None:
            for arc_name, npz_data in npz_archives.items():
                for key_cand in (inp_meta.name, safe_name, f"input_{idx}", f"arr_{idx}"):
                    if key_cand in npz_data:
                        loaded_arr = np.asarray(npz_data[key_cand])
                        logs.append(f"Loaded '{key_cand}' from '{arc_name}' for '{inp_meta.name}': shape={loaded_arr.shape}, dtype={loaded_arr.dtype}")
                        break
                if loaded_arr is not None:
                    break

        if loaded_arr is None:
            pb_cand = model_dir_path / "test_data_set_0" / f"input_{idx}.pb"
            if pb_cand.exists():
                loaded_arr = load_pb_tensor(pb_cand)
                logs.append(f"Loaded ONNX TensorProto '{pb_cand.relative_to(model_dir_path)}' for '{inp_meta.name}': shape={loaded_arr.shape}, dtype={loaded_arr.dtype}")

        if loaded_arr is None and idx < len(case.inputs) and case.inputs[idx]:
            shape, np_dtype = parse_iree_shape_spec(case.inputs[idx])
            loaded_arr = make_random_array(shape, np_dtype, rng)
            logs.append(f"Generated input #{idx} ('{inp_meta.name}') from meta.json spec '{case.inputs[idx]}': shape={loaded_arr.shape}, dtype={loaded_arr.dtype}")

        if loaded_arr is None:
            resolved_shape = tuple(
                int(d) if isinstance(d, int) and d > 0 else 1
                for d in (inp_meta.shape or [1])
            )
            np_dtype = ORT_TYPE_TO_NP.get(inp_meta.type, np.float32)
            loaded_arr = make_random_array(resolved_shape, np_dtype, rng)
            logs.append(f"Auto-generated seeded input #{idx} ('{inp_meta.name}'): shape={loaded_arr.shape}, dtype={loaded_arr.dtype}")

        npy_path = inputs_dir / f"input_{idx}.npy"
        np.save(npy_path, loaded_arr)
        feed_dict[inp_meta.name] = loaded_arr
        input_npy_paths.append(npy_path)

    output_names = [o.name for o in ort_outputs_meta]
    ort_results = sess.run(output_names, feed_dict)

    ort_output_paths: List[Path] = []
    for idx, (out_name, out_arr) in enumerate(zip(output_names, ort_results)):
        out_arr_np = np.asarray(out_arr)
        out_path = ort_outputs_dir / f"ort_output_{idx}.npy"
        np.save(out_path, out_arr_np)
        ort_output_paths.append(out_path)
        logs.append(
            f"ONNX Runtime output #{idx} ('{out_name}') saved to {out_path.name}: "
            f"shape={out_arr_np.shape}, dtype={out_arr_np.dtype}"
        )

    return input_npy_paths, ort_output_paths, "\n".join(logs)


def compare_numpy_outputs(
    ort_output_paths: List[Path],
    iree_output_paths: List[Path],
    atol: float,
    rtol: float,
) -> Tuple[bool, List[Dict[str, Any]], str]:
    """
    Compares ONNX Runtime .npy outputs against IREE RVV .npy outputs.
    Computes max_abs_diff, mean_abs_diff, max_rel_diff, RMSE, cosine_similarity,
    and np.allclose(ort_arr, iree_arr, rtol=rtol, atol=atol).
    """
    if len(ort_output_paths) != len(iree_output_paths):
        msg = f"[FAIL] Output count mismatch: ONNX Runtime produced {len(ort_output_paths)} output(s), IREE produced {len(iree_output_paths)}."
        return False, [], msg

    all_passed = True
    metrics_list: List[Dict[str, Any]] = []
    lines = [
        "================================================================================",
        f"NUMPY COMPARISON: ONNX Runtime (Golden) vs. IREE RISC-V 64 RVV (atol={atol}, rtol={rtol})",
        "================================================================================",
    ]

    for idx, (ort_path, iree_path) in enumerate(zip(ort_output_paths, iree_output_paths)):
        if not iree_path.exists():
            all_passed = False
            msg = f"  [Output #{idx}] MISSING IREE output file: {iree_path}"
            lines.append(msg)
            metrics_list.append({
                "output_index": idx,
                "status": "FAILED",
                "error": f"Missing file {iree_path}",
            })
            continue

        ort_arr = np.load(ort_path)
        iree_arr = np.load(iree_path)

        if ort_arr.shape != iree_arr.shape:
            all_passed = False
            msg = f"  [Output #{idx}] SHAPE MISMATCH: ORT={ort_arr.shape} vs IREE={iree_arr.shape}"
            lines.append(msg)
            metrics_list.append({
                "output_index": idx,
                "status": "FAILED",
                "ort_shape": list(ort_arr.shape),
                "iree_shape": list(iree_arr.shape),
                "error": "Shape mismatch",
            })
            continue

        # Cast to float64 for high-precision difference metrics
        ort_f64 = ort_arr.astype(np.float64).ravel()
        iree_f64 = iree_arr.astype(np.float64).ravel()

        abs_diff = np.abs(ort_f64 - iree_f64)
        max_abs_diff = float(np.max(abs_diff)) if abs_diff.size > 0 else 0.0
        mean_abs_diff = float(np.mean(abs_diff)) if abs_diff.size > 0 else 0.0
        rmse = float(np.sqrt(np.mean((ort_f64 - iree_f64) ** 2))) if abs_diff.size > 0 else 0.0

        denom = np.maximum(np.abs(ort_f64), 1e-12)
        max_rel_diff = float(np.max(abs_diff / denom)) if abs_diff.size > 0 else 0.0

        norm_ort = float(np.linalg.norm(ort_f64))
        norm_iree = float(np.linalg.norm(iree_f64))
        if norm_ort > 0 and norm_iree > 0:
            cosine_sim = float(np.dot(ort_f64, iree_f64) / (norm_ort * norm_iree))
        elif norm_ort == 0 and norm_iree == 0:
            cosine_sim = 1.0
        else:
            cosine_sim = 0.0

        is_close = bool(np.allclose(ort_arr, iree_arr, rtol=rtol, atol=atol, equal_nan=True))
        if not is_close:
            all_passed = False

        status_str = "MATCH (PASSED)" if is_close else "MISMATCH (FAILED)"
        lines.append(
            f"  [Output #{idx}] {status_str} | shape={ort_arr.shape} dtype={ort_arr.dtype}\n"
            f"      max_abs_diff = {max_abs_diff:.6e} | mean_abs_diff = {mean_abs_diff:.6e}\n"
            f"      max_rel_diff = {max_rel_diff:.6e} | RMSE          = {rmse:.6e} | cosine_sim = {cosine_sim:.6f}"
        )
        metrics_list.append({
            "output_index": idx,
            "status": "PASSED" if is_close else "FAILED",
            "shape": list(ort_arr.shape),
            "dtype": str(ort_arr.dtype),
            "max_abs_diff": max_abs_diff,
            "mean_abs_diff": mean_abs_diff,
            "max_rel_diff": max_rel_diff,
            "rmse": rmse,
            "cosine_similarity": cosine_sim,
            "atol": atol,
            "rtol": rtol,
        })

    lines.append("================================================================================")
    return all_passed, metrics_list, "\n".join(lines)


def run_single_model(
    case: OnnxModelCase,
    pipeline_script: Optional[str],
    work_dir: Path,
    iree_host_bin: str,
    iree_riscv_bin: str,
    qemu_bin: str,
    sysroot: str,
    compare_ort: bool = True,
) -> Dict[str, Any]:
    """
    1. Generates NumPy input .npy files and runs ONNX Runtime to produce golden .npy outputs.
    2. Executes the IREE RISC-V 64 RVV pipeline (via custom script or built-in flow)
       using the exact same input .npy files and collects IREE .npy outputs.
    3. Compares ONNX Runtime vs. IREE NumPy outputs and returns full metrics.
    """
    model_out_dir = work_dir / case.tier / case.name
    inputs_dir = model_out_dir / "inputs"
    ort_outputs_dir = model_out_dir / "ort_outputs"
    iree_outputs_dir = model_out_dir / "iree_outputs"
    for d in (model_out_dir, inputs_dir, ort_outputs_dir, iree_outputs_dir):
        d.mkdir(parents=True, exist_ok=True)

    start_ts = time.time()
    step_logs: List[str] = []

    # Step 0: Run ONNX Runtime Golden Reference & Save Input/Output .npy tensors
    input_npy_paths: List[Path] = []
    ort_output_paths: List[Path] = []
    expected_iree_output_paths: List[Path] = []

    if compare_ort:
        try:
            print(f"==> [{case.tier.upper()}] {case.name} :: 0. ONNX Runtime Golden Execution (NumPy)")
            input_npy_paths, ort_output_paths, ort_log = prepare_inputs_and_run_ort(
                case=case,
                inputs_dir=inputs_dir,
                ort_outputs_dir=ort_outputs_dir,
            )
            step_logs.append(f"--- 0. ONNX Runtime Reference ---\n{ort_log}")
            expected_iree_output_paths = [
                iree_outputs_dir / f"iree_output_{i}.npy"
                for i in range(len(ort_output_paths))
            ]
        except Exception as exc:
            duration = time.time() - start_ts
            err_msg = f"[ERROR] ONNX Runtime golden execution failed for '{case.name}': {exc}"
            print(f"    {err_msg}", file=sys.stderr)
            return {
                "name": case.name,
                "tier": case.tier,
                "status": "FAILED",
                "returncode": 1,
                "duration_sec": round(duration, 2),
                "comparison_metrics": [],
                "output": "\n".join(step_logs + [err_msg]),
            }

    # Build iree-run-module flags for .npy inputs and .npy outputs
    iree_input_flags = [f"--input=@{p.as_posix()}" for p in input_npy_paths]
    if not iree_input_flags:
        fallback_inputs = case.inputs or ["1x3x224x224xf32=0"]
        iree_input_flags = [f"--input={inp}" for inp in fallback_inputs]

    iree_output_flags = [f"--output=@{p.as_posix()}" for p in expected_iree_output_paths]

    env = os.environ.copy()
    env.update({
        "ONNX_MODEL_NAME": case.name,
        "ONNX_MODEL_TIER": case.tier,
        "ONNX_MODEL_PATH": case.onnx_path,
        "ONNX_MODEL_DIR": case.model_dir,
        "ONNX_WEIGHTS_PATHS": ":".join(case.weights_paths),
        "ONNX_FIRST_WEIGHT_PATH": case.weights_paths[0] if case.weights_paths else "",
        "ONNX_ENTRY_FUNCTION": case.entry_function,
        "ONNX_INPUTS": ";".join(case.inputs),
        "ONNX_INPUT_NPY_FILES": ":".join(p.as_posix() for p in input_npy_paths),
        "ORT_OUTPUT_NPY_FILES": ":".join(p.as_posix() for p in ort_output_paths),
        "IREE_OUTPUT_NPY_FILES": ":".join(p.as_posix() for p in expected_iree_output_paths),
        "IREE_RUN_INPUT_FLAGS": " ".join(iree_input_flags),
        "IREE_RUN_OUTPUT_FLAGS": " ".join(iree_output_flags),
        "ONNX_OPSET_VERSION": str(case.opset_version),
        "IREE_RVV_CPU_FEATURES": case.rvv_cpu_features,
        "IREE_RVV_LMUL_MAX": str(case.rvv_lmul_max),
        "IREE_HOST_BIN_DIR": iree_host_bin,
        "IREE_RISCV_BIN_DIR": iree_riscv_bin,
        "QEMU_RISCV64_BIN": qemu_bin,
        "RISCV_SYSROOT": sysroot,
        "MODEL_ARTIFACT_DIR": str(model_out_dir),
        "ATOL": str(case.atol),
        "RTOL": str(case.rtol),
    })

    if pipeline_script:
        cmd = [
            pipeline_script,
            "--model", case.onnx_path,
            "--model-dir", case.model_dir,
            "--name", case.name,
            "--tier", case.tier,
            "--output-dir", str(model_out_dir),
            "--rvv-features", case.rvv_cpu_features,
            "--inputs-npy", ",".join(p.as_posix() for p in input_npy_paths),
            "--iree-outputs-npy", ",".join(p.as_posix() for p in expected_iree_output_paths),
            "--ort-outputs-npy", ",".join(p.as_posix() for p in ort_output_paths),
        ]
        if case.weights_paths:
            cmd.extend(["--weights", ",".join(case.weights_paths)])
        if case.extra_pipeline_args:
            cmd.extend(case.extra_pipeline_args)

        print(f"==> [{case.tier.upper()}] Running custom pipeline for '{case.name}':")
        print(f"    $ {' '.join(shlex.quote(c) for c in cmd)}")
        proc = subprocess.run(
            cmd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=case.timeout_sec,
        )
        step_logs.append(f"--- Custom Pipeline Execution (exit={proc.returncode}) ---\n{proc.stdout}")
        if proc.returncode != 0:
            duration = time.time() - start_ts
            return {
                "name": case.name,
                "tier": case.tier,
                "status": "FAILED",
                "returncode": proc.returncode,
                "duration_sec": round(duration, 2),
                "comparison_metrics": [],
                "output": "\n".join(step_logs),
            }
    else:
        # Built-in Default IREE RISC-V 64 RVV Pipeline
        mlir_path = model_out_dir / f"{case.name}.mlir"
        vmfb_path = model_out_dir / f"{case.name}_riscv64_rvv.vmfb"

        iree_import_onnx = str(Path(iree_host_bin) / "iree-import-onnx") if iree_host_bin else "iree-import-onnx"
        iree_compile = str(Path(iree_host_bin) / "iree-compile") if iree_host_bin else "iree-compile"
        iree_run_module = str(Path(iree_riscv_bin) / "iree-run-module") if iree_riscv_bin else "iree-run-module"

        cmd_import = [
            iree_import_onnx,
            case.onnx_path,
            "--opset-version", str(case.opset_version),
            "-o", str(mlir_path),
        ]
        cmd_compile = [
            iree_compile,
            str(mlir_path),
            "--iree-hal-target-device=local",
            "--iree-hal-local-target-device-backends=llvm-cpu",
            "--iree-llvmcpu-target-triple=riscv64-unknown-linux-gnu",
            "--iree-llvmcpu-target-abi=lp64d",
            f"--iree-llvmcpu-target-cpu-features={case.rvv_cpu_features}",
            f"--riscv-v-fixed-length-vector-lmul-max={case.rvv_lmul_max}",
            "--iree-opt-data-tiling",
            "--iree-llvmcpu-enable-ukernels=all",
            *case.extra_compile_flags,
            "-o", str(vmfb_path),
        ]

        cmd_run = []
        if qemu_bin:
            cmd_run.extend([qemu_bin, "-cpu", "rv64,v=true,vlen=256,vext_spec=v1.0"])
            if sysroot:
                cmd_run.extend(["-L", sysroot])
        cmd_run.extend([
            iree_run_module,
            "--device=local-task",
            f"--module={vmfb_path}",
            f"--function={case.entry_function}",
            *iree_input_flags,
            *iree_output_flags,
        ])

        for step_name, step_cmd in [
            ("1. ONNX -> MLIR Import", cmd_import),
            ("2. IREE RVV Cross-Compile", cmd_compile),
            ("3. RISC-V RVV Execution (with NumPy .npy I/O)", cmd_run),
        ]:
            print(f"==> [{case.tier.upper()}] {case.name} :: {step_name}")
            print(f"    $ {' '.join(shlex.quote(c) for c in step_cmd)}")
            proc = subprocess.run(
                step_cmd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=case.timeout_sec,
            )
            step_logs.append(f"--- {step_name} (exit={proc.returncode}) ---\n{proc.stdout}")
            if proc.returncode != 0:
                duration = time.time() - start_ts
                return {
                    "name": case.name,
                    "tier": case.tier,
                    "status": "FAILED",
                    "returncode": proc.returncode,
                    "duration_sec": round(duration, 2),
                    "comparison_metrics": [],
                    "output": "\n".join(step_logs),
                }

    # Step 4: Compare ONNX Runtime NumPy outputs vs. IREE RISC-V 64 RVV NumPy outputs
    comparison_metrics: List[Dict[str, Any]] = []
    if compare_ort:
        print(f"==> [{case.tier.upper()}] {case.name} :: 4. Comparing ONNX Runtime vs. IREE RVV NumPy Outputs")
        cmp_ok, comparison_metrics, cmp_log = compare_numpy_outputs(
            ort_output_paths=ort_output_paths,
            iree_output_paths=expected_iree_output_paths,
            atol=case.atol,
            rtol=case.rtol,
        )
        print(cmp_log)
        step_logs.append(cmp_log)

        # Save per-model comparison report JSON
        report_json_path = model_out_dir / "comparison_report.json"
        report_json_path.write_text(
            json.dumps({
                "model": case.name,
                "tier": case.tier,
                "status": "PASSED" if cmp_ok else "FAILED",
                "atol": case.atol,
                "rtol": case.rtol,
                "outputs": comparison_metrics,
            }, indent=2),
            encoding="utf-8",
        )

        if not cmp_ok:
            duration = time.time() - start_ts
            return {
                "name": case.name,
                "tier": case.tier,
                "status": "FAILED",
                "returncode": 2,
                "duration_sec": round(duration, 2),
                "comparison_metrics": comparison_metrics,
                "output": "\n".join(step_logs),
            }

    duration = time.time() - start_ts
    return {
        "name": case.name,
        "tier": case.tier,
        "status": "PASSED",
        "returncode": 0,
        "duration_sec": round(duration, 2),
        "comparison_metrics": comparison_metrics,
        "output": "\n".join(step_logs),
    }


def write_reports(results: List[Dict[str, Any]], xml_path: Path, suite_name: str) -> None:
    """Writes JUnit XML, JSON summary, and Markdown comparison table for GitHub Actions."""
    xml_path.parent.mkdir(parents=True, exist_ok=True)
    failures = sum(1 for r in results if r["status"] != "PASSED")
    total_time = sum(r.get("duration_sec", 0.0) for r in results)

    testsuite = ET.Element(
        "testsuite",
        name=suite_name,
        tests=str(len(results)),
        failures=str(failures),
        time=f"{total_time:.2f}",
    )
    for res in results:
        tc = ET.SubElement(
            testsuite,
            "testcase",
            classname=f"iree.riscv64.rvv.onnx.{res['tier']}",
            name=res["name"],
            time=f"{res.get('duration_sec', 0.0):.2f}",
        )
        if res["status"] != "PASSED":
            fail = ET.SubElement(tc, "failure", message=f"Exit code {res['returncode']}")
            fail.text = res.get("output", "")[-8000:]

    tree = ET.ElementTree(testsuite)
    tree.write(xml_path, encoding="utf-8", xml_declaration=True)

    # Also write a Markdown summary table of ONNX Runtime vs IREE RVV NumPy comparisons
    md_path = xml_path.parent / "comparison_summary.md"
    md_lines = [
        f"## ONNX Runtime vs. IREE RISC-V 64 (RVV) Numerical Comparison (`{suite_name}`)",
        "",
        "| Model | Tier | Output # | Shape | Max Abs Diff | Mean Abs Diff | Cosine Sim | Tolerance (`atol` / `rtol`) | Status |",
        "| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |",
    ]
    for res in results:
        metrics = res.get("comparison_metrics") or []
        if not metrics:
            md_lines.append(
                f"| `{res['name']}` | `{res['tier']}` | - | - | - | - | - | - | **{res['status']}** |"
            )
        for m in metrics:
            if "max_abs_diff" in m:
                shape_str = "x".join(str(x) for x in m.get("shape", []))
                md_lines.append(
                    f"| `{res['name']}` | `{res['tier']}` | #{m['output_index']} | `{shape_str}` "
                    f"| `{m['max_abs_diff']:.4e}` | `{m['mean_abs_diff']:.4e}` | `{m['cosine_similarity']:.6f}` "
                    f"| `{m['atol']}` / `{m['rtol']}` | **{m['status']}** |"
                )
            else:
                md_lines.append(
                    f"| `{res['name']}` | `{res['tier']}` | #{m.get('output_index', 0)} | - | - | - | - "
                    f"| - | **{m.get('status', 'FAILED')}** ({m.get('error', '')}) |"
                )
    md_path.write_text("\n".join(md_lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="IREE RISC-V 64 RVV ONNX Auto-Discovery, Runner & ONNX Runtime NumPy Comparator"
    )
    parser.add_argument("--models-root", type=Path, default=Path("tests/onnx_models"),
                        help="Root directory scanned recursively for .onnx models and weights")
    parser.add_argument("--tier", choices=["pr", "stable", "nightly", "all"], default="all",
                        help="Filter models by CI tier (pr, stable, nightly, all)")
    parser.add_argument("--model-name", type=str, default=None,
                        help="Optional: run only a specific discovered model by name")
    parser.add_argument("--emit-matrix", action="store_true",
                        help="Emit a GitHub Actions compatible JSON matrix of discovered models")
    parser.add_argument("--emit-ctest", type=Path, default=None,
                        help="Write auto-generated CTestTestfile.cmake for discovered ONNX models")
    parser.add_argument("--run", action="store_true",
                        help="Execute discovered ONNX models and compare ONNX Runtime vs IREE RVV")
    parser.add_argument("--no-compare-ort", action="store_true",
                        help="Skip ONNX Runtime golden reference comparison")
    parser.add_argument("--compare-only", nargs=2, metavar=("ORT_NPY", "IREE_NPY"),
                        help="Standalone mode: directly compare two .npy files (ORT_NPY vs IREE_NPY)")
    parser.add_argument("--atol", type=float, default=1e-3,
                        help="Absolute tolerance for standalone --compare-only mode")
    parser.add_argument("--rtol", type=float, default=1e-3,
                        help="Relative tolerance for standalone --compare-only mode")
    parser.add_argument("--pipeline-script", type=str,
                        default=os.environ.get("CUSTOM_PIPELINE_SCRIPT", ""),
                        help="Path to your custom pipeline script (or set CUSTOM_PIPELINE_SCRIPT)")
    parser.add_argument("--work-dir", type=Path, default=Path("build-onnx-rvv-artifacts"),
                        help="Directory to store compiled MLIR, VMFB, .npy outputs, and comparison reports")
    parser.add_argument("--junit-xml", type=Path, default=Path("build-onnx-rvv-artifacts/junit_onnx_rvv.xml"),
                        help="Output path for JUnit XML test report")
    parser.add_argument("--iree-host-bin", type=str, default=os.environ.get("IREE_HOST_BIN_DIR", ""),
                        help="Path to host IREE tools (iree-compile, iree-import-onnx)")
    parser.add_argument("--iree-riscv-bin", type=str, default=os.environ.get("IREE_RISCV_BIN_DIR", ""),
                        help="Path to cross-compiled RISC-V IREE tools (iree-run-module)")
    parser.add_argument("--qemu-bin", type=str, default=os.environ.get("QEMU_RISCV64_BIN", "qemu-riscv64"),
                        help="Path to qemu-riscv64 binary (set empty string if running on native RISC-V hardware)")
    parser.add_argument("--sysroot", type=str, default=os.environ.get("RISCV_SYSROOT", ""),
                        help="Path to RISC-V sysroot for QEMU -L")

    args = parser.parse_args()

    # Standalone NumPy file comparison mode (--compare-only ort_out.npy iree_out.npy)
    if args.compare_only:
        ort_p = Path(args.compare_only[0])
        iree_p = Path(args.compare_only[1])
        ok, _, log_str = compare_numpy_outputs([ort_p], [iree_p], atol=args.atol, rtol=args.rtol)
        print(log_str)
        return 0 if ok else 1

    cases = discover_models(args.models_root, args.tier)

    if args.model_name:
        cases = [c for c in cases if c.name == args.model_name]

    if args.emit_matrix:
        matrix = {
            "include": [
                {
                    "name": c.name,
                    "tier": c.tier,
                    "onnx_path": c.onnx_path,
                    "weights": ",".join(c.weights_paths),
                    "rvv_features": c.rvv_cpu_features,
                }
                for c in cases
            ]
        }
        print(json.dumps(matrix))
        return 0

    if args.emit_ctest:
        lines = ["# Auto-generated CTest definitions for IREE RISC-V 64 RVV ONNX models"]
        for c in cases:
            test_id = f"iree_rvv_onnx_{c.tier}_{c.name}"
            cmd_parts = [
                sys.executable,
                str(Path(__file__).resolve()),
                "--models-root", str(args.models_root.resolve()),
                "--tier", c.tier,
                "--model-name", c.name,
                "--run",
            ]
            if args.pipeline_script:
                cmd_parts.extend(["--pipeline-script", args.pipeline_script])
            quoted = " ".join(f'"{p}"' for p in cmd_parts)
            lines.append(f"add_test({test_id} {quoted})")
            lines.append(f'set_tests_properties({test_id} PROPERTIES LABELS "onnx;rvv;{c.tier}")')
        args.emit_ctest.parent.mkdir(parents=True, exist_ok=True)
        args.emit_ctest.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"Wrote {len(cases)} CTest definitions to {args.emit_ctest}")
        return 0

    if not args.run:
        print(f"Discovered {len(cases)} ONNX model(s) for tier='{args.tier}':")
        for c in cases:
            w_info = f" (+{len(c.weights_paths)} weight file(s): {', '.join(Path(w).name for w in c.weights_paths)})" if c.weights_paths else " (embedded weights)"
            print(f"  - [{c.tier.upper()}] {c.name}: {c.onnx_path}{w_info} | PR={c.run_on_pr} | atol={c.atol}, rtol={c.rtol}")
        return 0

    if not cases:
        print(f"[INFO] No ONNX models found under {args.models_root} for tier '{args.tier}'.")
        return 0

    results = []
    for c in cases:
        res = run_single_model(
            case=c,
            pipeline_script=args.pipeline_script if args.pipeline_script else None,
            work_dir=args.work_dir,
            iree_host_bin=args.iree_host_bin,
            iree_riscv_bin=args.iree_riscv_bin,
            qemu_bin=args.qemu_bin,
            sysroot=args.sysroot,
            compare_ort=not args.no_compare_ort,
        )
        results.append(res)
        print(f"    -> [{res['status']}] {c.name} ({res['duration_sec']}s)")

    write_reports(results, args.junit_xml, suite_name=f"iree_riscv64_rvv_onnx_{args.tier}")
    failed = [r for r in results if r["status"] != "PASSED"]
    print(f"\nSummary: {len(results) - len(failed)}/{len(results)} ONNX models passed ONNX Runtime vs. IREE RVV verification.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())