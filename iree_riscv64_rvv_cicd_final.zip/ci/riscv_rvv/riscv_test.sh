#!/usr/bin/env bash
# ==============================================================================
# Enhanced IREE RISC-V 64 (RVV 1.0) CTest Runner (riscv_test.sh)
# ==============================================================================
# Why a stock riscv_test.sh / ctest_all.sh often misses or silently skips RVV ukernels:
#   1. Standalone ukernel tests (mmt4d_test, pack_test, unpack_test) do NOT have
#      the "driver=local-task" CTest label (they call C microkernels directly
#      without a HAL driver). Any script filtering by `-L driver=local-task`
#      completely skips all ukernel tests!
#   2. If QEMU_CPU does not explicitly enable RVV 1.0 (`v=true,vlen=256,vext_spec=v1.0`),
#      mmt4d_test hits ALLOW_GENERIC_FALLBACK and passes without testing RVV code!
#   3. Data-tiling and ukernels are off by default on RISC-V unless e2e_matmul
#      data-tiled targets (`e2e_matmul_cpu_dt_*`) and ukernel tests are explicitly run.
#
# Usage:
#   ./riscv_test.sh [RISCV_BUILD_DIR] [--stage pr|nightly|stable]
# ==============================================================================
set -euo pipefail

BUILD_DIR="${RISCV_BUILD_DIR:-build-riscv64-rvv}"
STAGE="${STAGE:-pr}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage) STAGE="$2"; shift 2 ;;
    --build-dir) BUILD_DIR="$2"; shift 2 ;;
    -*) echo "[ERROR] Unknown option: $1" >&2; exit 1 ;;
    *) BUILD_DIR="$1"; shift ;;
  esac
done

# 1. Force QEMU RVV 1.0 Vector Emulation so ukernels execute real RVV instructions
export QEMU_CPU="${QEMU_CPU:-rv64,v=true,vlen=256,vext_spec=v1.0}"
export IREE_VULKAN_DISABLE="${IREE_VULKAN_DISABLE:-1}"
export IREE_CUDA_DISABLE="${IREE_CUDA_DISABLE:-1}"
export IREE_HIP_DISABLE="${IREE_HIP_DISABLE:-1}"
JOBS="${CTEST_PARALLEL_LEVEL:-$(nproc || echo 4)}"
JUNIT_DIR="${ARTIFACTS_ROOT:-build-ci-artifacts}/junit_core_${STAGE}"
mkdir -p "${JUNIT_DIR}"

echo "=============================================================================="
echo "Running IREE RISC-V 64 (RVV) Target Tests via riscv_test.sh"
echo "  Build Dir : ${BUILD_DIR}"
echo "  CI Stage  : ${STAGE}"
echo "  QEMU_CPU  : ${QEMU_CPU}"
echo "=============================================================================="

# ------------------------------------------------------------------------------
# STEP 1 (MANDATORY): Explicitly Run RVV Microkernel (ukernel) Unit Tests First
# ------------------------------------------------------------------------------
# Note: Never pass `-L driver=local-task` here because ukernel unit tests
# (mmt4d_test, pack_test, unpack_test, query_tile_sizes_test) do not use a HAL
# driver and do not carry a driver=* label.
echo "==> [riscv_test.sh :: 1/2] Running RVV Microkernel Unit Tests (mmt4d, pack, unpack)..."
ctest --test-dir "${BUILD_DIR}" \
  --tests-regex "ukernel" \
  --output-on-failure \
  --parallel "${JOBS}" \
  --output-junit "${JUNIT_DIR}/junit_riscv_rvv_ukernel.xml"

# ------------------------------------------------------------------------------
# STEP 2: Run Runtime HAL/VM, Check Suite & E2E Data-Tiled Matmul Tests
# ------------------------------------------------------------------------------
CTEST_ARGS=(
  "--test-dir" "${BUILD_DIR}"
  "--output-on-failure"
  "--parallel" "${JOBS}"
  "--label-exclude" "nokokoro|driver=vulkan|driver=cuda|driver=metal|driver=hip|hostonly"
  "--exclude-regex" "ukernel"
)

if [[ "${STAGE}" == "pr" ]]; then
  # Fast PR Gate: run core runtime + check_llvm-cpu + e2e_matmul (including data-tiled RVV matmuls)
  PR_REGEX="${IREE_CTEST_TESTS_REGEX:-iree/base|iree/hal|iree/vm|check_llvm-cpu|e2e_matmul}"
  echo "==> [riscv_test.sh :: 2/2] Running Fast PR Gate Subset (${PR_REGEX})..."
  CTEST_ARGS+=("--tests-regex" "${PR_REGEX}")
else
  echo "==> [riscv_test.sh :: 2/2] Running Full RISC-V 64 Target CTest Suite (${STAGE})..."
  if [[ -n "${IREE_CTEST_TESTS_REGEX:-}" ]]; then
    CTEST_ARGS+=("--tests-regex" "${IREE_CTEST_TESTS_REGEX}")
  fi
fi

CTEST_ARGS+=("--output-junit" "${JUNIT_DIR}/junit_riscv_target_${STAGE}.xml")
ctest "${CTEST_ARGS[@]}"

echo "==> [riscv_test.sh] All RISC-V 64 RVV ukernel and target tests passed!"
