#!/usr/bin/env python3
"""
MODULE 03: Standalone ONNX Runtime vs. IREE RISC-V 64 (RVV) NumPy Comparator
============================================================================
Can be called directly by any CI script or custom pipeline script in two modes:

Mode A — Prepare Inputs & Run ONNX Runtime Golden Reference:
  python3 ci/riscv_rvv/modules/03_ort_vs_iree_numpy.py prepare \
    --onnx model.onnx \
    --inputs-dir /tmp/model_run/inputs \
    --ort-outputs-dir /tmp/model_run/ort_outputs \
    --seed 42

Mode B — Compare ONNX Runtime .npy Outputs vs. IREE RVV .npy Outputs:
  python3 ci/riscv_rvv/modules/03_ort_vs_iree_numpy.py compare \
    --ort-outputs /tmp/model_run/ort_outputs/ort_output_0.npy \
    --iree-outputs /tmp/model_run/iree_outputs/iree_output_0.npy \
    --atol 1e-3 --rtol 1e-3 \
    --report-json /tmp/model_run/comparison_report.json
"""

import argparse
import json
import sys
from pathlib import Path
from typing import List, Tuple, Dict, Any

import numpy as np

ORT_TYPE_TO_NP = {
    "tensor(float)": np.float32,
    "tensor(float16)": np.float16,
    "tensor(double)": np.float64,
    "tensor(int64)": np.int64,
    "tensor(int32)": np.int32,
    "tensor(int16)": np.int16,
    "tensor(int8)": np.int8,
    "tensor(uint8)": np.uint8,
    "tensor(bool)": np.bool_,
}

IREE_DTYPE_TO_NP = {
    "f32": np.float32,
    "f16": np.float16,
    "f64": np.float64,
    "i64": np.int64,
    "i32": np.int32,
    "i16": np.int16,
    "i8": np.int8,
    "u8": np.uint8,
    "i1": np.bool_,
}


def parse_iree_shape_spec(spec: str) -> Tuple[Tuple[int, ...], Any]:
    lhs = spec.split("=")[0].strip()
    parts = lhs.split("x")
    dtype_str = parts[-1].lower()
    dims = tuple(int(d) for d in parts[:-1]) if len(parts) > 1 else (1,)
    np_dtype = IREE_DTYPE_TO_NP.get(dtype_str, np.float32)
    return dims, np_dtype


def make_random_array(shape: Tuple[int, ...], np_dtype: Any, rng: np.random.Generator) -> np.ndarray:
    if np.issubdtype(np_dtype, np.floating):
        return rng.uniform(-1.0, 1.0, size=shape).astype(np_dtype)
    elif np.issubdtype(np_dtype, np.bool_):
        return rng.integers(0, 2, size=shape).astype(np_dtype)
    else:
        return rng.integers(0, 10, size=shape).astype(np_dtype)


def prepare_ort_golden(
    onnx_path: str,
    model_dir: str,
    inputs_dir: Path,
    ort_outputs_dir: Path,
    input_specs: List[str],
    seed: int = 42,
) -> Tuple[List[Path], List[Path], str]:
    import onnxruntime as ort

    inputs_dir.mkdir(parents=True, exist_ok=True)
    ort_outputs_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    logs = []

    sess = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
    ort_inputs = sess.get_inputs()
    ort_outputs_meta = sess.get_outputs()

    feed_dict: Dict[str, np.ndarray] = {}
    input_npy_paths: List[Path] = []

    for idx, inp_meta in enumerate(ort_inputs):
        custom_by_name = Path(model_dir) / f"{inp_meta.name}.npy"
        custom_by_idx = Path(model_dir) / f"input_{idx}.npy"

        if custom_by_name.exists():
            arr = np.load(custom_by_name)
            logs.append(f"Loaded custom input '{inp_meta.name}' from {custom_by_name}: shape={arr.shape}, dtype={arr.dtype}")
        elif custom_by_idx.exists():
            arr = np.load(custom_by_idx)
            logs.append(f"Loaded custom input '{inp_meta.name}' from {custom_by_idx}: shape={arr.shape}, dtype={arr.dtype}")
        elif idx < len(input_specs) and input_specs[idx]:
            shape, np_dtype = parse_iree_shape_spec(input_specs[idx])
            arr = make_random_array(shape, np_dtype, rng)
            logs.append(f"Generated input #{idx} ('{inp_meta.name}') from spec '{input_specs[idx]}': shape={arr.shape}, dtype={arr.dtype}")
        else:
            resolved_shape = tuple(
                int(d) if isinstance(d, int) and d > 0 else 1
                for d in (inp_meta.shape or [1])
            )
            np_dtype = ORT_TYPE_TO_NP.get(inp_meta.type, np.float32)
            arr = make_random_array(resolved_shape, np_dtype, rng)
            logs.append(f"Auto-generated input #{idx} ('{inp_meta.name}'): shape={arr.shape}, dtype={arr.dtype}")

        npy_path = inputs_dir / f"input_{idx}.npy"
        np.save(npy_path, arr)
        feed_dict[inp_meta.name] = arr
        input_npy_paths.append(npy_path)

    output_names = [o.name for o in ort_outputs_meta]
    ort_results = sess.run(output_names, feed_dict)

    ort_output_paths: List[Path] = []
    for idx, (out_name, out_arr) in enumerate(zip(output_names, ort_results)):
        out_arr_np = np.asarray(out_arr)
        out_path = ort_outputs_dir / f"ort_output_{idx}.npy"
        np.save(out_path, out_arr_np)
        ort_output_paths.append(out_path)
        logs.append(
            f"ONNX Runtime output #{idx} ('{out_name}') -> {out_path.name}: "
            f"shape={out_arr_np.shape}, dtype={out_arr_np.dtype}"
        )

    return input_npy_paths, ort_output_paths, "\n".join(logs)


def compare_numpy_outputs(
    ort_output_paths: List[Path],
    iree_output_paths: List[Path],
    atol: float,
    rtol: float,
) -> Tuple[bool, List[Dict[str, Any]], str]:
    if len(ort_output_paths) != len(iree_output_paths):
        msg = f"[FAIL] Output count mismatch: ONNX Runtime={len(ort_output_paths)} vs IREE={len(iree_output_paths)}."
        return False, [], msg

    all_passed = True
    metrics_list: List[Dict[str, Any]] = []
    lines = [
        "================================================================================",
        f"NUMPY COMPARISON: ONNX Runtime (Golden) vs. IREE RISC-V 64 RVV (atol={atol}, rtol={rtol})",
        "================================================================================",
    ]

    for idx, (ort_path, iree_path) in enumerate(zip(ort_output_paths, iree_output_paths)):
        if not iree_path.exists():
            all_passed = False
            lines.append(f"  [Output #{idx}] MISSING IREE output file: {iree_path}")
            metrics_list.append({"output_index": idx, "status": "FAILED", "error": f"Missing {iree_path}"})
            continue

        ort_arr = np.load(ort_path)
        iree_arr = np.load(iree_path)

        if ort_arr.shape != iree_arr.shape:
            all_passed = False
            lines.append(f"  [Output #{idx}] SHAPE MISMATCH: ORT={ort_arr.shape} vs IREE={iree_arr.shape}")
            metrics_list.append({
                "output_index": idx,
                "status": "FAILED",
                "ort_shape": list(ort_arr.shape),
                "iree_shape": list(iree_arr.shape),
                "error": "Shape mismatch",
            })
            continue

        ort_f64 = ort_arr.astype(np.float64).ravel()
        iree_f64 = iree_arr.astype(np.float64).ravel()

        abs_diff = np.abs(ort_f64 - iree_f64)
        max_abs_diff = float(np.max(abs_diff)) if abs_diff.size > 0 else 0.0
        mean_abs_diff = float(np.mean(abs_diff)) if abs_diff.size > 0 else 0.0
        rmse = float(np.sqrt(np.mean((ort_f64 - iree_f64) ** 2))) if abs_diff.size > 0 else 0.0

        denom = np.maximum(np.abs(ort_f64), 1e-12)
        max_rel_diff = float(np.max(abs_diff / denom)) if abs_diff.size > 0 else 0.0

        norm_ort = float(np.linalg.norm(ort_f64))
        norm_iree = float(np.linalg.norm(iree_f64))
        if norm_ort > 0 and norm_iree > 0:
            cosine_sim = float(np.dot(ort_f64, iree_f64) / (norm_ort * norm_iree))
        elif norm_ort == 0 and norm_iree == 0:
            cosine_sim = 1.0
        else:
            cosine_sim = 0.0

        is_close = bool(np.allclose(ort_arr, iree_arr, rtol=rtol, atol=atol, equal_nan=True))
        if not is_close:
            all_passed = False

        status_str = "MATCH (PASSED)" if is_close else "MISMATCH (FAILED)"
        lines.append(
            f"  [Output #{idx}] {status_str} | shape={ort_arr.shape} dtype={ort_arr.dtype}\n"
            f"      max_abs_diff = {max_abs_diff:.6e} | mean_abs_diff = {mean_abs_diff:.6e}\n"
            f"      max_rel_diff = {max_rel_diff:.6e} | RMSE          = {rmse:.6e} | cosine_sim = {cosine_sim:.6f}"
        )
        metrics_list.append({
            "output_index": idx,
            "status": "PASSED" if is_close else "FAILED",
            "shape": list(ort_arr.shape),
            "dtype": str(ort_arr.dtype),
            "max_abs_diff": max_abs_diff,
            "mean_abs_diff": mean_abs_diff,
            "max_rel_diff": max_rel_diff,
            "rmse": rmse,
            "cosine_similarity": cosine_sim,
            "atol": atol,
            "rtol": rtol,
        })

    lines.append("================================================================================")
    return all_passed, metrics_list, "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Standalone ONNX Runtime vs. IREE NumPy Comparator")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_prep = sub.add_parser("prepare", help="Generate input .npy files and run ONNX Runtime golden reference")
    p_prep.add_argument("--onnx", required=True, help="Path to .onnx model file")
    p_prep.add_argument("--model-dir", default="", help="Directory containing model/custom inputs")
    p_prep.add_argument("--inputs-dir", type=Path, required=True, help="Directory to write input_*.npy")
    p_prep.add_argument("--ort-outputs-dir", type=Path, required=True, help="Directory to write ort_output_*.npy")
    p_prep.add_argument("--input-specs", nargs="*", default=[], help="Optional IREE input shape specs")
    p_prep.add_argument("--seed", type=int, default=42)

    p_cmp = sub.add_parser("compare", help="Compare ONNX Runtime .npy outputs against IREE .npy outputs")
    p_cmp.add_argument("--ort-outputs", nargs="+", type=Path, required=True, help="ORT golden .npy files")
    p_cmp.add_argument("--iree-outputs", nargs="+", type=Path, required=True, help="IREE .npy files")
    p_cmp.add_argument("--atol", type=float, default=1e-3)
    p_cmp.add_argument("--rtol", type=float, default=1e-3)
    p_cmp.add_argument("--report-json", type=Path, default=None)

    args = parser.parse_args()
    if args.cmd == "prepare":
        model_dir = args.model_dir or str(Path(args.onnx).parent)
        _, _, log_str = prepare_ort_golden(
            onnx_path=args.onnx,
            model_dir=model_dir,
            inputs_dir=args.inputs_dir,
            ort_outputs_dir=args.ort_outputs_dir,
            input_specs=args.input_specs,
            seed=args.seed,
        )
        print(log_str)
        return 0
    elif args.cmd == "compare":
        ok, metrics, log_str = compare_numpy_outputs(
            ort_output_paths=args.ort_outputs,
            iree_output_paths=args.iree_outputs,
            atol=args.atol,
            rtol=args.rtol,
        )
        print(log_str)
        if args.report_json:
            args.report_json.parent.mkdir(parents=True, exist_ok=True)
            args.report_json.write_text(
                json.dumps({"status": "PASSED" if ok else "FAILED", "outputs": metrics}, indent=2),
                encoding="utf-8",
            )
        return 0 if ok else 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
