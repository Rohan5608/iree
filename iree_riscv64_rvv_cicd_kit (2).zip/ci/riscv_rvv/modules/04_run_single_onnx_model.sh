#!/usr/bin/env bash
# ==============================================================================
# MODULE 04: Single ONNX Model Execution Wrapper (Custom Script or IREE RVV Flow)
# ==============================================================================
# Invoked automatically by discover_and_run_onnx.py for each discovered model,
# OR can be called directly by the CI/CD team for a single model.
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../config.env"

echo "=================================================================="
echo "Model            : ${ONNX_MODEL_NAME} (Tier: ${ONNX_MODEL_TIER})"
echo "ONNX File        : ${ONNX_MODEL_PATH}"
echo "Weights          : ${ONNX_WEIGHTS_PATHS:-<embedded in .onnx>}"
echo "Input .npy Files : ${ONNX_INPUT_NPY_FILES}"
echo "ORT Golden .npy  : ${ORT_OUTPUT_NPY_FILES}"
echo "IREE Target .npy : ${IREE_OUTPUT_NPY_FILES}"
echo "=================================================================="

# If USER_ACTUAL_SCRIPT is configured and executable, delegate to your script:
if [[ -n "${USER_ACTUAL_SCRIPT:-}" && -x "${USER_ACTUAL_SCRIPT}" ]]; then
  echo "[Module 04] Delegating to custom pipeline script: ${USER_ACTUAL_SCRIPT}"
  exec "${USER_ACTUAL_SCRIPT}" \
    "${ONNX_MODEL_PATH}" \
    "${ONNX_FIRST_WEIGHT_PATH:-}" \
    "${MODEL_ARTIFACT_DIR}" \
    "${ONNX_MODEL_TIER}" \
    "${ONNX_INPUT_NPY_FILES}" \
    "${IREE_OUTPUT_NPY_FILES}"
fi

# Built-in Standard IREE ONNX -> MLIR -> RISC-V 64 RVV VMFB -> QEMU/Hardware Flow
MLIR_OUT="${MODEL_ARTIFACT_DIR}/${ONNX_MODEL_NAME}.mlir"
VMFB_OUT="${MODEL_ARTIFACT_DIR}/${ONNX_MODEL_NAME}_riscv64_rvv.vmfb"

IREE_IMPORT_ONNX="${IREE_HOST_BIN_DIR:+${IREE_HOST_BIN_DIR}/}iree-import-onnx"
IREE_COMPILE="${IREE_HOST_BIN_DIR:+${IREE_HOST_BIN_DIR}/}iree-compile"
IREE_RUN_MODULE="${IREE_RISCV_BIN_DIR:+${IREE_RISCV_BIN_DIR}/}iree-run-module"

# 1. Import ONNX (+ external weights in same directory) to MLIR
"${IREE_IMPORT_ONNX}" "${ONNX_MODEL_PATH}" \
  --opset-version "${ONNX_OPSET_VERSION:-17}" \
  -o "${MLIR_OUT}"

# 2. Compile MLIR to RISC-V 64 RVV VMFB (with data-tiling & RVV ukernels enabled)
"${IREE_COMPILE}" "${MLIR_OUT}" \
  --iree-hal-target-device=local \
  --iree-hal-local-target-device-backends=llvm-cpu \
  --iree-llvmcpu-target-triple="${IREE_RVV_TARGET_TRIPLE}" \
  --iree-llvmcpu-target-abi="${IREE_RVV_TARGET_ABI}" \
  --iree-llvmcpu-target-cpu-features="${IREE_RVV_CPU_FEATURES}" \
  --riscv-v-fixed-length-vector-lmul-max="${IREE_RVV_LMUL_MAX:-8}" \
  --iree-opt-data-tiling \
  --iree-llvmcpu-enable-ukernels="${IREE_ENABLE_UKERNELS:-all}" \
  -o "${VMFB_OUT}"

# 3. Assemble --input=@.../input_0.npy and --output=@.../iree_output_0.npy flags
IFS=':' read -r -a IN_NPY_ARR <<< "${ONNX_INPUT_NPY_FILES:-}"
RUN_IO_FLAGS=()
for npy in "${IN_NPY_ARR[@]}"; do
  [[ -n "${npy}" ]] && RUN_IO_FLAGS+=("--input=@${npy}")
done

IFS=':' read -r -a OUT_NPY_ARR <<< "${IREE_OUTPUT_NPY_FILES:-}"
for npy in "${OUT_NPY_ARR[@]}"; do
  [[ -n "${npy}" ]] && RUN_IO_FLAGS+=("--output=@${npy}")
done

# 4. Run on QEMU (RVV 1.0) or physical RISC-V 64 board and write IREE .npy outputs
if [[ -n "${QEMU_RISCV64_BIN:-}" ]]; then
  "${QEMU_RISCV64_BIN}" \
    -cpu "${QEMU_CPU_ARGS}" \
    ${RISCV_SYSROOT:+-L "${RISCV_SYSROOT}"} \
    "${IREE_RUN_MODULE}" \
    --device=local-task \
    --module="${VMFB_OUT}" \
    --function="${ONNX_ENTRY_FUNCTION}" \
    "${RUN_IO_FLAGS[@]}"
else
  "${IREE_RUN_MODULE}" \
    --device=local-task \
    --module="${VMFB_OUT}" \
    --function="${ONNX_ENTRY_FUNCTION}" \
    "${RUN_IO_FLAGS[@]}"
fi
