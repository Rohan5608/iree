#!/usr/bin/env bash
# ==============================================================================
# MODULE 02: Run IREE Core CTest Suites by CI Stage (pr | nightly | stable)
# ==============================================================================
# Usage:
#   ./ci/riscv_rvv/modules/02_run_iree_core_tests.sh --stage <pr|nightly|stable>
#
# Test Layers Executed:
#   Layer A: Host Compiler Lit Tests (RISC-V & LLVMCPU RVV codegen / tile selection)
#   Layer B: RISC-V 64 RVV Microkernel Tests (mmt4d, pack, unpack, tile sizes)
#   Layer C: Core Runtime / HAL / VM Unit Tests (local-task driver, ELF loader)
#   Layer D: End-to-End Data-Tiled Matmul & Check Smoke Tests (e2e_matmul_cpu_dt_*)
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../config.env"

STAGE="pr"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage) STAGE="$2"; shift 2 ;;
    *) echo "[ERROR] Unknown argument: $1" >&2; exit 1 ;;
  esac
done

JUNIT_DIR="${ARTIFACTS_ROOT}/junit_core_${STAGE}"
mkdir -p "${JUNIT_DIR}"
JOBS="$(nproc || echo 4)"

echo "==> [Module 02] Layer A: Compiler Lit Tests (RISC-V & LLVMCPU RVV Codegen)"
if [[ "${STAGE}" == "nightly" ]]; then
  ctest --test-dir "${HOST_BUILD_DIR}" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_host_lit_full.xml"
else
  ctest --test-dir "${HOST_BUILD_DIR}" \
    -R "compiler/src/iree/compiler/Codegen/LLVMCPU|riscv" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_host_lit_riscv.xml"
fi

echo "==> [Module 02] Layer B: RISC-V 64 RVV Microkernel (ukernel: mmt4d/pack/unpack) Tests"
ctest --test-dir "${RISCV_BUILD_DIR}" \
  -R "ukernel" \
  --output-on-failure -j "${JOBS}" \
  --output-junit "${JUNIT_DIR}/junit_riscv_rvv_ukernel.xml"

echo "==> [Module 02] Layer C: RISC-V 64 Core Runtime, HAL & VM Tests"
if [[ "${STAGE}" == "pr" ]]; then
  ctest --test-dir "${RISCV_BUILD_DIR}" \
    -R "iree/base|iree/hal|iree/vm" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_riscv_runtime_core.xml"
else
  # Nightly & Stable run the full cross-compiled CTest tree
  ctest --test-dir "${RISCV_BUILD_DIR}" \
    --output-on-failure -j "${JOBS}" \
    --output-junit "${JUNIT_DIR}/junit_riscv_runtime_full.xml"
fi

echo "==> [Module 02] Layer D: End-to-End Data-Tiled Matmul & Check Suite (RVV Verification)"
ctest --test-dir "${RISCV_BUILD_DIR}" \
  -L "driver=local-task" \
  -R "check_llvm-cpu|e2e_matmul" \
  --output-on-failure -j "${JOBS}" \
  --output-junit "${JUNIT_DIR}/junit_riscv_e2e_matmul.xml"

echo "==> [Module 02] All Core IREE CTest Gates Passed for stage '${STAGE}'!"
