#!/usr/bin/env bash
# ==============================================================================
# MASTER CI/CD ENTRYPOINT FOR IREE RISC-V 64 (RVV)
# ==============================================================================
# Give this single command to your CI/CD team to wire into Jenkins, GitLab CI,
# GitHub Actions, or Buildkite:
#
#   1. Pull Request Gate:
#        ./ci/riscv_rvv/ci_entrypoint.sh --stage pr
#
#   2. Nightly Full Regression & Pre-Release Package:
#        ./ci/riscv_rvv/ci_entrypoint.sh --stage nightly
#
#   3. Stable Release Gate & Official Release Package:
#        ./ci/riscv_rvv/ci_entrypoint.sh --stage stable --release-version v1.0.0
#
# Optional modular flags (to run only specific steps in separate CI stages):
#   --skip-build          Skip Module 01 (use existing build-host & build-riscv64-rvv)
#   --skip-core-tests     Skip Module 02 (IREE CTest Lit / ukernel / HAL tests)
#   --skip-onnx-tests     Skip Module 03/04 (ONNX Auto-Discovery & ORT vs IREE comparison)
#   --package-release     Package release tarball + SHA256 checksum in dist/
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.env"

STAGE="pr"
RELEASE_VERSION=""
SKIP_BUILD=0
SKIP_CORE_TESTS=0
SKIP_ONNX_TESTS=0
PACKAGE_RELEASE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --stage) STAGE="$2"; shift 2 ;;
    --release-version) RELEASE_VERSION="$2"; PACKAGE_RELEASE=1; shift 2 ;;
    --skip-build) SKIP_BUILD=1; shift ;;
    --skip-core-tests) SKIP_CORE_TESTS=1; shift ;;
    --skip-onnx-tests) SKIP_ONNX_TESTS=1; shift ;;
    --package-release) PACKAGE_RELEASE=1; shift ;;
    *) echo "[ERROR] Unknown flag: $1" >&2; exit 1 ;;
  esac
done

if [[ "${STAGE}" == "nightly" || "${STAGE}" == "stable" ]]; then
  PACKAGE_RELEASE=1
fi

BUILD_TYPE="RelWithDebInfo"
if [[ "${STAGE}" == "stable" ]]; then
  BUILD_TYPE="Release"
fi

echo "=============================================================================="
echo "IREE RISC-V 64 (RVV) CI/CD Pipeline | Stage: ${STAGE^^} | Build: ${BUILD_TYPE}"
echo "=============================================================================="

# --- Module 01: Build Host Compiler + Cross-Compile RISC-V 64 RVV Runtime ---
if [[ "${SKIP_BUILD}" -eq 0 ]]; then
  "${SCRIPT_DIR}/modules/01_build_iree_rvv.sh" --build-type "${BUILD_TYPE}"
fi

# --- Module 02: Run IREE Core CTest Suites (Lit + RVV ukernels + E2E Matmul) ---
if [[ "${SKIP_CORE_TESTS}" -eq 0 ]]; then
  "${SCRIPT_DIR}/modules/02_run_iree_core_tests.sh" --stage "${STAGE}"
fi

# --- Module 03 & 04: Auto-Discover ONNX Models & Compare ORT vs. IREE NumPy ---
if [[ "${SKIP_ONNX_TESTS}" -eq 0 ]]; then
  python3 "${SCRIPT_DIR}/discover_and_run_onnx.py" \
    --models-root "${ONNX_MODELS_ROOT}" \
    --tier "${STAGE}" \
    --iree-host-bin "$(realpath "${HOST_INSTALL_DIR}/bin")" \
    --iree-riscv-bin "$(realpath "${RISCV_BUILD_DIR}/tools")" \
    --pipeline-script "${SCRIPT_DIR}/modules/04_run_single_onnx_model.sh" \
    --work-dir "${ARTIFACTS_ROOT}/onnx_${STAGE}" \
    --junit-xml "${ARTIFACTS_ROOT}/onnx_${STAGE}/junit_onnx_${STAGE}.xml" \
    --run
fi

# --- Module 05: Package Nightly / Stable Release Artifact Tarball ---
if [[ "${PACKAGE_RELEASE}" -eq 1 ]]; then
  if [[ -z "${RELEASE_VERSION}" ]]; then
    DATE_TAG="$(date -u +%Y%m%d)"
    RELEASE_VERSION="${STAGE}-riscv64-rvv-${DATE_TAG}"
  fi
  PKG_DIR="${ARTIFACTS_ROOT}/dist/iree-${RELEASE_VERSION}"
  mkdir -p "${PKG_DIR}/host-bin" "${PKG_DIR}/riscv64-bin"
  cp "${HOST_INSTALL_DIR}/bin/iree-compile" "${PKG_DIR}/host-bin/" || true
  cp "${HOST_INSTALL_DIR}/bin/iree-import-onnx" "${PKG_DIR}/host-bin/" || true
  cp "${RISCV_BUILD_DIR}/tools/iree-run-module" "${PKG_DIR}/riscv64-bin/" || true
  cp "${RISCV_BUILD_DIR}/tools/iree-benchmark-module" "${PKG_DIR}/riscv64-bin/" || true
  TARBALL="${ARTIFACTS_ROOT}/iree-${RELEASE_VERSION}.tar.gz"
  tar -czvf "${TARBALL}" -C "${ARTIFACTS_ROOT}/dist" "iree-${RELEASE_VERSION}"
  sha256sum "${TARBALL}" > "${TARBALL}.sha256"
  echo "==> Packaged Release Artifact: ${TARBALL} (+ .sha256)"
fi

echo "==> [SUCCESS] IREE RISC-V 64 (RVV) CI/CD Stage '${STAGE}' Completed!"
