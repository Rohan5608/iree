# IREE RISC-V 64 (`riscv64` RVV / VME) CI/CD Engineering & Handover Documentation

This document explains **what our RISC-V 64 Vector & Matrix (`riscv64` RVV / VME) CI/CD pipeline is trying to achieve**, **which script files run at every stage (with visual flow graphs)**, and **the exact copy-paste commands** (both modular script commands and raw underlying CLI commands) so the CI/CD team can wire up **Pull Request (PR)**, **Nightly Release**, and **Stable Release** pipelines in Jenkins, GitLab CI, GitHub Actions, or Buildkite without writing YAML from scratch.

---

## 1. Executive Summary: What Are We Trying to Do?

We maintain a fork of the [IREE (Intermediate Representation Execution Environment) compiler and runtime](https://github.com/iree-org/iree) targeting **64-bit RISC-V processors with Vector Extensions (`riscv64` RVV 1.0) and VME (Vector Matrix Extension) microkernels**.

Because standard CI servers run on `x86_64` Linux machines while our deployment target is `riscv64`, our CI/CD pipeline solves four problems automatically:

1. **Two-Stage Cross-Compilation ([IREE RISC-V Build Flow](https://iree.dev/building-from-source/riscv/))**:
   - **Host Build (`x86_64`)**: Compile the IREE compiler (`iree-compile`) and ONNX importer (`iree-import-onnx`) to run on the fast `x86_64` CI host while emitting `riscv64` RVV/VME machine code.
   - **Target Cross-Build (`riscv64`)**: Cross-compile the lightweight IREE runtime (`iree-run-module`, `iree-benchmark-module`, and microkernel test binaries) for `riscv64-unknown-linux-gnu` using [`build_tools/cmake/linux_riscv64.cmake`](https://github.com/iree-org/iree/blob/main/build_tools/cmake/linux_riscv64.cmake).
2. **Three-Tier Compiler & Runtime Verification (Lit → RVV/VME `ukernel` → `riscv_test.sh`)**:
   - Verify that MLIR compiler passes generate valid RISC-V vector/matrix instructions (`lit` tests), that hand-tuned RISC-V 64 C/assembly microkernels ([IREE CPU Microkernels](https://iree.dev/community/blog/2024-01-22-exploring-cpu-microkernels-on-a-matmul-example/#overview-of-the-compilation-and-linking-flow)) compute exact tile math (`ukernel` tests), and that `riscv_test.sh` executes core HAL/VM and `e2e_matmul` tests on the target.
3. **VME Ukernel ONNX & CTest Suite (`ci/riscv_rvv/vme_ukernel_suite/`)**:
   - Automatically generates `.onnx` test cases across **Conv2D** (`gen_conv2d_onnx.py`), **Unbatched 2D MatMul** (`gen_matmul_onnx.py`), and **Combined Conv2D + MatMul Models** (`gen_conv_matmul_model_onnx.py`), and harnesses every dimension case into CTest (`ctest -R "vme_ukernel"`).
4. **End-to-End Numerical Accuracy Verification (IREE VME Ukernel Path First → ONNX Runtime → NumPy Compare)**:
   - Every CTest case in `vme_ukernel_suite` feeds deterministic NumPy inputs (`input_0.npy`) **first** through the **IREE VME Ukernel Path** (`iree-import-onnx` → `iree-compile` with `--iree-opt-data-tiling --iree-llvmcpu-enable-ukernels=all --iree-global-opt-use-im2col-for-convs=true` → `iree-run-module` saving `iree_output_0.npy`), **then** through **ONNX Runtime** (`CPUExecutionProvider` saving `ort_output_0.npy`), and finally compares both NumPy outputs via `np.allclose(atol, rtol)` with `max_abs_diff`, `RMSE`, and `cosine_similarity`.

---

## 2. Visual Flow Graphs: Which Scripts Run at Each CI/CD Stage?

*(A high-resolution diagram is bundled at `ci/riscv_rvv/docs/iree_riscv64_rvv_cicd_flow_graph.png`.)*

### Flow Graph A: Master CI/CD Stage Pipeline (VME Ukernel Path)

```text
[CI/CD Trigger Event]
  |
  +---> Pull Request (PR) -----> ./ci/riscv_rvv/ci_entrypoint.sh --stage pr
  +---> Nightly Cron Schedule -> ./ci/riscv_rvv/ci_entrypoint.sh --stage nightly
  +---> Release Tag (v*.*.*) --> ./ci/riscv_rvv/ci_entrypoint.sh --stage stable
          |
          v
  +======================================================+
  | STAGE 0: Fast Pre-Commit & Script Integrity Gate     |
  +======================================================+
  | Script : ci/riscv_rvv/modules/00_pre_commit_check.sh
          |
          v
  +======================================================+
  | STAGE 1: Two-Step Host + RISC-V 64 RVV Cross-Build   |
  +======================================================+
  | Script : ci/riscv_rvv/modules/01_build_iree_rvv.sh
  | Config : ci/riscv_rvv/config.env
  |   |-- 1A. Host Build (iree-compile, iree-import-onnx)
  |   +-- 1B. Target Cross-Build (riscv64 iree-run-module)
          |
          v
  +======================================================+
  | STAGE 2: IREE Core Tests (Lit + RVV ukernel + HAL)   |
  +======================================================+
  | Script : ci/riscv_rvv/modules/02_run_iree_core_tests.sh
  |          (Delegates RISC-V target tests to riscv_test.sh)
  |   |-- 2A. Host Lit Tests (MLIR -> RISC-V RVV codegen)
  |   |-- 2B. RVV Microkernel Tests (ctest -R ukernel)
  |   +-- 2C. Core Runtime / HAL / e2e_matmul
          |
          v
  +======================================================+
  | STAGE 3: Generate VME Ukernel ONNX & CTest Suite     |
  +======================================================+
  | Scripts:
  |   |-- vme_ukernel_suite/gen_conv2d_onnx.py
  |   |-- vme_ukernel_suite/gen_matmul_onnx.py
  |   +-- vme_ukernel_suite/gen_conv_matmul_model_onnx.py
  | Output : conv2d_tests.cmake, matmul_tests.cmake,
  |          conv_matmul_model_tests.cmake
          |
          v
  +======================================================+
  | STAGE 4: Run VME Ukernel Path via CTest              |
  +======================================================+
  | Runner : ctest --test-dir build-vme-ctest -R vme_ukernel
  | Script : vme_ukernel_suite/run_vme_ukernel_case.py
  |   |-- 4A. IREE VME Ukernel Path -> iree_output_0.npy
  |   |-- 4B. ONNX Runtime Golden   -> ort_output_0.npy
  |   +-- 4C. NumPy np.allclose(atol, rtol) + JUnit XML
          |
          v
  +======================================================+
  | STAGE 5: Release Packaging (Nightly & Stable Only)   |
  +======================================================+
  | Output : iree-<version>.tar.gz + .sha256 checksum
```

| Stage | Script Executed | Key Inputs Consumed | Key Outputs Produced |
| :--- | :--- | :--- | :--- |
| **Stage 0: Pre-Commit Gate** | `ci/riscv_rvv/modules/00_pre_commit_check.sh` | `ci/riscv_rvv/**` | Exit `0` (Pass) or `1` |
| **Stage 1: Build & Cross-Build** | `ci/riscv_rvv/modules/01_build_iree_rvv.sh` | `ci/riscv_rvv/config.env`, `linux_riscv64.cmake` | `iree-compile`, `iree-import-onnx`, `iree-run-module` |
| **Stage 2: Core CTest Pyramid** | `ci/riscv_rvv/modules/02_run_iree_core_tests.sh` (`riscv_test.sh`) | `--stage pr\|nightly\|stable` | `junit_host_lit_*.xml`, `junit_riscv_rvv_ukernel.xml` |
| **Stage 3: Generate VME ONNX Cases** | `gen_conv2d_onnx.py`, `gen_matmul_onnx.py`, `gen_conv_matmul_model_onnx.py` | Dimension & model configs | `.onnx` files + `*_tests.cmake` |
| **Stage 4: VME Ukernel CTest Run** | `ci/riscv_rvv/vme_ukernel_suite/run_vme_ukernel_case.py` | `IREE_VME_CPU_FEATURES` | `iree_output_0.npy`, `ort_output_0.npy`, `comparison_report.json`, `junit_vme_ukernel_*.xml` |
| **Stage 5: Release Packaging** | `ci/riscv_rvv/ci_entrypoint.sh` | Host & `riscv64` binaries | `iree-<version>.tar.gz` + `.sha256` |

### Flow Graph B: VME Ukernel Path Dataflow (Per-Case CTest Execution)

Every `ctest -R vme_ukernel` test case runs `run_vme_ukernel_case.py` in this exact order:

```text
[Generated ONNX Case: Conv2D | Unbatched MatMul | Conv+MatMul Model]
        |
        v
  [STEP 1] Generate Deterministic NumPy Input
        +-> Saves inputs/input_0.npy matching ONNX graph signature
        |
        v
  [STEP 2] FIRST: Execute IREE VME Ukernel Path
        |-- 2a. iree-import-onnx model.onnx -o model.mlir
        |-- 2b. iree-compile model.mlir
        |         --iree-llvmcpu-target-cpu-features="${IREE_VME_CPU_FEATURES}"
        |         --iree-opt-data-tiling
        |         --iree-llvmcpu-enable-ukernels=all
        |         --iree-global-opt-use-im2col-for-convs=true
        |         -> model_vme.vmfb
        +-- 2c. iree-run-module --module=model_vme.vmfb
                  --input=@inputs/input_0.npy
                  --output=@iree_outputs/iree_output_0.npy
        |
        v
  [STEP 3] THEN: Execute ONNX Runtime Golden Reference
        |-- Runs onnxruntime.InferenceSession (CPUExecutionProvider)
        +-- Feeds exact same inputs/input_0.npy
              -> Saves ort_outputs/ort_output_0.npy
        |
        v
  [STEP 4] NumPy Numerical Comparison (03_ort_vs_iree_numpy.py)
        |-- Loads ort_output_0.npy & iree_output_0.npy
        |-- Computes max_abs_diff, mean_abs_diff, RMSE, cosine_sim
        +-- Asserts np.allclose(ort_arr, iree_arr, rtol=1e-3, atol=1e-3)
              -> comparison_report.json + CTest Pass/Fail
```

---

## 3. Detailed Explanation of Every Stage

### Stage 0: Pre-Commit & Script Integrity Gate (`00_pre_commit_check.sh`)
- Validates Bash (`bash -n`) and Python (`py_compile`) syntax across `ci/riscv_rvv/` in under 3 seconds before triggering a cross-compile.
- Install locally with `./ci/riscv_rvv/modules/00_pre_commit_check.sh --install-hook`.

### Stage 1: Two-Step Host + Target Cross-Compilation (`01_build_iree_rvv.sh`)
- **Host Build (`build-host/`)**: Builds `iree-compile`, `iree-import-onnx`, and Python bindings (`-DIREE_BUILD_PYTHON_BINDINGS=ON`) on `x86_64`.
- **Target Cross-Build (`build-riscv64-rvv/`)**: Cross-compiles `iree-run-module`, `iree-benchmark-module`, and CTest unit binaries for `riscv64-unknown-linux-gnu` via [`build_tools/cmake/linux_riscv64.cmake`](https://github.com/iree-org/iree/blob/main/build_tools/cmake/linux_riscv64.cmake).
- Uses `RelWithDebInfo` with assertions on PR/Nightly, and `Release` on Stable Releases.

### Stage 2: IREE Internal CTest Pyramid (`02_run_iree_core_tests.sh` & `riscv_test.sh`)
1. **Host Compiler Lit & Python Binding Tests**: `ctest --test-dir build-host -R "compiler/src/iree/compiler/Codegen/LLVMCPU|riscv|compiler/bindings/python"`.
2. **RISC-V 64 RVV `ukernel` Unit Tests (`ctest -R ukernel`)**: Runs `mmt4d_test`, `pack_test`, `unpack_test`, and `query_tile_sizes_test` **without** `-L driver=local-task` (because standalone ukernel tests do not carry a HAL driver label) and with RVV enabled so tests do not silently fall back via `ALLOW_GENERIC_FALLBACK` ([IREE Issue #24576](https://github.com/iree-org/iree/issues/24576)).
3. **Core Runtime, HAL, VM & `e2e_matmul` Tests**: Runs `iree/base|iree/hal|iree/vm|check_llvm-cpu|e2e_matmul` on PRs and the full cross-compiled CTest tree on Nightly/Stable.

### Stage 3 & Stage 4: VME Ukernel ONNX & CTest Suite (`ci/riscv_rvv/vme_ukernel_suite/`)

| Generator File | Operation Covered | Dimension & Layer Coverage | Generated CTest File |
| :--- | :--- | :--- | :--- |
| `ci/riscv_rvv/vme_ukernel_suite/gen_conv2d_onnx.py` | **Conv2D** | 10 dimension cases (`1x1` pointwise, `3x3`, `5x5`, `7x7`, strided, batched, and odd shapes like `1x7x19x23` and `1x11x17x17`) routed via `--iree-global-opt-use-im2col-for-convs=true` + `--iree-opt-data-tiling` | `conv2d_tests.cmake` |
| `ci/riscv_rvv/vme_ukernel_suite/gen_matmul_onnx.py` | **MatMul (Unbatched 2D)** | 12 `(M, K, N)` cases (`16x16x16` up to `256x512x256`, GEMV `1x128x64`, skinny `4x256x128`, and odd remainder shapes like `17x33x19`, `13x47x29`, `7x513x31`) | `matmul_tests.cmake` |
| `ci/riscv_rvv/vme_ukernel_suite/gen_conv_matmul_model_onnx.py` | **Combined Conv2D + MatMul Model** | 4 end-to-end CNN+MLP models (`Conv -> Relu -> Conv -> Relu -> GlobalAveragePool -> Flatten -> MatMul -> Add -> Relu -> MatMul -> Add`) across `32x32`, `28x28`, odd `19x23`, and `56x56` inputs | `conv_matmul_model_tests.cmake` |

- **PR Stage (`--stage pr`)**: Runs all VME ukernel CTest cases labeled `stable` (`-L stable`) for fast PR turnaround.
- **Nightly Stage (`--stage nightly`)**: Runs **all** `stable` and `nightly` VME ukernel CTest cases (including large dimensions and odd-shape sweeps).
- **Stable Release Stage (`--stage stable`)**: Runs all `stable` VME ukernel CTest cases as a strict release gate before packaging `iree-<version>.tar.gz` + `.sha256`.

---

## 4. Copy-Paste Command Reference for the CI/CD Team

### Option 1: Single-Command Master Entrypoint (Recommended)

```bash
# 1. Run on Every Pull Request (PR):
./ci/riscv_rvv/ci_entrypoint.sh --stage pr

# 2. Run on Nightly Schedule (Cron):
./ci/riscv_rvv/ci_entrypoint.sh --stage nightly

# 3. Run on Stable Release Tag (e.g., v1.0.0):
./ci/riscv_rvv/ci_entrypoint.sh --stage stable --release-version v1.0.0
```

### Option 2: Modular Stage-by-Stage Script Commands

```bash
# STAGE 0: Fast Pre-Commit Check
./ci/riscv_rvv/modules/00_pre_commit_check.sh

# STAGE 1: Build Host Compiler & Cross-Compile RISC-V 64 RVV Runtime
./ci/riscv_rvv/modules/01_build_iree_rvv.sh --build-type RelWithDebInfo

# STAGE 2: Run IREE Core CTest Suites (Lit + RVV ukernel + riscv_test.sh)
./ci/riscv_rvv/modules/02_run_iree_core_tests.sh --stage pr

# STAGE 3: Generate VME Ukernel ONNX Cases (Conv2D, Unbatched MatMul, Combined Model)
python3 ci/riscv_rvv/vme_ukernel_suite/gen_conv2d_onnx.py
python3 ci/riscv_rvv/vme_ukernel_suite/gen_matmul_onnx.py
python3 ci/riscv_rvv/vme_ukernel_suite/gen_conv_matmul_model_onnx.py

# STAGE 4: Run VME Ukernel Path via CTest (IREE VME -> ONNX Runtime -> NumPy Compare)
export IREE_VME_CPU_FEATURES="+m,+a,+f,+d,+v,+zvl256b"
export IREE_HOST_BIN_DIR="$(realpath build-host/install/bin)"
export IREE_RISCV_BIN_DIR="$(realpath build-riscv64-rvv/tools)"
cmake -B build-vme-ctest -S ci/riscv_rvv/vme_ukernel_suite
ctest --test-dir build-vme-ctest -R "vme_ukernel" --output-on-failure -j "$(nproc)"
```

### Option 3: Raw Underlying CLI Commands (Single VME Ukernel Case Without Wrappers)

```bash
# 1. Import ONNX to MLIR
./build-host/install/bin/iree-import-onnx \
  tests/vme_ukernel_onnx/conv2d/conv2d_f32_1x3x32x32_k3s1p1.onnx \
  --opset-version 17 \
  -o /tmp/vme_case/model.mlir

# 2. Compile via IREE VME Ukernel Path (data-tiling + ukernels=all + im2col for Conv2D)
./build-host/install/bin/iree-compile \
  /tmp/vme_case/model.mlir \
  --iree-hal-target-device=local \
  --iree-hal-local-target-device-backends=llvm-cpu \
  --iree-llvmcpu-target-triple=riscv64-unknown-linux-gnu \
  --iree-llvmcpu-target-abi=lp64d \
  --iree-llvmcpu-target-cpu-features="+m,+a,+f,+d,+v,+zvl256b" \
  --riscv-v-fixed-length-vector-lmul-max=8 \
  --iree-opt-data-tiling \
  --iree-llvmcpu-enable-ukernels=all \
  --iree-global-opt-use-im2col-for-convs=true \
  -o /tmp/vme_case/model_vme.vmfb

# 3. Execute on Target (saving iree_output_0.npy)
./build-riscv64-rvv/tools/iree-run-module \
  --device=local-task \
  --module=/tmp/vme_case/model_vme.vmfb \
  --function=main_graph \
  --input=@/tmp/vme_case/inputs/input_0.npy \
  --output=@/tmp/vme_case/iree_outputs/iree_output_0.npy

# 4. Compare IREE VME Output vs. ONNX Runtime Golden Output in NumPy
python3 ci/riscv_rvv/modules/03_ort_vs_iree_numpy.py compare \
  --ort-outputs /tmp/vme_case/ort_outputs/ort_output_0.npy \
  --iree-outputs /tmp/vme_case/iree_outputs/iree_output_0.npy \
  --atol 1e-3 --rtol 1e-3
```

---

## 5. Summary Matrix: PR vs. Nightly vs. Stable Release Pipeline Policies

| Pipeline Policy | Pull Request (`--stage pr`) | Nightly Release (`--stage nightly`) | Stable Release (`--stage stable`) |
| :--- | :--- | :--- | :--- |
| **Trigger Condition** | Every PR targeting `main` / `release/*` | Daily schedule (`0 20 * * *` UTC) | Git tag push (`v*.*.*`) or manual release trigger |
| **CMake Build Type** | `RelWithDebInfo` (`IREE_ENABLE_ASSERTIONS=ON`) | `RelWithDebInfo` (`IREE_ENABLE_ASSERTIONS=ON`) | `Release` (fully optimized) |
| **Host Lit & Python Tests** | RISC-V, LLVMCPU & `compiler/bindings/python` | Full host Lit + Python binding suite | RISC-V, LLVMCPU & `compiler/bindings/python` |
| **RISC-V 64 RVV `ukernel` Tests** | Mandatory (`ctest -R ukernel` via `riscv_test.sh`) | Mandatory (`ctest -R ukernel` via `riscv_test.sh`) | Mandatory (`ctest -R ukernel` via `riscv_test.sh`) |
| **RISC-V 64 Runtime / HAL / E2E** | `iree/base\|iree/hal\|iree/vm\|check_llvm-cpu\|e2e_matmul` | Full cross-compiled CTest suite | Full cross-compiled CTest suite |
| **VME Ukernel ONNX CTest Suite** | `stable`-labeled Conv2D, MatMul & Hybrid cases | All `stable` + `nightly` Conv2D, MatMul & Hybrid cases | `stable`-labeled Conv2D, MatMul & Hybrid cases |
| **Output Artifacts for CI** | JUnit XML + `comparison_report.json` | JUnit XML + `iree-nightly-riscv64-rvv-YYYYMMDD.tar.gz` | JUnit XML + `iree-vX.Y.Z.tar.gz` + `.sha256` |
